"计算商业银行之资产负债表结构。"

##########################################
#使用/在用；
#状态/完善中；
##########################################

include("./defineType.jl")
# include("./setParameters.jl")
# include("./fun_initVariables.jl")


## 函数区



"汇总各银行之总资产。"
function together_B_A_all!(bank::BankCommercial, bankList::TypeState{1})
    bank.A_all[bankList] = bank.A_BI_all[bankList] + bank.A_exBI[bankList]
end


"加总各银行之银行间总资产，通过银行间资产邻接矩阵。"
function sum_B_A_BI!(bank::BankCommercial, interbank::BankInterbank, bankList::TypeState{1}, interbankList::TypeState{2})
    bank.A_BI_all[:] = sum(interbank.A_BI .* interbankList, dims = 2)
end

"汇总各银行之非银行间资产``A_{-BI}``。"
function together_B_A_exBI!(bank::BankCommercial, bankList::TypeState{1})
    bank.A_exBI[bankList] = bank.A_P[bankList] + bank.A_Q[bankList] + bank.A_R[bankList] + bank.A_other[bankList]
end

# "更新各银行之银行总负债``Z_{B}``。"
# function update_B_Z_all!(bank::BankCommercial, interbank::BankInterbank, byWay::String = "all")
#     if byWay == "all"
#         together_B_Z_exBI!(bank,bankList)
#         together_B_Z_BI!(bank, interbank,bankList,interbankList)
#     elseif byWay == "Z_exBI" || byWay == "Z_D"
#         together_B_Z_exBI!(bank,bankList)
#     elseif byWay == "Z_BI"
#         together_B_Z_BI!(bank, interbank,bankList,interbankList)
#     else
#         throw(DomainError(byWay, "关键词取值错误！"))
#     end
#     together_B_Z_all!(bank,bankList)
# end

"汇总各银行之总负债。"
function together_B_Z_all!(bank::BankCommercial, bankList::TypeState{1})
    bank.Z_all[bankList] = bank.Z_BI_all[bankList] + bank.Z_exBI[bankList]
end

"加总各银行之银行间负债，通过银行间负债邻接矩阵。"
function sum_B_Z_BI!(bank::BankCommercial, interbank::BankInterbank, bankList::TypeState{1}, interbankList::TypeState{2})
    bank.Z_BI_all[:] = sum(interbank.Z_BI .* interbankList, dims = 2)
end

"汇总各银行之非银行间负债``Z_{-BI}``。"
function together_B_Z_exBI!(bank::BankCommercial, bankList::TypeState{1})
    bank.Z_exBI[bankList] = bank.Z_D[bankList] + bank.Z_other[bankList]
end

"计算各银行之所有者权益``E_{B}``，通过总资产与总负债差值。"
function calc_B_E_all!(bank::BankCommercial, bankList::TypeState{1})
    bank.E_all[bankList] = max.(bank.A_all[bankList] - bank.Z_all[bankList] - LESS1[bankList], 0.0)
end

"计算银行体系内包括已退出银行在内的所有各银行之所有者权益``E_{B}``，通过总资产与总负债差值。"
function calc_B_E_all_at_all_bank!(bank::BankCommercial, bankList::TypeState{1})
    bank.E_all[:] = max.(bank.A_all - bank.Z_all - LESS1, 0.0)
end


"计算各银行之总资产``A_{B}``，通过所有者权益和总负债。"
function calc_B_A_all!(bank::BankCommercial, bankList::TypeState{1})
    bank.A_all[bankList] = bank.E_all[bankList] + bank.Z_all[bankList]
end

"计算各银行之总负债``Z_{B}``，通过所有者权益和总资产。"
function calc_B_Z_all!(bank::BankCommercial, bankList::TypeState{1})
    bank.Z_all[bankList] = bank.A_all[bankList] - bank.E_all[bankList]
end

"转换银行间资产为负债。"
function alter_to_Z_BI!(interbank::BankInterbank)
    interbank.Z_BI = interbank.A_BI'
end

"转换银行间负债为资产。"
function alter_to_A_BI!(interbank::BankInterbank)
    interbank.A_BI = interbank.Z_BI'
end

# HACK改为单独计算？"汇总各银行之总贷款流量``Lo_{B}``。"
function together_B_Lo_all!(bank::BankCommercial, bankList::TypeState{1})
    bank.Lo_all[bankList] = bank.Lo_BI[bankList] + bank.Lo_exBI[bankList]
end

# HACK改为单独计算？"汇总各银行之非银行间贷款流量``Lo_{-BI}``。"
function together_B_Lo_exBI!(bank::BankCommercial, bankList::TypeState{1})
    bank.Lo_exBI[bankList] = bank.Lo_P[bankList]
end

# HACK改为单独计算？"汇总各银行之总借款流量``Bi_{B}``。"
function together_B_Li_all!(bank::BankCommercial, bankList::TypeState{1})
    bank.Li_all[bankList] = bank.Li_BI[bankList] + bank.Li_exBI[bankList]
end

# HACK改为单独计算？"汇总各银行之非银行间借款流量``Bi_{-BI}``。"
function together_B_Li_exBI!(bank::BankCommercial, bankList::TypeState{1})
    bank.Li_exBI[bankList] = bank.Li_D[bankList]
end


### #使用/暂无 更新银行间变量
"""
更新各银行间之资产负债矩阵。
# Arguments
`byWay::String`: 参数，通过该参数指定的变量作为已知变量，更新其他相关各变量。
- `Z_BI`: 已知``Z_{BI}``，更新其余银行间资产负债变量；
- `A_BI`: 已知``A_{BI}``，更新其余银行间资产负债变量；
"""
function update_BI_balanceSheet!(interbank::BankInterbank; byWay::String)
    if byWay == "Z_BI"
        interbank.A_BI = interbank.Z_BI'
    elseif byWay == "A_BI"
        interbank.Z_BI = interbank.A_BI'
    else
        throw(DomainError(byWay, "关键词取值错误！"))
    end
end


### 更新各银行之资产负债表变量
"""
更新各银行之资产负债表变量。
# Arguments
`byWay::String`: 参数，通过该参数指定的变量作为已知变量，更新其他相关各变量。
- `all`: 更新各银行之所有资产负债表变量；
- `A_exBI`: 已知``A_{-BI}``，更新各银行之其余相关的资产负债表变量；
- `A_P`: 已知``L_{-BI}``，更新各银行之其余相关的资产负债表变量；
- `A_Q`: 已知``Q_{B}``，更新各银行之其余相关的资产负债表变量；
- `A_R`: 已知``R_{B}``，更新各银行之其余相关的资产负债表变量；
- `A_other`: 已知``A_{other}``，更新各银行之其余相关的资产负债表变量；
- `A_BI_all`: 已知``A_{BI}[i,:]``，更新各银行之其余相关的资产负债表变量；
- `Z_exBI`: 已知``Z_{exBI}``，更新各银行之其余相关的资产负债表变量；
- `Z_D`: 已知``D_{B}``，更新各银行之其余相关的资产负债表变量；
- `Z_other`: 已知``Z_{other}``，更新各银行之其余相关的资产负债表变量；
- `Z_BI_all`: 已知``Z_{BI}[i,:]``，更新各银行之其余相关的资产负债表变量；
- `E_all and Z_all`: 已知``E_{B}``和``Z_{B}``，更新各银行之其余相关的资产负债表变量；
- `E_all and A_all`: 已知``E_{B}``和``A_{B}``，更新各银行之其余相关的资产负债表变量；
- `calc all E_all`: 已知``A_{B}``和``Z_{B}``，更新计算所有银行之所有者权益``E_{B}``；
- `sum A_BI`: 已知``A_{BI}[i,j]``，加总各银行变量``A_{BI}[i,:]``；
- `sum Z_BI`: 已知``Z_{BI}[i,j]``，加总各银行变量``Z_{BI}[i,:]``；
- `alter A_BI`: 已知``Z_{BI}[i,j]``，转换得到``A_{BI}[i,j]``；
- `alter Z_BI`: 已知``A_{BI}[i,j]``，转换得到``Z_{BI}[i,j]``；
"""
function update_B_balanceSheet!(bank::BankCommercial, interbank::BankInterbank, bankList::TypeState{1}, interbankList::TypeState{2}; byWay::String)
    if byWay == "all"
        together_B_A_exBI!(bank, bankList)
        sum_B_A_BI!(bank, interbank, bankList, interbankList)
        together_B_A_all!(bank, bankList)
        together_B_Z_exBI!(bank, bankList)
        sum_B_Z_BI!(bank, interbank, bankList, interbankList)
        together_B_Z_all!(bank, bankList)
        calc_B_E_all!(bank, bankList)
    elseif byWay == "A_exBI" || byWay == "A_P" || byWay == "A_Q" || byWay == "A_R" || byWay == "A_other"
        together_B_A_exBI!(bank, bankList)
        together_B_A_all!(bank, bankList)
        # calc_B_E_all!(bank,bankList) #HACK 冗余。不能调用，只能在外部手动计算。此处可以删除。
    elseif byWay == "A_BI_all"
        together_B_A_all!(bank, bankList)
        # calc_B_E_all!(bank,bankList) #HACK 冗余。不能调用，只能在外部手动计算。此处可以删除。
    elseif byWay == "Z_exBI" || byWay == "Z_D" || byWay == "Z_other"
        together_B_Z_exBI!(bank, bankList)
        together_B_Z_all!(bank, bankList)
        # calc_B_E_all!(bank,bankList) #HACK 冗余。不能调用，只能在外部手动计算。此处可以删除。
    elseif byWay == "Z_BI_all"
        together_B_Z_all!(bank, bankList)
        # calc_B_E_all!(bank,bankList) #HACK 冗余。不能调用，只能在外部手动计算。此处可以删除。
    elseif byWay == "E_all and Z_all"
        calc_B_A_all!(bank, bankList)
    elseif byWay == "E_all and A_all"
        calc_B_Z_all!(bank, bankList)
    elseif byWay == "calc all E_all"
        calc_B_E_all_at_all_bank!(bank, bankList)
    elseif byWay == "sum A_BI"
        sum_B_A_BI!(bank, interbank, bankList, interbankList)
        together_B_A_all!(bank, bankList)
        # calc_B_E_all!(bank,bankList) #HACK 冗余。不能调用，只能在外部手动计算。此处可以删除。
    elseif byWay == "sum Z_BI"
        sum_B_Z_BI!(bank, interbank, bankList, interbankList)
        together_B_Z_all!(bank, bankList)
        # calc_B_E_all!(bank,bankList) #HACK 冗余。不能调用，只能在外部手动计算。此处可以删除。
    elseif byWay == "alter from A_BI"
        # sum_B_A_BI!(bank, interbank,bankList,interbankList) #HACK 冗余。不能调用，只能在外部手动计算。此处可以删除。
        # together_B_A_all!(bank,bankList) #HACK 冗余。不能调用，只能在外部手动计算。此处可以删除。
        alter_to_Z_BI!(interbank)
        # sum_B_Z_BI!(bank, interbank,bankList,interbankList) #HACK 冗余。不能调用，只能在外部手动计算。此处可以删除。
        # together_B_Z_all!(bank,bankList) #HACK 冗余。不能调用，只能在外部手动计算。此处可以删除。
        # calc_B_E_all!(bank,bankList) #HACK 冗余。不能调用，只能在外部手动计算。此处可以删除。
    elseif byWay == "alter from Z_BI"
        # sum_B_Z_BI!(bank, interbank,bankList,interbankList) #HACK 冗余。不能调用，只能在外部手动计算。此处可以删除。
        # together_B_Z_all!(bank,bankList) #HACK 冗余。不能调用，只能在外部手动计算。此处可以删除。
        alter_to_A_BI!(interbank)
        # sum_B_A_BI!(bank, interbank,bankList,interbankList) #HACK 冗余。不能调用，只能在外部手动计算。此处可以删除。
        # together_B_A_all!(bank,bankList) #HACK 冗余。不能调用，只能在外部手动计算。此处可以删除。
        # calc_B_E_all!(bank,bankList) #HACK 冗余。不能调用，只能在外部手动计算。此处可以删除。
    else
        throw(DomainError(byWay, "关键词取值错误！"))
    end
end


# function update_B_balanceSheet!(bank::BankCommercial, interbank::BankInterbank; byWay::String)
#     update_B_A_all!(bank, interbank, byWay = byWay)
#     update_B_Z_all!(bank, interbank, byWay = byWay)
#     update_B_E_all!(bank,byWay=byWay)
# end




# "更新各银行之银行总资产``A_{B}``。"
# function update_B_A_all!(bank::BankCommercial, interbank::BankInterbank; byWay::String = "all")
#     if byWay == "all"
#     elseif byWay == "A_exBI" || byWay == "A_P" || byWay == "A_Q" || byWay == "A_R"
#         together_B_A_exBI!(bank,bankList)
#     elseif byWay == "A_BI"
#         together_B_A_BI!(bank, interbank,bankList,interbankList)
#     else
#         throw(DomainError(byWay, "关键词取值错误！"))
#     end
#     together_B_A_all!(bank,bankList)
# end







