

## 模块之银行间市场BI1111

##########################################
#使用：在用；
#状态：进行中；
##########################################


function model_BI1111(BB::BankCommercial, BI::BankInterbank)

    ## 初始化
    tau = 0 # 初始化传染轮次
    isEnd = false # 初始化结束判断

    tau += 1 # 传染回合累加一
    println("开始回合$tau")

    ## # 初始阶段$t_{0}$，当$\tau=1$时：
    println("t0 初始阶段")

    ## 设置临时变量
    BB_t0 = deepcopy(BB) # 临时设置BB变量，被读取于阶段1
    BI_t0 = deepcopy(BI) # 临时设置BI变量，被读取于阶段1


    ## # 子过程：外部违约损失冲击
    println("子过程：外部违约损失冲击")

    ## 初始化
    tau = 0 # 初始化传染轮次
    isEnd = false # 初始化结束判断

    tau += 1 # 传染回合累加一
    println("开始回合$tau")

    ## ## 初始阶段$t_{0}$，当$\tau=1$时：
    println("t0 初始阶段")

    on = BB.isOn # 临时设置BB有存在的示性变量
    bal = TypeState{1}(BB.isOn .|| BB.isOff) # 临时设置BB示性变量
    ial = TypeState{2}((BB.isOn .|| BB.isOff) .&& (BB.isOn .|| BB.isOff)') # 临时设置BI示性变量

    ## ## 初始外生传染冲击阶段$t_{1}$，当$\tau=1$时：
    println("t1 开始外生传染冲击阶段")

    ## ## 初始外生损失冲击传染：
    println("t1-1 初始外生损失冲击传染")
    if p.theta_Shock_exBI_t == 1.0
        update_B_Shock!(BB, BI, bal, ial; byWay = "Shock_L_exBI_t") # 生成综合外生冲击
        BB.Shock_B_A[bal] = BB.Shock_exBI_t[bal] # 银行外冲击传导至银行内资产冲击
        update_B_Shock!(BB, BI, bal, ial; byWay = "Shock_B_A")
    elseif p.theta_Shock_exBI_t != 0.0
        throw(DomainError(p.theta_Shock_exBI_t, "参数暂时只能取值1或者0！"))
    end

    ## ## 初始外生冲击阶段$t_{2}$，当$\tau=1$时：
    println("t2 开始外生冲击阶段")

    ## ### 初始化：
    println("t2-0 初始化")

    ## 设置临时变量
    BB_t1 = deepcopy(BB)
    BI_t1 = deepcopy(BI)

    ## 清零银行间和银行外冲击变量
    update_B_Shock!(BB, BI, bal, ial; byWay = "clear Shock_BI and Shock_exBI")

    ## ### 银行之非银行间贷款违约损失冲击：
    println("t2-1 银行之非银行间贷款违约损失冲击")
    if p.theta_Shock_exBI_t == 1.0
        BB.A_P[bal] -= BB.Shock_B_A[bal] # 银行之非银行间资产变动
        update_B_balanceSheet!(BB, BI, bal, ial; byWay = "A_P")
        update_B_state!(BB, BI; to = "insolvent", from = "healthy") # 更新各银行之状态，从健康到资不抵债
        # update_B_state!(BB, BI; to = "bankrupt", from = "insolvent") # 更新各银行之状态，从资不抵债到破产
        BB.E_all[BB.isOn] = max.(BB.E_all[BB.isOn] - BB.Shock_B_A[BB.isOn], 0.0) # 银行之所有者权益
        # update_B_state!(BB, BI, to = "insolvent", from = "any")
        # update_B_balanceSheet!(BB, BI,a,ia; byWay = "E_all and A_all") # 计算各银行之总负债Z_BI_all
        BB.Z_BI_all[BB.isInsolvent] = BB_t1.Z_BI_all[BB.isInsolvent] - ((BB.Shock_B_A[BB.isInsolvent] - BB_t1.E_all[BB.isInsolvent]) ./ (BB_t1.Z_BI_all[BB.isInsolvent] + BB_t1.Z_D[BB.isInsolvent]) .* BB_t1.Z_BI_all[BB.isInsolvent]) # 银行间负债变动，由于违约
        update_B_balanceSheet!(BB, BI, bal, ial; byWay = "Z_BI_all") # 汇总各银行之非银行间负债Z_exBI、总负债Z_all，被动地计算所有者权益
        BB.Z_D[BB.isInsolvent] = BB_t1.Z_D[BB.isInsolvent] - ((BB.Shock_B_A[BB.isInsolvent] - BB_t1.E_all[BB.isInsolvent]) ./ (BB_t1.Z_BI_all[BB.isInsolvent] + BB_t1.Z_D[BB.isInsolvent]) .* BB_t1.Z_D[BB.isInsolvent]) # 存款负债变动，由于违约
        update_B_balanceSheet!(BB, BI, bal, ial; byWay = "Z_D") # 汇总各银行之非银行间负债Z_exBI、总负债Z_all，被动地计算所有者权益
        BB.Shock_BI_def_s[BB.isInsolvent] = abs.(BB.Z_BI_all[BB.isInsolvent] - BB_t1.Z_BI_all[BB.isInsolvent]) # 银行内冲击传导至银行间传染冲击
        update_B_Shock!(BB, BI, bal, ial; byWay = "Shock_BI_def_s") # 汇总各银行之违约损失冲击
        BB.Shock_D_s[BB.isInsolvent] = abs.(BB.Z_D[BB.isInsolvent] - BB_t1.Z_D[BB.isInsolvent]) # 银行内冲击传导至银行存款传染冲击
    elseif p.theta_Shock_exBI_t != 0.0
        throw(DomainError(p.theta_Shock_exBI_t, "参数暂时只能取值1或者0！"))
    end

    ## ## 尾声阶段$t_{4}$：
    println("t4 开始尾声阶段")

    ## TODO存储数据
    BB_tau[tau] = deepcopy(BB) # 存储该轮次传染结果数据
    BI_tau[tau] = deepcopy(BI) # 存储该轮次传染结果数据

    ## 清零银行内冲击变量
    update_B_Shock!(BB, BI, bal, ial; byWay = "clear Shock_B")

    ## 判定本回合是否有银行转移状态，如果无则后续处理然后结束本轮，如果有则继续处理。
    if BB.isInsolvent == BB_t1.isInsolvent
        isEnd = true
    end

    ## # 子过程：违约损失冲击传染
    println("子过程：违约损失冲击传染")
    while (tau <= p.max_num_tau .&& isEnd != true) # 循环，当回合$\tau>1$时：


        tau += 1 # 传染回合累加一
        println("开始回合$tau")

        ## ## 初始阶段$t_{0}$，当$\tau>1$时：
        println("t0 初始阶段")

        on = BB.isOn # 临时设置BB有存在的示性变量
        a = TypeState{1}(BB.isOn .|| BB.isOff) # 临时设置BB示性变量
        ia = TypeState{2}((BB.isOn .|| BB.isOff) .&& (BB.isOn .|| BB.isOff)') # 临时设置BI示性变量


        ## ## 银行间传染冲击阶段$t_{1}$，当$\tau>1$时：
        println("t1 开始银行间传染冲击阶段")

        ## ### 银行间违约损失冲击传染方式$i_{br} \stackrel{def,BI}{\longrightarrow} j_{cre}$：
        println("t1-1 银行间违约损失冲击传染方式")
        isv = BB.isInsolvent # 临时设置BB资不抵债的示性变量，在阶段1
        cre_isv = BI.listOfCreditors # 临时设置BI之列表之于银行之债权方银行编号
        for i in findall(isv) # 资不抵债银行违约，导致其对各债权银行负债变动，造成银行间违约冲击
            BI.Z_BI[i, cre_isv[i]] .*= (1.0 - BB.Shock_BI_def_s[i] ./ BB_t1.Z_BI_all[i])
            BI.Shock_BI_def[cre_isv[i], i] = BI_t1.Z_BI[i, cre_isv[i]] .* BB.Shock_BI_def_s[i] ./ BB_t1.Z_BI_all[i]
        end
        # HACK以下部分是否提取出来在阶段1结束之前使用
        update_B_balanceSheet!(BB, BI, a, ia; byWay = "alter from Z_BI") # 转换银行间资产负债邻接矩阵
        update_B_Shock!(BB, BI, a, ia; byWay = "Shock_BI_def") # 加总各单个债权银行遭受总银行间违约损失冲击
        # BB.A_BI_all[a] -= BB.Shock_BI_def_t[a] # HACK（仅作说明）各资不抵债银行对应债权银行之银行间资产变动（不是在此处出现，在银行内冲击阶段出现）。可以删除。
        BB.Shock_B_A[a] = BB.Shock_BI_def_t[a] # 银行间冲击传导为银行内冲击
        update_B_Shock!(BB, BI, a, ia; byWay = "Shock_B_A") # 汇总各银行之银行内资产负债冲击



        ## ## 银行资产负债冲击阶段$t_{2}$，当$\tau>1$时：
        println("t2 开始银行资产负债冲击阶段")

        ## ### 初始化：
        println("t2-0 初始化")

        ## 设置临时变量
        BB_t1 = deepcopy(BB) # 临时设置BB变量，被读取于本回合之银行资产冲击
        BI_t1 = deepcopy(BI) # 临时设置BI变量，被读取于本回合之银行资产冲击

        ## 清零银行间和银行外冲击变量
        update_B_Shock!(BB, BI, a, ia; byWay = "clear Shock_BI and Shock_exBI") # 清零各银行之不必要的冲击变量，被使用于下一回合，从第二回合开始

        ## ### 银行内资产冲击：
        println("t2-1 银行内资产冲击")
        BB.A_BI_all[a] = max.(BB.A_BI_all[a] - BB.Shock_B_A[a], 0.0) # 银行之银行间资产变动
        update_B_balanceSheet!(BB, BI, a, ia; byWay = "A_BI_all")
        BB.E_all[BB.isOn] = max.(BB.E_all[BB.isOn] - BB.Shock_B_A[BB.isOn], 0.0) # 银行之所有者权益变动
        update_B_state!(BB, BI; to = "insolvent", from = "healthy") # 更新各银行之状态，从健康到资不抵债
        # update_B_state!(BB, BI; to = "bankrupt", from = "insolvent") # 更新各银行之状态，从资不抵债到破产
        # update_B_balanceSheet!(BB, BI,a,ia; byWay = "E_all and A_all") #HACK冗余，可以删除
        BB.Z_BI_all[BB.isInsolvent] = BB_t1.Z_BI_all[BB.isInsolvent] - ((BB.Shock_B_A[BB.isInsolvent] - BB_t1.E_all[BB.isInsolvent]) ./ (BB_t1.Z_BI_all[BB.isInsolvent] + BB_t1.Z_D[BB.isInsolvent]) .* BB_t1.Z_BI_all[BB.isInsolvent]) # 银行间负债变动，由于违约
        update_B_balanceSheet!(BB, BI, a, ia; byWay = "Z_BI_all") # 更新资产负债表，通过Z_D或Z_BI_all
        BB.Z_D[BB.isInsolvent] = BB_t1.Z_D[BB.isInsolvent] - ((BB.Shock_B_A[BB.isInsolvent] - BB_t1.E_all[BB.isInsolvent]) ./ (BB_t1.Z_BI_all[BB.isInsolvent] + BB_t1.Z_D[BB.isInsolvent]) .* BB_t1.Z_D[BB.isInsolvent]) # 存款负债变动，由于违约
        update_B_balanceSheet!(BB, BI, a, ia; byWay = "Z_D") # 更新资产负债表，通过Z_D或Z_BI_all
        BB.Shock_BI_def_s[BB.isInsolvent] = abs.(BB.Z_BI_all[BB.isInsolvent] - BB_t1.Z_BI_all[BB.isInsolvent]) # 银行内冲击传导至银行间传染冲击
        update_B_Shock!(BB, BI, a, ia; byWay = "Shock_BI_def_s") # 汇总各银行之倒闭流动性挤兑冲击、违约损失冲击
        BB.Shock_D_s[BB.isInsolvent] = abs.(BB.Z_D[BB.isInsolvent] - BB_t1.Z_D[BB.isInsolvent]) # 银行内冲击传导至银行存款传染冲击
        # i0 = (BB.isBankrupt .&& BB.isInsolvent) # 计算状态之于银行集合其满足破产和资不抵债
        # BB.Shock_BI_run_br_s[i0] = BB.A_BI_all[i0] # 资不抵债的和银行内冲击传导至银行倒闭冲击
        # update_B_Shock!(BB, BI,a,ia; byWay = "Shock_BI_run_br_s") # 汇总各银行之倒闭流动性挤兑冲击、违约损失冲击


        ## ## 尾声阶段$t_{4}$：
        println("t4 开始尾声阶段")

        # update_B_state!(BB, BI; to = "bankrupt", from = "insolvent") # 更新各银行之状态到破产

        ## TODO存储数据
        BB_tau[tau] = deepcopy(BB) # 存储该轮次传染结果数据
        BI_tau[tau] = deepcopy(BI) # 存储该轮次传染结果数据

        ## 清零银行内冲击变量
        update_B_Shock!(BB, BI, a, ia; byWay = "clear Shock_B") # 清零银行内资产负债冲击



        ## 判定本回合是否有银行转移状态，如果无则后续处理然后结束本轮，如果有则继续处理。
        if BB.isInsolvent == BB_t1.isInsolvent
            isEnd = true
            break
        end


    end # while 子过程：违约损失冲击传染


    ## # 子过程：外部挤兑流动冲击
    println("子过程：外部挤兑流动冲击")

    ## 初始化
    tau = 0 # 初始化传染轮次
    isEnd = false # 初始化结束判断

    tau += 1 # 传染回合累加一
    println("开始回合$tau")

    ## ## 初始阶段$t_{0}$，当$\tau=1$时：
    println("t0 初始阶段")

    on = BB.isOn # 临时设置BB有存在的示性变量
    a = TypeState{1}(BB.isOn .|| BB.isOff) # 临时设置BB示性变量
    ia = TypeState{2}((BB.isOn .|| BB.isOff) .&& (BB.isOn .|| BB.isOff)') # 临时设置BI示性变量

    ## ## 初始外生传染冲击阶段$t_{1}$，当$\tau=1$时：
    println("t1 开始外生传染冲击阶段")

    ## ### 初始外生挤兑流动冲击传染：
    println("t1-2 初始外生挤兑流动冲击传染")
    if p.theta_Shock_exBI_t == 0.0
        update_B_Shock!(BB, BI, a, ia; byWay = "Shock_D_t") # 生成综合外生冲击
        BB.Shock_B_Z[a] = BB.Shock_D_t[a] # 银行外冲击传导至银行内负债冲击
        update_B_Shock!(BB, BI, a, ia; byWay = "Shock_B_Z")
    elseif p.theta_Shock_exBI_t != 1.0
        throw(DomainError(p.theta_Shock_exBI_t, "参数暂时只能取值1或者0！"))
    end

    ## ## 初始外生冲击阶段$t_{2}$，当$\tau=1$时：
    println("t2 开始外生冲击阶段")

    ## ### 初始化：
    println("t2-0 初始化")

    ## 设置临时变量
    BB_t1 = deepcopy(BB) # 临时设置BB变量，被读取于阶段1
    BI_t1 = deepcopy(BI) # 临时设置BI变量，被读取于阶段1

    ## 清零银行间和银行外冲击变量
    update_B_Shock!(BB, BI, a, ia; byWay = "clear Shock_BI and Shock_exBI")

    ## ### 银行存款挤兑流动冲击：
    println("t2-2 银行存款挤兑流动冲击")
    if p.theta_Shock_exBI_t == 0.0
        BB.Z_D[a] -= BB.Shock_B_Z[a] # 存款负债变动
        update_B_balanceSheet!(BB, BI, a, ia; byWay = "Z_D")
        BB.A_Q[a] = max.(BB.A_Q[a] - BB.Shock_B_Z[a], 0.0) # 流动资产变动
        update_B_balanceSheet!(BB, BI, a, ia; byWay = "A_Q")
        update_B_state!(BB, BI; to = "illiquity", from = "healthy") # 更新各银行之状态，从健康到流动性短缺
        # update_B_state!(BB, BI; to = "bankrupt", from = "illiquity") # 更新各银行之状态，从流动性短缺到破产
        BB.A_BI_all[BB.isIlliquity] = BB_t1.A_BI_all[BB.isIlliquity] - ((BB.Shock_B_Z[BB.isIlliquity] - BB_t1.A_Q[BB.isIlliquity]) ./ (BB_t1.A_P[BB.isIlliquity] + BB_t1.A_BI_all[BB.isIlliquity]) .* BB_t1.A_BI_all[BB.isIlliquity]) # 银行间资产应变动，由于回收资产
        update_B_balanceSheet!(BB, BI, a, ia; byWay = "A_BI_all") # 更新资产负债表，通过A_BI_all
        BB.Shock_BI_run_ilq_s[BB.isIlliquity] = abs.(BB.A_BI_all[BB.isIlliquity] - BB_t1.A_BI_all[BB.isIlliquity]) # 银行内冲击传导至银行间传染冲击
        update_B_Shock!(BB, BI, a, ia; byWay = "Shock_BI_run_ilq_s") # 汇总各银行之流动性短缺流动性挤兑冲击
        BB.A_P[BB.isIlliquity] = BB_t1.A_P[BB.isIlliquity] - ((BB.Shock_B_Z[BB.isIlliquity] - BB_t1.A_Q[BB.isIlliquity]) ./ (BB_t1.A_P[BB.isIlliquity] + BB_t1.A_BI_all[BB.isIlliquity]) .* BB_t1.A_P[BB.isIlliquity]) # 非银行间贷款资产应变动，由于回收资产
        update_B_balanceSheet!(BB, BI, a, ia; byWay = "A_P") # 更新资产负债表，通过A_P
        BB.Shock_L_exBI_s[BB.isIlliquity] = abs.(BB.A_P[BB.isIlliquity] - BB_t1.A_P[BB.isIlliquity]) # 银行内冲击传导至银行厂商贷款传染冲击
    elseif p.theta_Shock_exBI_t != 1.0
        throw(DomainError(p.theta_Shock_exBI_t, "参数暂时只能取值1或者0！"))
    end



    ## ## 尾声阶段$t_{4}$：
    println("t4 开始尾声阶段")

    ## TODO存储数据
    BB_tau[tau] = deepcopy(BB) # 存储该轮次传染结果数据
    BI_tau[tau] = deepcopy(BI) # 存储该轮次传染结果数据

    ## 清零银行内冲击变量
    update_B_Shock!(BB, BI, a, ia; byWay = "clear Shock_B")

    ## 判定本回合是否有银行转移状态，如果无则后续处理然后结束本轮，如果有则继续处理。
    if BB.isIlliquity == BB_t1.isIlliquity
        isEnd = true
    end

    ## # 子过程：流动性短缺银行间挤兑流动冲击传染
    println("子过程：流动性短缺银行间挤兑流动冲击传染")
    while (tau <= p.max_num_tau .&& isEnd != true) # 循环，当回合$\tau>1$时：

        tau += 1 # 传染回合累加一
        println("开始回合$tau")

        ## # 初始阶段$t_{0}$，当$\tau>1$时：
        println("t0 初始阶段")

        on = BB.isOn # 临时设置BB有存在的示性变量
        a = TypeState{1}(BB.isOn .|| BB.isOff) # 临时设置BB示性变量
        ia = TypeState{2}((BB.isOn .|| BB.isOff) .&& (BB.isOn .|| BB.isOff)') # 临时设置BI示性变量


        ## ## 银行间传染冲击阶段$t_{1}$，当$\tau>1$时：
        println("t1 开始银行间传染冲击阶段")

        ## ### 流动性短缺银行银行间挤兑流动冲击传染方式 $i_{ilq} \stackrel{BI,run}{\longrightarrow} k_{deb}$：
        println("t1-2 流动性短缺银行银行间挤兑流动冲击传染方式")
        ilq = BB.isIlliquity # 临时设置BB流动性短缺的示性变量，在阶段1
        deb_ilq = BI.listOfDebtors # 临时设置BI之列表之于银行之债务方银行编号
        for i in findall(ilq) # 流动性短缺银行收回资产，导致其对各债务银行之资产变动，造成流动性短缺银行间挤兑流动冲击
            BI.A_BI[i, deb_ilq[i]] .*= (1.0 - BB.Shock_BI_run_ilq_s[i] ./ BB_t1.A_BI_all[i])
            BI.Shock_BI_run_ilq[deb_ilq[i], i] = BI_t1.A_BI[i, deb_ilq[i]] .* BB.Shock_BI_run_ilq_s[i] ./ BB_t1.A_BI_all[i] # 注意这里用BI.A_BI而非BI.Z_BI是因为转换资产负债表过程被放在后面了
        end
        # HACK以下部分是否提取出来在阶段1结束之前使用
        update_B_balanceSheet!(BB, BI, a, ia; byWay = "alter from A_BI") # 转换银行间资产负债邻接矩阵
        update_B_Shock!(BB, BI, a, ia; byWay = "Shock_BI_run_ilq") # 加总各单个债务银行遭受总银行间挤兑流动冲击
        # BB.A_BI_all[a] -= BB.Shock_BI_run_ilq_t[a] # HACK（仅作说明）各流动性短缺银行对应债务银行之银行间负债变动（不是在此处出现，而是在银行内冲击阶段出现）。可以删除。
        BB.Shock_B_Z[a] = BB.Shock_BI_run_t[a] # 银行间冲击传导为银行内冲击
        update_B_Shock!(BB, BI, a, ia; byWay = "Shock_B_Z") # 汇总各银行之银行内资产负债冲击


        ## ## 银行资产负债冲击阶段$t_{2}$，当$\tau>1$时：
        println("t2 开始银行资产负债冲击阶段")

        ## ### 初始化：
        println("t2-0 初始化")

        ## 清零银行间和银行外冲击变量
        update_B_Shock!(BB, BI, a, ia; byWay = "clear Shock_BI and Shock_exBI") # 清零各银行之不必要的冲击变量，被使用于下一回合，从第二回合开始

        ## ### 银行内负债冲击：
        println("t2-2 银行内负债冲击")

        ## 设置临时变量
        BB_t1 = deepcopy(BB) # 临时设置BB变量，被读取于本回合之银行资产冲击
        BI_t1 = deepcopy(BI) # 临时设置BI变量，被读取于本回合之银行资产冲击

        i1 = (on .&& ((BB.Z_D - BB.Shock_D_s) + ((BB.Z_BI_all - BB.Shock_BI_def_s)) .< BB.Shock_B_Z)) # 计算条件之于银行集合其满足其应违约但是应被收回
        BB.Shock_B_Z[i1] = (BB.Shock_D_s[i1] + BB.Shock_BI_def_s[i1]) - (BB.Z_D[i1] + BB.Z_BI_all[i1]) # 更新遭受实际银行内负债冲击
        update_B_Shock!(BB, BI, a, ia; byWay = "Shock_B_Z")
        update_B_state!(BB, BI; to = "illiquity", from = "healthy")
        BB.Z_BI_all[a] = max.(BB.Z_BI_all[a] - BB.Shock_B_Z[a], 0.0) # 银行之银行间负债变动
        update_B_balanceSheet!(BB, BI, a, ia; byWay = "Z_BI_all")
        BB.A_Q[a] = max.(BB.A_Q[a] - BB.Shock_B_Z[a], 0.0) # 银行之流动资产变动
        update_B_state!(BB, BI; to = "illiquity", from = "healthy") # 更新各银行之状态，从健康到流动性短缺
        # update_B_state!(BB, BI; to = "bankrupt", from = "illiquity") # 更新各银行之状态，从流动性短缺到破产
        update_B_balanceSheet!(BB, BI, a, ia; byWay = "A_Q")
        BB.A_BI_all[BB.isIlliquity] = BB_t1.A_BI_all[BB.isIlliquity] - ((BB.Shock_B_Z[BB.isIlliquity] - BB_t1.A_Q[BB.isIlliquity]) ./ (BB_t1.A_P[BB.isIlliquity] + BB_t1.A_BI_all[BB.isIlliquity]) .* BB_t1.A_BI_all[BB.isIlliquity]) # 银行间资产应变动，由于回收资产
        update_B_balanceSheet!(BB, BI, a, ia; byWay = "A_BI_all") # 更新资产负债表，通过A_P或A_BI_all
        BB.Shock_BI_run_ilq_s[BB.isIlliquity] = abs.(BB.A_BI_all[BB.isIlliquity] - BB_t1.A_BI_all[BB.isIlliquity]) # 计算应银行内冲击传导至银行间传染冲击
        update_B_Shock!(BB, BI, a, ia; byWay = "Shock_BI_run_ilq_s") # 汇总各银行之流动性短缺流动性挤兑冲击
        BB.A_P[BB.isIlliquity] = BB_t1.A_P[BB.isIlliquity] - ((BB.Shock_B_Z[BB.isIlliquity] - BB_t1.A_Q[BB.isIlliquity]) ./ (BB_t1.A_P[BB.isIlliquity] + BB_t1.A_BI_all[BB.isIlliquity]) .* BB_t1.A_P[BB.isIlliquity]) # 非银行间贷款资产应变动，由于回收资产
        update_B_balanceSheet!(BB, BI, a, ia; byWay = "A_P") # 更新资产负债表，通过A_P或A_BI_all
        BB.Shock_L_exBI_s[BB.isIlliquity] = abs.(BB.A_P[BB.isIlliquity] - BB_t1.A_P[BB.isIlliquity]) # 银行内冲击传导至银行厂商贷款传染冲击
        # i0 = (BB.isBankrupt .&& BB.isIlliquity) # 计算状态之于银行集合其满足破产和流动性短缺
        # BB.Shock_BI_run_br_s[i0] = BB.A_BI_all[i0] # 流动性短缺的银行内冲击传导至银行倒闭冲击
        # update_B_Shock!(BB, BI,a,ia; byWay = "Shock_BI_run_br_s") # 汇总各银行之倒闭流动性挤兑冲击



        ## ## 尾声阶段$t_{4}$：
        println("t4 开始尾声阶段")

        # update_B_state!(BB, BI; to = "bankrupt", from = "illiquity") # 更新各银行之状态到破产

        ## TODO存储数据
        BB_tau[tau] = deepcopy(BB) # 存储该轮次传染结果数据
        BI_tau[tau] = deepcopy(BI) # 存储该轮次传染结果数据

        ## 清零银行内冲击变量
        update_B_Shock!(BB, BI, a, ia; byWay = "clear Shock_B") # 清零银行内资产负债冲击

        ## 判定本回合是否有银行转移状态，如果无则后续处理然后结束本轮，如果有则继续处理。
        if BB.isIlliquity == BB_t1.isIlliquity
            isEnd = true
            break
        end


    end # while # 子过程：流动性短缺银行间挤兑流动冲击传染





    ## # 子过程：外生破产银行间挤兑流动冲击传染 #TODO增加参数，判断是否增加外生冲击。 #HACK这个过程可以暂时不使用。
    println("子过程：破产银行间挤兑流动冲击传染")

    ## ## 初始外生冲击破产召回阶段$t_{3}$：，当$\tau=1$时：
    println("t3 开始破产召回阶段")

    if BB_t0.isBankrupt != FALSE1 # 当最初存在已经判定倒闭的银行时执行以下过程
        BB_t1 = deepcopy(BB) # 临时设置BB变量，被读取于阶段1
        BI_t1 = deepcopy(BI) # 临时设置BI变量，被读取于阶段1
        BB.Shock_BI_run_br_s[BB.isBankrupt], BB.A_BI_all[BB.isBankrupt] = transfer_B_capital(BB.Shock_BI_run_br_s[BB.isBankrupt], BB.A_BI_all[BB.isBankrupt], BB.A_BI_all[BB.isBankrupt]) # 转移破产银行之资产变动，并且银行内冲击传导至银行倒闭挤兑流动冲击
        BB.Shock_L_exBI_s[BB.isBankrupt], BB.A_P[BB.isBankrupt] = transfer_B_capital(BB.Shock_L_exBI_s[BB.isBankrupt], BB.A_P[BB.isBankrupt], BB.A_P[BB.isBankrupt]) # 非银行间贷款资产应变动，由于回收资产，并且银行内冲击传导至银行厂商贷款传染冲击
        update_B_Shock!(BB, BI, a, ia; byWay = "Shock_BI_run_br_s") # 汇总各银行之倒闭流动性挤兑冲击
        update_B_state!(BB, BI; to = "off", from = "bankrupt") # 更新各银行之状态，从破产到退出
    end # if

    ## ## 外生破产银行银行间挤兑流动冲击传染：
    println("t1-3 外生破产银行银行间挤兑流动冲击传染")
    if BB_t0.isBankrupt != FALSE1 # 当最初存在已经判定倒闭的银行时执行以下过程
        update_B_state!(BB, BI; to = "bankrupt", from = "any") # 更新示性向量之于破产银行状态
        br = BB.isBankrupt # 临时设置破产银行示性变量
        deb_br = BI.listOfDebtors # 临时设置BI之列表之于银行之债务方银行编号
        for i in findall(br) # 破产银行收回其银行间资产，用于后续偿还其银行间负债。此举导致其对各债务银行之资产变动，造成破产银行银行间挤兑流动冲击
            BI.Shock_BI_run_br[deb_br[i], i], BI.A_BI[i, deb_br[i]] = transfer_B_capital(BI.Shock_BI_run_br[deb_br[i], i], BI.A_BI[i, deb_br[i]], BI.A_BI[i, deb_br[i]])
        end
        # HACK以下部分是否提取出来在阶段1结束之前使用
        update_B_balanceSheet!(BB, BI, a, ia; byWay = "alter from A_BI") # 转换银行间资产负债邻接矩阵
        update_B_Shock!(BB, BI, a, ia; byWay = "Shock_BI_run_br") # 加总各单个债务银行遭受总银行间挤兑流动冲击
        BB.Shock_B_Z[a] = BB.Shock_BI_run_t[a] # 银行间冲击传导为银行内冲击
        update_B_Shock!(BB, BI, a, ia; byWay = "Shock_B_Z") # 更新各银行之冲击变量，通过银行内负债冲击

        # update_B_state!(BB, BI; to = "off", from = "bankrupt") # 更新各银行之状态，从破产到退出
    end # if


    while #NOW # 




    ## # 子过程：破产银行间挤兑流动冲击传染 #BUG
    println("子过程：破产银行间挤兑流动冲击传染")

        ## 初始化
        tau = 0 # 初始化传染轮次
        isEnd = false # 初始化结束判断

        tau += 1 # 传染回合累加一
        println("开始回合$tau")

        ## ## 初始阶段$t_{0}$，当$\tau=1$时：
        println("t0 初始阶段")

        on = BB.isOn # 临时设置BB有存在的示性变量
        a = TypeState{1}(BB.isOn .|| BB.isOff) # 临时设置BB示性变量
        ia = TypeState{2}((BB.isOn .|| BB.isOff) .&& (BB.isOn .|| BB.isOff)') # 临时设置BI示性变量


        ## ## 破产资产负债冲击阶段$t_{3}$：，当$\tau=1$时：
        println("t3 开始破产召回阶段")

        ## ### 初始化：
        println("t2-0 初始化")

        ## 设置临时变量
        BB_t1 = deepcopy(BB)
        BI_t1 = deepcopy(BI)

        ## 清零银行间和银行外冲击变量
        update_B_Shock!(BB, BI, a, ia; byWay = "clear Shock_BI and Shock_exBI")

        ## ## 破产召回阶段$t_{3}$：，当$\tau=1$时：
        println("t3 开始破产召回阶段")
        update_B_state!(BB, BI; to = "bankrupt", from = "any") # 更新示性向量之于破产银行状态
        BB.Shock_BI_run_br_s[BB.isBankrupt], BB.A_BI_all[BB.isBankrupt] = transfer_B_capital(BB.Shock_BI_run_br_s[BB.isBankrupt], BB.A_BI_all[BB.isBankrupt], BB.A_BI_all[BB.isBankrupt]) # 转移破产银行之资产变动，并且银行内冲击传导至银行倒闭挤兑流动冲击
        update_B_Shock!(BB, BI, a, ia; byWay = "Shock_BI_run_br_s") # 汇总各银行之倒闭流动性挤兑冲击
        BB.Shock_L_exBI_s[BB.isBankrupt], BB.A_P[BB.isBankrupt] = transfer_B_capital(BB.Shock_L_exBI_s[BB.isBankrupt], BB.A_P[BB.isBankrupt], BB.A_P[BB.isBankrupt]) # 非银行间贷款资产应变动，由于回收资产，并且银行内冲击传导至银行厂商贷款传染冲击
        # update_B_state!(BB, BI; to = "off", from = "bankrupt") # 更新各银行之状态，从破产到退出

        ## ## 尾声阶段$t_{4}$：
        println("t4 开始尾声阶段")

        ## TODO存储数据
        BB_tau[tau] = deepcopy(BB) # 存储该轮次传染结果数据
        BI_tau[tau] = deepcopy(BI) # 存储该轮次传染结果数据

        ## 清零银行内冲击变量
        update_B_Shock!(BB, BI, a, ia; byWay = "clear Shock_B") # 清零银行内资产负债冲击

        ## 判定本回合是否有银行转移状态，如果无则后续处理然后结束本轮，如果有则继续处理。
        if BB.isBankrupt == BB_t1.isBankrupt
            isEnd = true
        end

        ## # 子过程：流动性短缺银行间挤兑流动冲击传染
        println("子过程：流动性短缺银行间挤兑流动冲击传染")
        while (tau <= p.max_num_tau .&& isEnd != true) # 循环，当回合$\tau>1$时：

            tau += 1 # 传染回合累加一
            println("开始回合$tau")

            ## # 初始阶段$t_{0}$，当$\tau>1$时：
            println("t0 初始阶段")

            on = BB.isOn # 临时设置BB有存在的示性变量
            a = TypeState{1}(BB.isOn .|| BB.isOff) # 临时设置BB示性变量
            ia = TypeState{2}((BB.isOn .|| BB.isOff) .&& (BB.isOn .|| BB.isOff)') # 临时设置BI示性变量


            ## ## 银行间传染冲击阶段$t_{1}$，当$\tau>1$时：
            println("t1 开始银行间传染冲击阶段")

            ## ### 流动性短缺银行银行间挤兑流动冲击传染方式 $i_{ilq} \stackrel{BI,run}{\longrightarrow} k_{deb}$：
            println("t1-2 流动性短缺银行银行间挤兑流动冲击传染方式")
            ilq = BB.isIlliquity # 临时设置BB流动性短缺的示性变量，在阶段1
            deb_ilq = BI.listOfDebtors # 临时设置BI之列表之于银行之债务方银行编号
            for i in findall(ilq) # 流动性短缺银行收回资产，导致其对各债务银行之资产变动，造成流动性短缺银行间挤兑流动冲击
                BI.A_BI[i, deb_ilq[i]] .*= (1.0 - BB.Shock_BI_run_ilq_s[i] ./ BB_t1.A_BI_all[i])
                BI.Shock_BI_run_ilq[deb_ilq[i], i] = BI_t1.A_BI[i, deb_ilq[i]] .* BB.Shock_BI_run_ilq_s[i] ./ BB_t1.A_BI_all[i] # 注意这里用BI.A_BI而非BI.Z_BI是因为转换资产负债表过程被放在后面了
            end
            # HACK以下部分是否提取出来在阶段1结束之前使用
            update_B_balanceSheet!(BB, BI, a, ia; byWay = "alter from A_BI") # 转换银行间资产负债邻接矩阵
            update_B_Shock!(BB, BI, a, ia; byWay = "Shock_BI_run_ilq") # 加总各单个债务银行遭受总银行间挤兑流动冲击
            # BB.A_BI_all[a] -= BB.Shock_BI_run_ilq_t[a] # HACK（仅作说明）各流动性短缺银行对应债务银行之银行间负债变动（不是在此处出现，而是在银行内冲击阶段出现）。可以删除。
            BB.Shock_B_Z[a] = BB.Shock_BI_run_t[a] # 银行间冲击传导为银行内冲击
            update_B_Shock!(BB, BI, a, ia; byWay = "Shock_B_Z") # 汇总各银行之银行内资产负债冲击


            ## ## 银行资产负债冲击阶段$t_{2}$，当$\tau>1$时：
            println("t2 开始银行资产负债冲击阶段")

            ## ### 初始化：
            println("t2-0 初始化")

            ## 清零银行间和银行外冲击变量
            update_B_Shock!(BB, BI, a, ia; byWay = "clear Shock_BI and Shock_exBI") # 清零各银行之不必要的冲击变量，被使用于下一回合，从第二回合开始

            ## ### 银行内负债冲击：
            println("t2-2 银行内负债冲击")

            ## 设置临时变量
            BB_t1 = deepcopy(BB) # 临时设置BB变量，被读取于本回合之银行资产冲击
            BI_t1 = deepcopy(BI) # 临时设置BI变量，被读取于本回合之银行资产冲击

            i1 = (on .&& ((BB.Z_D - BB.Shock_D_s) + ((BB.Z_BI_all - BB.Shock_BI_def_s)) .< BB.Shock_B_Z)) # 计算条件之于银行集合其满足其应违约但是应被收回
            BB.Shock_B_Z[i1] = (BB.Shock_D_s[i1] + BB.Shock_BI_def_s[i1]) - (BB.Z_D[i1] + BB.Z_BI_all[i1]) # 更新遭受实际银行内负债冲击
            update_B_Shock!(BB, BI, a, ia; byWay = "Shock_B_Z")
            update_B_state!(BB, BI; to = "illiquity", from = "healthy")
            BB.Z_BI_all[a] = max.(BB.Z_BI_all[a] - BB.Shock_B_Z[a], 0.0) # 银行之银行间负债变动
            update_B_balanceSheet!(BB, BI, a, ia; byWay = "Z_BI_all")
            BB.A_Q[a] = max.(BB.A_Q[a] - BB.Shock_B_Z[a], 0.0) # 银行之流动资产变动
            update_B_state!(BB, BI; to = "illiquity", from = "healthy") # 更新各银行之状态，从健康到流动性短缺
            # update_B_state!(BB, BI; to = "bankrupt", from = "illiquity") # 更新各银行之状态，从流动性短缺到破产
            update_B_balanceSheet!(BB, BI, a, ia; byWay = "A_Q")
            BB.A_BI_all[BB.isIlliquity] = BB_t1.A_BI_all[BB.isIlliquity] - ((BB.Shock_B_Z[BB.isIlliquity] - BB_t1.A_Q[BB.isIlliquity]) ./ (BB_t1.A_P[BB.isIlliquity] + BB_t1.A_BI_all[BB.isIlliquity]) .* BB_t1.A_BI_all[BB.isIlliquity]) # 银行间资产应变动，由于回收资产
            update_B_balanceSheet!(BB, BI, a, ia; byWay = "A_BI_all") # 更新资产负债表，通过A_P或A_BI_all
            BB.Shock_BI_run_ilq_s[BB.isIlliquity] = abs.(BB.A_BI_all[BB.isIlliquity] - BB_t1.A_BI_all[BB.isIlliquity]) # 计算应银行内冲击传导至银行间传染冲击
            update_B_Shock!(BB, BI, a, ia; byWay = "Shock_BI_run_ilq_s") # 汇总各银行之流动性短缺流动性挤兑冲击
            BB.A_P[BB.isIlliquity] = BB_t1.A_P[BB.isIlliquity] - ((BB.Shock_B_Z[BB.isIlliquity] - BB_t1.A_Q[BB.isIlliquity]) ./ (BB_t1.A_P[BB.isIlliquity] + BB_t1.A_BI_all[BB.isIlliquity]) .* BB_t1.A_P[BB.isIlliquity]) # 非银行间贷款资产应变动，由于回收资产
            update_B_balanceSheet!(BB, BI, a, ia; byWay = "A_P") # 更新资产负债表，通过A_P或A_BI_all
            BB.Shock_L_exBI_s[BB.isIlliquity] = abs.(BB.A_P[BB.isIlliquity] - BB_t1.A_P[BB.isIlliquity]) # 银行内冲击传导至银行厂商贷款传染冲击
            # i0 = (BB.isBankrupt .&& BB.isIlliquity) # 计算状态之于银行集合其满足破产和流动性短缺
            # BB.Shock_BI_run_br_s[i0] = BB.A_BI_all[i0] # 流动性短缺的银行内冲击传导至银行倒闭冲击
            # update_B_Shock!(BB, BI,a,ia; byWay = "Shock_BI_run_br_s") # 汇总各银行之倒闭流动性挤兑冲击



            ## ## 尾声阶段$t_{4}$：
            println("t4 开始尾声阶段")

            # update_B_state!(BB, BI; to = "bankrupt", from = "illiquity") # 更新各银行之状态到破产

            ## TODO存储数据
            BB_tau[tau] = deepcopy(BB) # 存储该轮次传染结果数据
            BI_tau[tau] = deepcopy(BI) # 存储该轮次传染结果数据

            ## 清零银行内冲击变量
            update_B_Shock!(BB, BI, a, ia; byWay = "clear Shock_B") # 清零银行内资产负债冲击

            ## 判定本回合是否有银行转移状态，如果无则后续处理然后结束本轮，如果有则继续处理。
            if BB.isIlliquity == BB_t1.isIlliquity
                isEnd = true
                break
            end


        end # while # 子过程：流动性短缺银行间挤兑流动冲击传染


        # ## 循环，当回合$\tau>1$时：
        # while (tau <= p.max_num_tau .&& isEnd != true)

        #     tau += 1 # 传染回合累加一
        #     println("开始回合$tau")

        #     ## ## 初始阶段$t_{0}$，当$\tau>1$时：
        #     println("t0 初始阶段")

        #     on = BB.isOn # 临时设置BB有存在的示性变量
        #     a = TypeState{1}(BB.isOn .|| BB.isOff) # 临时设置BB示性变量
        #     ia = TypeState{2}((BB.isOn .|| BB.isOff) .&& (BB.isOn .|| BB.isOff)') # 临时设置BI示性变量

        #     ## ## 银行间传染冲击阶段$t_{1}$，当$\tau>1$时：
        #     println("t1 开始银行间传染冲击阶段")

        #     # ## ### 流动性短缺银行银行间挤兑流动冲击传染方式 $i_{ilq} \stackrel{BI,run}{\longrightarrow} k_{deb}$：
        #     # println("t1-2 流动性短缺银行银行间挤兑流动冲击传染方式")
        #     # ilq = BB.isIlliquity # 临时设置BB流动性短缺的示性变量，在阶段1
        #     # deb_ilq = BI.listOfDebtors # 临时设置BI之列表之于银行之债务方银行编号
        #     # for i in findall(ilq) # 流动性短缺银行收回资产，导致其对各债务银行之资产变动，造成流动性短缺银行间挤兑流动冲击
        #     #     BI.A_BI[i, deb_ilq[i]] = BI_t1.A_BI[i, deb_ilq[i]] .* (1.0 - BB.Shock_BI_run_ilq_s[i] ./ BB_t1.A_BI_all[i])
        #     #     BI.Shock_BI_run_ilq[deb_ilq[i], i] = BI_t1.A_BI[i, deb_ilq[i]] .* BB.Shock_BI_run_ilq_s[i] ./ BB_t1.A_BI_all[i] # 注意这里用BI.A_BI而非BI.Z_BI是因为转换资产负债表过程被放在后面了
        #     # end
        #     # # HACK以下部分是否提取出来在阶段1结束之前使用
        #     # update_B_balanceSheet!(BB, BI, a, ia; byWay = "alter from A_BI") # 转换银行间资产负债邻接矩阵
        #     # update_B_Shock!(BB, BI, a, ia; byWay = "Shock_BI_run_ilq") # 加总各单个债务银行遭受总银行间挤兑流动冲击
        #     # # BB.A_BI_all[a] -= BB.Shock_BI_run_ilq_t[a] # HACK（仅作说明）各流动性短缺银行对应债务银行之银行间负债变动（不是在此处出现，而是在银行内冲击阶段出现）。可以删除。
        #     # BB.Shock_B_Z[a] = BB.Shock_BI_run_t[a] # 银行间冲击传导为银行内冲击
        #     # update_B_Shock!(BB, BI, a, ia; byWay = "Shock_B_Z") # 汇总各银行之银行内资产负债冲击

        #     ## ### 破产银行银行间挤兑流动冲击传染方式 $i_{br} \stackrel{BI,run}{\longrightarrow} k_{deb}$：
        #     println("t1-3 破产银行银行间挤兑流动冲击传染方式")
        #     br = BB.isBankrupt # 临时设置BB破产的示性变量
        #     deb_br = BI.listOfDebtors # 临时设置BI之列表之于银行之债务方银行编号
        #     for i in findall(br) # 破产银行收回其银行间资产，用于后续偿还其银行间负债。此举导致其对各债务银行之资产变动，造成破产银行银行间挤兑流动冲击
        #         BI.A_BI[i, deb_br[i]] = BI_t1.A_BI[i, deb_br[i]] .* (1.0 - BB.Shock_BI_run_br_s[i] ./ BB_t1.A_BI_all[i])
        #         BI.Shock_BI_run_br[deb_br[i], i] = BI_t1.A_BI[i, deb_br[i]] .* BB.Shock_BI_run_br_s[i] ./ BB_t1.A_BI_all[i] # 注意这里用BI.A_BI而非BI.Z_BI是因为转换资产负债表过程被放在后面了
        #         # BI.Shock_BI_run_br[deb_br[i], i], BI.A_BI[i, deb_br[i]] = transfer_B_capital(BI.Shock_BI_run_br[deb_br[i], i], BI.A_BI[i, deb_br[i]], BI.A_BI[i, deb_br[i]])
        #     end
        #     # HACK以下部分是否提取出来在阶段1结束之前使用
        #     update_B_balanceSheet!(BB, BI, a, ia; byWay = "alter from A_BI") # 转换银行间资产负债邻接矩阵
        #     update_B_Shock!(BB, BI, a, ia; byWay = "Shock_BI_run_br") # 加总各单个债务银行遭受总银行间挤兑流动冲击
        #     # BB.A_BI_all[a] -= BB.Shock_BI_run_br_t[a] # HACK（仅作说明）各流动性短缺银行对应债务银行之银行间负债变动（不是在此处出现，在银行内冲击阶段出现）。可以删除。
        #     BB.Shock_B_Z[a] = BB.Shock_BI_run_t[a] # 银行间冲击传导为银行内冲击
        #     update_B_Shock!(BB, BI, a, ia; byWay = "Shock_B_Z") # 更新各银行之冲击变量，通过银行内负债冲击

        #     # update_B_state!(BB, BI; to = "off", from = "bankrupt") # 更新各银行之状态，从破产到退出


        #     ## ## 银行资产负债冲击阶段$t_{2}$，当$\tau>1$时：
        #     println("t2 开始银行资产负债冲击阶段")


        #     ## ### 初始化：
        #     println("t2-0 初始化")

        #     ## ### 银行内负债冲击：
        #     println("t2-2 银行内负债冲击")

        #     ## 设置临时变量
        #     BB_t1 = deepcopy(BB) # 临时设置BB变量
        #     BI_t1 = deepcopy(BI) # 临时设置BI变量

        #     i1 = (on .&& ((BB.Z_D - BB.Shock_D_s) + ((BB.Z_BI_all - BB.Shock_BI_def_s)) .< BB.Shock_B_Z)) # 计算条件之于银行集合其满足其应违约但是应被收回
        #     BB.Shock_B_Z[i1] = (BB.Shock_D_s[i1] + BB.Shock_BI_def_s[i1]) - (BB.Z_D[i1] + BB.Z_BI_all[i1]) # 更新遭受实际银行内负债冲击
        #     update_B_Shock!(BB, BI, a, ia; byWay = "Shock_B_Z")
        #     update_B_state!(BB, BI; to = "illiquity", from = "healthy")
        #     BB.Z_BI_all[a] = max.(BB.Z_BI_all[a] - BB.Shock_B_Z[a], 0.0) # 银行之银行间负债变动
        #     update_B_balanceSheet!(BB, BI, a, ia; byWay = "Z_BI_all")
        #     BB.A_Q[a] = max.(BB.A_Q[a] - BB.Shock_B_Z[a], 0.0) # 银行之流动资产变动
        #     update_B_state!(BB, BI; to = "illiquity", from = "healthy") # 更新各银行之状态，从健康到破产
        #     # update_B_state!(BB, BI; to = "bankrupt", from = "illiquity") # 更新各银行之状态，从健康到破产
        #     update_B_balanceSheet!(BB, BI, a, ia; byWay = "A_Q")
        #     BB.A_BI_all[BB.isIlliquity] = BB_t1.A_BI_all[BB.isIlliquity] - ((BB.Shock_B_Z[BB.isIlliquity] - BB_t1.A_Q[BB.isIlliquity]) ./ (BB_t1.A_P[BB.isIlliquity] + BB_t1.A_BI_all[BB.isIlliquity]) .* BB_t1.A_BI_all[BB.isIlliquity]) # 银行间资产应变动，由于回收资产
        #     update_B_balanceSheet!(BB, BI, a, ia; byWay = "A_BI_all") # 更新资产负债表，通过A_P或A_BI_all
        #     BB.Shock_BI_run_ilq_s[BB.isIlliquity] = abs.(BB.A_BI_all[BB.isIlliquity] - BB_t1.A_BI_all[BB.isIlliquity]) # 计算应银行内冲击传导至银行间传染冲击
        #     update_B_Shock!(BB, BI, a, ia; byWay = "Shock_BI_run_ilq_s") # 汇总各银行之流动性短缺流动性挤兑冲击
        #     BB.A_P[BB.isIlliquity] = BB_t1.A_P[BB.isIlliquity] - ((BB.Shock_B_Z[BB.isIlliquity] - BB_t1.A_Q[BB.isIlliquity]) ./ (BB_t1.A_P[BB.isIlliquity] + BB_t1.A_BI_all[BB.isIlliquity]) .* BB_t1.A_P[BB.isIlliquity]) # 非银行间贷款资产应变动，由于回收资产
        #     update_B_balanceSheet!(BB, BI, a, ia; byWay = "A_P") # 更新资产负债表，通过A_P或A_BI_all
        #     BB.Shock_L_exBI_s[BB.isIlliquity] = abs.(BB.A_P[BB.isIlliquity] - BB_t1.A_P[BB.isIlliquity]) # 银行内冲击传导至银行厂商贷款传染冲击
        #     # i0 = (BB.isBankrupt .&& BB.isIlliquity) # 计算状态之于银行集合其满足破产和流动性短缺
        #     # BB.Shock_BI_run_br_s[i0] = BB.A_BI_all[i0] # 流动性短缺的银行内冲击传导至银行倒闭冲击
        #     # update_B_Shock!(BB, BI,a,ia; byWay = "Shock_BI_run_br_s") # 汇总各银行之倒闭流动性挤兑冲击

        #     ## 清零银行间和银行外冲击变量
        #     update_B_Shock!(BB, BI, a, ia; byWay = "clear Shock_BI and Shock_exBI") # 清零各银行之不必要的冲击变量，被使用于下一回合，从第二回合开始


        #     ## ## 破产召回阶段$t_{3}$：，当$\tau>1$时：
        #     println("t3 开始破产召回阶段")

        #     ## 设置临时变量
        #     BB_t2 = deepcopy(BB) # 临时设置BB变量
        #     BI_t2 = deepcopy(BI) # 临时设置BI变量

        #     # br = BB.isBankrupt # 临时设置破产银行示性变量
        #     # cre_br = BI.listOfCreditors # 临时设置BI之列表之于银行之债权方银行编号
        #     BB.Shock_BI_run_br_s[BB.isBankrupt], BB.A_BI_all[BB.isBankrupt] = transfer_B_capital(BB.Shock_BI_run_br_s[BB.isBankrupt], BB.A_BI_all[BB.isBankrupt], BB.A_BI_all[BB.isBankrupt]) # 转移破产银行之资产变动，并且银行内冲击传导至银行倒闭挤兑流动冲击
        #     update_B_Shock!(BB, BI, a, ia; byWay = "Shock_BI_run_br_s") # 汇总各银行之倒闭流动性挤兑冲击
        #     BB.Shock_L_exBI_s[BB.isBankrupt], BB.A_P[BB.isBankrupt] = transfer_B_capital(BB.Shock_L_exBI_s[BB.isBankrupt], BB.A_P[BB.isBankrupt], BB.A_P[BB.isBankrupt]) # 非银行间贷款资产应变动，由于回收资产，并且银行内冲击传导至银行厂商贷款传染冲击
        #     # BB.A_P[BB.isBankrupt] .= 0.0  #HACK，冗余，可以删除
        #     # BB.Shock_BI_run_br_s[BB.isBankrupt] = abs.(BB.A_BI_all[BB.isBankrupt] - BB_t1.A_BI_all[BB.isBankrupt]) # 倒闭的银行之银行内冲击传导至银行倒闭挤兑流动冲击  #HACK，冗余，可以删除
        #     update_B_Shock!(BB, BI, a, ia; byWay = "Shock_BI_run_br_s") # 汇总各银行之倒闭流动性挤兑冲击
        #     # BB.Shock_L_exBI_s[BB.isBankrupt] = abs.(BB.A_P[BB.isBankrupt] - BB_t1.A_P[BB.isBankrupt]) # 银行内冲击传导至银行厂商贷款传染冲击 #HACK，冗余，可以删除
        #     # update_B_balanceSheet!(BB, BI,a,ia; byWay = "alter from A_BI") # 转换银行间资产负债邻接矩阵
        #     # update_B_balanceSheet!(BB, BI,a,ia; byWay = "A_other") # 更新各银行之资产负债表变量，通过其它资产
        #     # BB.A_P[br] .= 0.0 # 破产银行之非银行间贷款清零
        #     # BB.A_Q[BB.isBankrupt], BB.A_BI_all[BB.isBankrupt] = transfer_B_capital(BB.A_Q[BB.isBankrupt], BB.A_BI_all[BB.isBankrupt], BB.A_BI_all[BB.isBankrupt])
        #     # for i in findall(br) # 破产银行偿还银行间借款，破产银行对应债权银行之银行间资产变成各自债权银行之其它资产
        #     #     BB.A_other[cre_br[i]], BI.A_BI[cre_br[i], i] = transfer_B_capital(BB.A_other[cre_br[i]], BI.A_BI[cre_br[i], i], BI.A_BI[cre_br[i], i])
        #     #     # BB.A_other[cre_br[i]] += BI.A_BI[cre_br[i], i]
        #     #     # BI.A_BI[cre_br[i], i] .= 0.0
        #     # end
        #     # BB.A_Q[br] .= 0.0 # 破产银行之流动资金清零
        #     # BB.A_R[br] .= 0.0 # 破产银行之存款准备金清零
        #     # BB.A_other[br] .= 0.0 # 破产银行之其它资产清零
        #     # update_B_balanceSheet!(BB, BI,a,ia; byWay = "A_exBI") # 更新各银行之资产负债表变量，通过非银行间资产
        #     # BB.Z_D[br] .= 0.0 # 破产银行之居民存款清零，为了偿还剩余存款负债
        #     # BB.Z_other[br] .= 0.0 # 破产银行之其它负债清零
        #     # BB.Z_BI_all[br] .= 0.0 # 破产银行之银行间贷款清零，为了偿还所有银行间负债
        #     # update_B_balanceSheet!(BB, BI,a,ia; byWay = "Z_exBI") # 更新各银行之资产负债表变量，通过非银行间负债
        #     # update_B_state!(BB, BI; to = "off", from = "bankrupt") # 更新各银行之状态，从破产到退出





        #     ## ## 尾声阶段$t_{4}$：
        #     println("t4 开始尾声阶段")

        #     ## TODO存储数据
        #     BB_tau[tau] = deepcopy(BB) # 存储该轮次传染结果数据
        #     BI_tau[tau] = deepcopy(BI) # 存储该轮次传染结果数据

        #     ## 清零银行内冲击变量
        #     update_B_Shock!(BB, BI, a, ia; byWay = "clear Shock_B") # 清零银行内资产负债冲击

        #     ## 判定本回合是否有银行转移状态，如果无则后续处理然后结束本轮，如果有则继续处理。
        #     if BB.isOff == BB_t1.isOff
        #         isEnd = true
        #         break
        #     end

        # end # while

    end # while


    ## # 传染过程结束
    println("传染过程结束")
    ## 收尾
    # update_B_balanceSheet!(BB, BI,a,ia; byWay = "calc all E_all") # 更新计算各银行之所有者权益
    # BB_tau[tau] = deepcopy(BB) # 存储该轮次传染结果数据
    # BI_tau[tau] = deepcopy(BI) # 存储该轮次传染结果数据
    #TODO 最终破产清算

    return BB, BI, BB_tau, BI_tau

    println("model_BI1111结束。")

end # end function


# end; # module


