

## 模块之银行间市场BI1111：最新的一版。

##########################################
#使用：暂时不需要；
#状态：暂停，待以后需要的时候处理；
##########################################


function model_BI1111(BB::BankCommercial, BI::BankInterbank)


    ## 初始化
    env.tau = 0 # 初始化传染回合
    env.is_end_round = false # 初始化结束判断

    env.tau += 1 # 传染回合累加一
    println("开始回合",env.tau)

    ## 初始阶段$t_{0}$，当$\env.tau=1$时：
    println("t0 初始阶段")

    local on = BB.isOn # 临时设置BB有存在的示性变量
    local b = TypeState{1}(BB.isOn .|| BB.isOff) # 临时设置BB示性变量
    local ib = TypeState{2}((BB.isOn .|| BB.isOff) .&& (BB.isOn .|| BB.isOff)') # 临时设置BI示性变量

    # ## 更新各银行之变量 # HACK多余，已经在初始化过程定义，此处可以删除
    # update_B_Shock!(BB, BI, b, ib; byWay = "all") # 更新各银行之所有冲击变量，在第一回合开始时
    # update_B_balanceSheet!(BB, BI, b, ib; byWay = "all") # 更新各银行之资产负债表变量
    # update_B_state!(BB, BI; to = "any", from = "any") # 更新本轮银行B示性向量


    ## 初始外生传染冲击阶段$t_{1}$，当$\env.tau=1$时：
    println("t1 开始外生传染冲击阶段")
    ## # 初始外生损失冲击传染：
    if para.theta_Shock_exBI_t == 1.0
        println("t1-1 初始外生损失冲击传染")
        update_B_Shock!(BB, BI, b, ib; byWay = "Shock_L_exBI_t") # 生成综合外生冲击
        BB.Shock_B_A[b] = BB.Shock_exBI_t[b] # 银行外冲击传导至银行内资产冲击
        update_B_Shock!(BB, BI, b, ib; byWay = "Shock_B_A")
        ## # 初始外生挤兑流动冲击传染：
    elseif para.theta_Shock_exBI_t == 0.0
        println("t1-2 初始外生挤兑流动冲击传染")
        update_B_Shock!(BB, BI, b, ib; byWay = "Shock_D_t") # 生成综合外生冲击
        BB.Shock_B_Z[b] = BB.Shock_exBI_t[b] # 银行外冲击传导至银行内负债冲击
        update_B_Shock!(BB, BI, b, ib; byWay = "Shock_B_Z")
    else
        throw(DomainError(para.theta_Shock_exBI_t, "参数暂时只能取值1或者0！"))
    end

    ## # 外生破产银行银行间挤兑流动冲击传染：
    println("t1-3 外生破产银行银行间挤兑流动冲击传染")
    update_B_state!(BB, BI; to = "bankrupt", from = "any") # 更新示性向量之于破产银行状态
    br = BB.isBankrupt # 临时设置破产银行示性变量
    deb_br = BI.listOfDebtors # 临时设置BI之列表之于破产的银行之债务方银行编号
    for i in findall(br) # 破产银行收回其银行间资产，用于偿还其银行间负债。此举导致其对各债务银行之资产变动，造成破产银行银行间挤兑流动冲击
        BI.Shock_BI_run_br[deb_br[i], i], BI.A_BI[i, deb_br[i]] = transfer_B_capital(; target = BI.Shock_BI_run_br[deb_br[i], i], source = BI.A_BI[i, deb_br[i]])
        # BI.Shock_BI_run_br[deb_br[i], i] = BI.A_BI[i, deb_br[i]]
        # BI.A_BI[i, deb_br[i]] .= 0.0
    end
    # HACK以下部分是否提取出来在阶段1结束之前使用
    update_B_balanceSheet!(BB, BI, b, ib; byWay = "alter from A_BI") # 转换银行间资产负债邻接矩阵
    update_B_Shock!(BB, BI, b, ib; byWay = "Shock_BI_run_br") # 加总各单个债务银行遭受总银行间挤兑流动冲击
    # BB.A_BI_all[b] -= BB.Shock_BI_run_br_t[b] # HACK（仅作说明）各流动性短缺银行对应债务银行之银行间负债变动（不是在此处出现，在银行内冲击阶段出现）。可以删除。
    BB.Shock_B_Z[b] = BB.Shock_BI_run_t[b] # 银行间冲击传导为银行内冲击
    update_B_Shock!(BB, BI, b, ib; byWay = "Shock_B_Z") # 更新各银行之冲击变量，通过银行内负债冲击

    # update_B_state!(BB, BI; to = "off", from = "bankrupt") # 更新各银行之状态，从破产到退出


    ## 初始外生冲击阶段$t_{2}$，当$\env.tau=1$时：
    println("t2 开始外生冲击阶段")

    ## # 初始化：
    println("t2-0 初始化")

    ## 设置临时变量
    BB_t0 = deepcopy(BB) # 临时设置BB变量，被读取于阶段1
    BI_t0 = deepcopy(BI) # 临时设置BI变量，被读取于阶段1

    ## 清零银行间和银行外冲击变量
    update_B_Shock!(BB, BI, b, ib; byWay = "clear Shock_BI and Shock_exBI")

    if para.theta_Shock_exBI_t == 1.0
        ## # 银行之非银行间贷款违约损失冲击：
        println("t2-1 银行之非银行间贷款违约损失冲击")
        BB.A_P[b] -= BB.Shock_B_A[b] # 银行之非银行间资产变动
        update_B_balanceSheet!(BB, BI, b, ib; byWay = "A_P")
        update_B_state!(BB, BI; to = "bankrupt", from = "healthy") # 更新各银行之状态，从健康到破产
        BB.E_all[BB.isOn] = max.(BB.E_all[BB.isOn] - BB.Shock_B_A[BB.isOn], 0.0) # 银行之所有者权益
        update_B_state!(BB, BI, to = "insolvent", from = "any")
        # update_B_balanceSheet!(BB, BI,b,ib; byWay = "E_all and A_all") # 计算各银行之总负债Z_BI_all
        BB.Z_BI_all[BB.isInsolvent] = BB_t0.Z_BI_all[BB.isInsolvent] - ((BB.Shock_B_A[BB.isInsolvent] - BB_t0.E_all[BB.isInsolvent]) ./ (BB_t0.Z_BI_all[BB.isInsolvent] + BB_t0.Z_D[BB.isInsolvent]) .* BB_t0.Z_BI_all[BB.isInsolvent]) # 银行间负债变动，由于违约
        update_B_balanceSheet!(BB, BI, b, ib; byWay = "Z_BI_all") # 汇总各银行之非银行间负债Z_exBI、总负债Z_all，被动地计算所有者权益
        BB.Z_D[BB.isInsolvent] = BB_t0.Z_D[BB.isInsolvent] - ((BB.Shock_B_A[BB.isInsolvent] - BB_t0.E_all[BB.isInsolvent]) ./ (BB_t0.Z_BI_all[BB.isInsolvent] + BB_t0.Z_D[BB.isInsolvent]) .* BB_t0.Z_D[BB.isInsolvent]) # 存款负债变动，由于违约
        update_B_balanceSheet!(BB, BI, b, ib; byWay = "Z_D") # 汇总各银行之非银行间负债Z_exBI、总负债Z_all，被动地计算所有者权益
        BB.Shock_BI_def_s[BB.isInsolvent] = abs.(BB.Z_BI_all[BB.isInsolvent] - BB_t0.Z_BI_all[BB.isInsolvent]) # 银行内冲击传导至银行间传染冲击
        update_B_Shock!(BB, BI, b, ib; byWay = "Shock_BI_def_s") # 汇总各银行之违约损失冲击
        BB.Shock_D_s[BB.isInsolvent] = abs.(BB.Z_D[BB.isInsolvent] - BB_t0.Z_D[BB.isInsolvent]) # 银行内冲击传导至银行存款传染冲击
        # i0 = (BB.isBankrupt .&& BB.isInsolvent) # 计算状态之于银行集合其满足破产和资不抵债
        # BB.Shock_BI_run_br_s[i0] = BB.A_BI_all[i0] # 资不抵债的和银行内冲击传导至银行倒闭冲击
        # update_B_Shock!(BB, BI,b,ib; byWay = "Shock_BI_run_br_s") # 汇总各银行之倒闭流动性挤兑冲击

        ## 设置临时变量
        BB_t1 = deepcopy(BB)
        BI_t1 = deepcopy(BI)

    elseif para.theta_Shock_exBI_t == 0.0 #TODO如何考虑叠加状态？
        ## # 银行存款挤兑流动冲击：
        println("t2-2 银行存款挤兑流动冲击")
        BB.Z_D[b] -= BB.Shock_B_Z[b] # 存款负债变动
        update_B_balanceSheet!(BB, BI, b, ib; byWay = "Z_D")
        update_B_state!(BB, BI; to = "bankrupt", from = "healthy") # 更新各银行之状态，从健康到破产
        BB.A_Q[b] = max.(BB.A_Q[b] - BB.Shock_B_Z[b], 0.0) # 流动资产变动
        update_B_balanceSheet!(BB, BI, b, ib; byWay = "A_Q")
        BB.A_BI_all[BB.isIlliquity] = BB_t0.A_BI_all[BB.isIlliquity] - ((BB.Shock_B_Z[BB.isIlliquity] - BB_t0.A_Q[BB.isIlliquity]) ./ (BB_t0.A_P[BB.isIlliquity] + BB_t0.A_BI_all[BB.isIlliquity]) .* BB_t0.A_BI_all[BB.isIlliquity]) # 银行间资产应变动，由于回收资产
        update_B_balanceSheet!(BB, BI, b, ib; byWay = "A_BI_all") # 更新资产负债表，通过A_P或A_BI_all
        BB.Shock_BI_run_ilq_s[BB.isIlliquity] = abs.(BB.A_BI_all[BB.isIlliquity] - BB_t0.A_BI[BB.isIlliquity]) # 银行内冲击传导至银行间传染冲击
        update_B_Shock!(BB, BI, b, ib; byWay = "Shock_BI_run_ilq_s") # 汇总各银行之流动性短缺流动性挤兑冲击
        BB.A_P[BB.isIlliquity] = BB_t0.A_P[BB.isIlliquity] - ((BB.Shock_B_Z[BB.isIlliquity] - BB_t0.A_Q[BB.isIlliquity]) ./ (BB_t0.A_P[BB.isIlliquity] + BB_t0.A_BI_all[BB.isIlliquity]) .* BB_t0.A_P[BB.isIlliquity]) # 非银行间贷款资产应变动，由于回收资产
        update_B_balanceSheet!(BB, BI, b, ib; byWay = "A_P") # 更新资产负债表，通过A_P或A_BI_all
        BB.Shock_L_exBI_s[BB.isIlliquity] = abs.(BB.A_P[BB.isIlliquity] - BB_t0.A_P[BB.isIlliquity]) # 银行内冲击传导至银行厂商贷款传染冲击
    # i0 = (BB.isBankrupt .&& BB.isIlliquity) # 计算状态之于银行集合其满足破产和流动性短缺
    # BB.Shock_BI_run_br_s[i0] = BB.A_BI_all[i0] # 流动性短缺的银行内冲击传导至银行倒闭冲击
    # update_B_Shock!(BB, BI,b,ib; byWay = "Shock_BI_run_br_s") # 汇总各银行之倒闭流动性挤兑冲击
    else
        throw(DomainError(para.theta_Shock_exBI_t, "参数暂时只能取值1或者0！"))
    end


    ## 设置临时变量
    BB_t2 = deepcopy(BB)
    BI_t2 = deepcopy(BI)

    ## 破产清算阶段$t_{3}$：，当$\env.tau=1$时：
    println("t3 开始破产清算阶段")
    # br = BB.isBankrupt # 临时设置破产银行示性变量
    # cre_br = BI.listOfCreditors # 临时设置BI之列表之于上一回合破产的银行之债权方银行编号
    # BB.A_BI_all[BB.isBankrupt] .= 0.0 # 银行间资产应变动，由于回收资产
    # BB.A_P[BB.isBankrupt] .= 0.0 # 非银行间贷款资产应变动，由于回收资产
    BB.Shock_BI_run_br_s[BB.isBankrupt] = abs.(BB.A_BI_all[BB.isBankrupt] - BB_t2.A_BI_all[BB.isBankrupt]) # 倒闭的银行之银行内冲击传导至银行倒闭挤兑流动冲击
    update_B_Shock!(BB, BI, b, ib; byWay = "Shock_BI_run_br_s") # 汇总各银行之倒闭流动性挤兑冲击
    BB.Shock_L_exBI_s[BB.isBankrupt] = abs.(BB.A_P[BB.isBankrupt] - BB_t2.A_P[BB.isBankrupt]) # 银行内冲击传导至银行厂商贷款传染冲击
    # for i in findall(br) # 破产银行偿还银行间借款，破产银行对应债权银行之银行间资产变成各自债权银行之其它资产
    #     BB.A_other[cre_br[i]], BI.A_BI[cre_br[i], i] = transfer_B_capital(; target = BB.A_other[cre_br[i]], source = BI.A_BI[cre_br[i], i])
    #     # BB.A_other[cre_br[i]] += BI.A_BI[cre_br[i], i]
    #     # BI.A_BI[cre_br[i], i] .= 0.0
    # end
    # update_B_balanceSheet!(BB, BI,b,ib; byWay = "alter from A_BI") # 转换银行间资产负债邻接矩阵
    # update_B_balanceSheet!(BB, BI,b,ib; byWay = "A_other") # 更新各银行之资产负债表变量，通过其它资产
    # BB.A_P[br] .= 0.0 # 破产银行之非银行间贷款清零
    # BB.A_Q[br] .= 0.0 # 破产银行之流动资金清零
    # BB.A_R[br] .= 0.0 # 破产银行之存款准备金清零
    # BB.A_other[br] .= 0.0 # 破产银行之其它资产清零
    # update_B_balanceSheet!(BB, BI,b,ib; byWay = "A_exBI") # 更新各银行之资产负债表变量，通过非银行间资产
    # BB.Z_D[br] .= 0.0 # 破产银行之居民存款清零，为了偿还剩余存款负债
    # BB.Z_other[br] .= 0.0 # 破产银行之其它负债清零
    # BB.Z_BI_all[br] .= 0.0 # 破产银行之银行间贷款清零，为了偿还所有银行间负债
    # update_B_balanceSheet!(BB, BI,b,ib; byWay = "Z_exBI") # 更新各银行之资产负债表变量，通过非银行间负债
    # update_B_state!(BB, BI; to = "off", from = "bankrupt") # 更新各银行之状态，从破产到退出

    # ## 上一回合破产的银行清算阶段$t_{3}$：，当$\env.tau=1$时：
    # println("开始破产清算阶段t3")
    # br_t0 = BB_t0.isBankrupt # 临时设置上一回合破产银行示性变量
    # cre_br_t0 = BI_t0.listOfCreditors # 临时设置BI之列表之于上一回合破产的银行之债权方银行编号
    # for i in findall(br_t0) # 破产银行偿还银行间借款，破产银行对应债权银行之银行间资产变成各自债权银行之其它资产
    #     BB.A_other[cre_br_t0[i]], BI.A_BI[cre_br_t0[i], i] = transfer_B_capital(; target = BB.A_other[cre_br_t0[i]], source = BI.A_BI[cre_br_t0[i], i])
    #     # BB.A_other[cre_br_t0[i]] += BI.A_BI[cre_br_t0[i], i]
    #     # BI.A_BI[cre_br_t0[i], i] .= 0.0
    # end
    # update_B_balanceSheet!(BB, BI,b,ib; byWay = "alter from A_BI") # 转换银行间资产负债邻接矩阵
    # # update_B_balanceSheet!(BB, BI,b,ib; byWay = "sum A_BI") # 加总银行间资产变量
    # # update_B_balanceSheet!(BB, BI,b,ib; byWay = "sum Z_BI") # 加总银行间负债变量
    # update_B_balanceSheet!(BB, BI,b,ib; byWay = "A_other") # 更新各银行之资产负债表变量，通过其它资产
    # BB.A_BI_all[br_t0] .= 0.0 # 破产银行之银行间贷款清零
    # BB.A_P[br_t0] .= 0.0 # 破产银行之非银行间贷款清零
    # BB.A_Q[br_t0] .= 0.0 # 破产银行之流动资金清零
    # BB.A_R[br_t0] .= 0.0 # 破产银行之存款准备金清零
    # BB.A_other[br_t0] .= 0.0 # 破产银行之其它资产清零
    # update_B_balanceSheet!(BB, BI,b,ib; byWay = "A_exBI") # 更新各银行之资产负债表变量，通过非银行间资产
    # BB.Z_D[br_t0] .= 0.0 # 破产银行之居民存款清零
    # BB.Z_other[br_t0] .= 0.0 # 破产银行之其它负债清零
    # BB.Z_BI_all[br_t0] .= 0.0 # 破产银行之银行间贷款清零
    # update_B_balanceSheet!(BB, BI,b,ib; byWay = "Z_D") # 更新各银行之资产负债表变量，通过非银行间负债
    # update_B_state!(BB, BI; to = "off", from = "bankrupt") # 更新各银行之状态，从破产到退出




    ## 尾声阶段$t_{4}$：
    println("t4 开始尾声阶段")


    # update_B_balanceSheet!(BB, BI,b,ib; byWay = "all") # 更新各银行之资产负债表变量，被使用于下一回合
    # update_B_state!(BB, BI; to = "any", from = "any") # 更新本轮银行B示性向量，被使用于下一回合

    ## 存储数据
    BB_tau[env.tau] = deepcopy(BB) # 存储该回合传染结果数据
    BI_tau[env.tau] = deepcopy(BI) # 存储该回合传染结果数据

    ## 清零银行内冲击变量
    update_B_Shock!(BB, BI, b, ib; byWay = "clear Shock_B")

    ## 判定本回合是否有银行转移状态从健康状态至其他状态，如果无则后续处理然后结束本轮，如果有则继续处理。
    if BB.isHealthy == BB_t0.isHealthy
        env.is_end_round = true
    end

    ## 循环，当回合$\env.tau>1$时：
    while (env.tau <= env.max_num_tau .|| env.is_end_round == true)

        env.tau += 1 # 传染回合累加一
        println("开始回合",env.tau)

        ## 初始阶段$t_{0}$，当$\env.tau>1$时：
        println("t0 初始阶段")


        local on = BB.isOn # 临时设置BB有存在的示性变量
        local b = TypeState{1}(BB.isOn .|| BB.isOff) # 临时设置BB示性变量
        local ib = TypeState{2}((BB.isOn .|| BB.isOff) .&& (BB.isOn .|| BB.isOff)') # 临时设置BI示性变量


        ## 银行间传染冲击阶段$t_{1}$，当$\env.tau>1$时：
        println("t1 开始银行间传染冲击阶段")
        
        ## # 银行间违约损失冲击传染方式$i_{br} \stackrel{def,BI}{\longrightarrow} j_{cre}$：
        println("t1-1 银行间违约损失冲击传染方式")
        isv = BB.isInsolvent # 临时设置BB资不抵债的示性变量，在阶段1
        cre_isv = BI.listOfCreditors # 临时设置BI之列表之于资不抵债的银行之债权方银行编号
        for i in findall(isv) # 资不抵债银行违约，导致其对各债权银行负债变动，造成银行间违约冲击
            BI.Z_BI[i, cre_isv[i]] .*= (1.0 - BB.Shock_BI_def_s[i] ./ BB_t0.Z_BI_all[i])
            BI.Shock_BI_def[cre_isv[i], i] = BI_t0.Z_BI[i, cre_isv[i]] .* BB.Shock_BI_def_s[i] ./ BB_t0.Z_BI_all[i]
        end
        # HACK以下部分是否提取出来在阶段1结束之前使用
        update_B_balanceSheet!(BB, BI, b, ib; byWay = "alter from Z_BI") # 转换银行间资产负债邻接矩阵
        update_B_Shock!(BB, BI, b, ib; byWay = "Shock_BI_def") # 加总各单个债权银行遭受总银行间违约损失冲击
        # BB.A_BI_all[b] -= BB.Shock_BI_def_t[b] # HACK（仅作说明）各资不抵债银行对应债权银行之银行间资产变动（不是在此处出现，在银行内冲击阶段出现）。可以删除。
        BB.Shock_B_A[b] = BB.Shock_BI_def_t[b] # 银行间冲击传导为银行内冲击
        update_B_Shock!(BB, BI, b, ib; byWay = "Shock_B_A") # 汇总各银行之银行内资产负债冲击


        ## # 流动性短缺银行银行间挤兑流动冲击传染方式 $i_{ilq} \stackrel{BI,run}{\longrightarrow} k_{deb}$：
        println("t1-2 流动性短缺银行银行间挤兑流动冲击传染方式")
        ilq = BB.isIlliquity # 临时设置BB流动性短缺的示性变量，在阶段1
        deb_ilq = BI.listOfDebtors # 临时设置BI之列表之于流动性短缺的银行之债务方银行编号
        for i in findall(ilq) # 流动性短缺银行收回资产，导致其对各债务银行之资产变动，造成流动性短缺银行间挤兑流动冲击
            BI.A_BI[i, deb_ilq[i]] = BI_t1.A_BI[i, deb_ilq[i]] .* (1.0 - BB.Shock_BI_run_ilq_s[i] ./ BB_t1.A_BI_all[i])
            BI.Shock_BI_run_ilq[deb_ilq[i], i] = BI_t1.A_BI[i, deb_ilq[i]] .* BB.Shock_BI_run_ilq_s[i] ./ BB_t1.A_BI_all[i] # 注意这里用BI.A_BI而非BI.Z_BI是因为转换资产负债表过程被放在后面了
        end
        # HACK以下部分是否提取出来在阶段1结束之前使用
        update_B_balanceSheet!(BB, BI, b, ib; byWay = "alter from A_BI") # 转换银行间资产负债邻接矩阵
        update_B_Shock!(BB, BI, b, ib; byWay = "Shock_BI_run_ilq") # 加总各单个债务银行遭受总银行间挤兑流动冲击
        # BB.A_BI_all[b] -= BB.Shock_BI_run_ilq_t[b] # HACK（仅作说明）各流动性短缺银行对应债务银行之银行间负债变动（不是在此处出现，而是在银行内冲击阶段出现）。可以删除。
        BB.Shock_B_Z[b] = BB.Shock_BI_run_t[b] # 银行间冲击传导为银行内冲击
        update_B_Shock!(BB, BI, b, ib; byWay = "Shock_B_Z") # 汇总各银行之银行内资产负债冲击


        ## # 破产银行银行间挤兑流动冲击传染方式 $i_{br} \stackrel{BI,run}{\longrightarrow} k_{deb}$：
        println("t1-3 破产银行银行间挤兑流动冲击传染方式")
        update_B_state!(BB, BI; to = "bankrupt", from = "any") # 更新示性向量之于破产银行状态
        br = BB.isBankrupt # 临时设置BB破产的示性变量
        deb_br = BI.listOfDebtors # 临时设置BI之列表之于破产的银行之债务方银行编号
        for i in findall(br) # 破产银行收回其银行间资产，用于偿还其银行间负债。此举导致其对各债务银行之资产变动，造成破产银行银行间挤兑流动冲击
            BI.Shock_BI_run_br[deb_br[i], i], BI.A_BI[i, deb_br[i]] = transfer_B_capital(; target = BI.Shock_BI_run_br[deb_br[i], i], source = BI.A_BI[i, deb_br[i]])
            # BI.Shock_BI_run_br[deb_br[i], i] = BI.A_BI[i, deb_br[i]]
            # BI.A_BI[i, deb_br[i]] .= 0.0
        end
        # HACK以下部分是否提取出来在阶段1结束之前使用
        update_B_balanceSheet!(BB, BI, b, ib; byWay = "alter from A_BI") # 转换银行间资产负债邻接矩阵
        update_B_Shock!(BB, BI, b, ib; byWay = "Shock_BI_run_br") # 加总各单个债务银行遭受总银行间挤兑流动冲击
        # BB.A_BI_all[b] -= BB.Shock_BI_run_br_t[b] # HACK（仅作说明）各流动性短缺银行对应债务银行之银行间负债变动（不是在此处出现，在银行内冲击阶段出现）。可以删除。
        BB.Shock_B_Z[b] = BB.Shock_BI_run_t[b] # 银行间冲击传导为银行内冲击
        update_B_Shock!(BB, BI, b, ib; byWay = "Shock_B_Z") # 更新各银行之冲击变量，通过银行内负债冲击

        # update_B_state!(BB, BI; to = "off", from = "bankrupt") # 更新各银行之状态，从破产到退出







        ## 银行资产负债冲击阶段$t_{2}$，当$\env.tau>1$时：
        println("t2 开始银行资产负债冲击阶段")

        ## # 初始化：
        println("t2-0 初始化")

        ## 设置临时变量
        BB_t0 = deepcopy(BB) # 临时设置BB变量，被读取于本回合之银行资产冲击
        BI_t0 = deepcopy(BI) # 临时设置BI变量，被读取于本回合之银行资产冲击

        ## 清零银行间和银行外冲击变量
        update_B_Shock!(BB, BI, b, ib; byWay = "clear Shock_BI and Shock_exBI") # 清零各银行之不必要的冲击变量，被使用于下一回合，从第二回合开始

        ## # 银行内资产冲击：
        println("t2-1 银行内资产冲击")
        BB.A_BI_all[b] = max.(BB.A_BI_all[b] - BB.Shock_B_A[b], 0.0) # 银行之银行间资产变动
        update_B_balanceSheet!(BB, BI, b, ib; byWay = "A_BI_all")
        BB.E_all[BB.isOn] = max.(BB.E_all[BB.isOn] - BB.Shock_B_A[BB.isOn], 0.0) # 银行之所有者权益变动
        update_B_state!(BB, BI; to = "insolvent", from = "healthy") # 更新各银行之状态，从健康到破产
        update_B_state!(BB, BI; to = "bankrupt", from = "insolvent") # 更新各银行之状态，从健康到破产
        # update_B_balanceSheet!(BB, BI,b,ib; byWay = "E_all and A_all")
        BB.Z_BI_all[BB.isInsolvent] = BB_t0.Z_BI_all[BB.isInsolvent] - ((BB.Shock_B_A[BB.isInsolvent] - BB_t0.E_all[BB.isInsolvent]) ./ (BB_t0.Z_BI_all[BB.isInsolvent] + BB_t0.Z_D[BB.isInsolvent]) .* BB_t0.Z_BI_all[BB.isInsolvent]) # 银行间负债变动，由于违约
        update_B_balanceSheet!(BB, BI, b, ib; byWay = "Z_BI_all") # 更新资产负债表，通过Z_D或Z_BI_all
        BB.Z_D[BB.isInsolvent] = BB_t0.Z_D[BB.isInsolvent] - ((BB.Shock_B_A[BB.isInsolvent] - BB_t0.E_all[BB.isInsolvent]) ./ (BB_t0.Z_BI_all[BB.isInsolvent] + BB_t0.Z_D[BB.isInsolvent]) .* BB_t0.Z_D[BB.isInsolvent]) # 存款负债变动，由于违约
        update_B_balanceSheet!(BB, BI, b, ib; byWay = "Z_D") # 更新资产负债表，通过Z_D或Z_BI_all
        BB.Shock_BI_def_s[BB.isInsolvent] = abs.(BB.Z_BI_all[BB.isInsolvent] - BB_t0.Z_BI_all[BB.isInsolvent]) # 银行内冲击传导至银行间传染冲击
        update_B_Shock!(BB, BI, b, ib; byWay = "Shock_BI_def_s") # 汇总各银行之倒闭流动性挤兑冲击、违约损失冲击
        BB.Shock_D_s[BB.isInsolvent] = abs.(BB.Z_D[BB.isInsolvent] - BB_t0.Z_D[BB.isInsolvent]) # 银行内冲击传导至银行存款传染冲击
        # i0 = (BB.isBankrupt .&& BB.isInsolvent) # 计算状态之于银行集合其满足破产和资不抵债
        # BB.Shock_BI_run_br_s[i0] = BB.A_BI_all[i0] # 资不抵债的和银行内冲击传导至银行倒闭冲击
        # update_B_Shock!(BB, BI,b,ib; byWay = "Shock_BI_run_br_s") # 汇总各银行之倒闭流动性挤兑冲击、违约损失冲击

        ## 设置临时变量
        BB_t1 = deepcopy(BB)
        BI_t1 = deepcopy(BI)

        ## # 银行内负债冲击：
        println("t2-2 银行内负债冲击")
        i1 = (on .&& ((BB.Z_D - BB.Shock_D_s) + ((BB.Z_BI_all - BB.Shock_BI_def_s)) .< BB.Shock_B_Z)) # 计算条件之于银行集合其满足其应违约但是应被收回
        BB.Shock_B_Z[i1] = (BB.Shock_D_s[i1] + BB.Shock_BI_def_s[i1]) - (BB.Z_D[i1] + BB.Z_BI_all[i1]) # 更新遭受实际银行内负债冲击
        update_B_Shock!(BB, BI, b, ib; byWay = "Shock_B_Z")
        update_B_state!(BB, BI; to = "illiquity", from = "healthy")
        BB.Z_BI_all[b] = max.(BB.Z_BI_all[b] - BB.Shock_B_Z[b], 0.0) # 银行之银行间负债变动
        update_B_balanceSheet!(BB, BI, b, ib; byWay = "Z_BI_all")
        BB.A_Q[b] = max.(BB.A_Q[b] - BB.Shock_B_Z[b], 0.0) # 银行之流动资产变动
        update_B_state!(BB, BI; to = "illiquity", from = "healthy") # 更新各银行之状态，从健康到破产
        update_B_state!(BB, BI; to = "bankrupt", from = "illiquity") # 更新各银行之状态，从健康到破产
        update_B_balanceSheet!(BB, BI, b, ib; byWay = "A_Q")
        BB.A_BI_all[BB.isIlliquity] = BB_t1.A_BI_all[BB.isIlliquity] - ((BB.Shock_B_Z[BB.isIlliquity] - BB_t1.A_Q[BB.isIlliquity]) ./ (BB_t1.A_P[BB.isIlliquity] + BB_t1.A_BI_all[BB.isIlliquity]) .* BB_t1.A_BI_all[BB.isIlliquity]) # 银行间资产应变动，由于回收资产
        update_B_balanceSheet!(BB, BI, b, ib; byWay = "A_BI_all") # 更新资产负债表，通过A_P或A_BI_all
        BB.Shock_BI_run_ilq_s[BB.isIlliquity] = abs.(BB.A_BI_all[BB.isIlliquity] - BB_t1.A_BI_all[BB.isIlliquity]) # 计算应银行内冲击传导至银行间传染冲击
        update_B_Shock!(BB, BI, b, ib; byWay = "Shock_BI_run_ilq_s") # 汇总各银行之流动性短缺流动性挤兑冲击
        BB.A_P[BB.isIlliquity] = BB_t1.A_P[BB.isIlliquity] - ((BB.Shock_B_Z[BB.isIlliquity] - BB_t1.A_Q[BB.isIlliquity]) ./ (BB_t1.A_P[BB.isIlliquity] + BB_t1.A_BI_all[BB.isIlliquity]) .* BB_t1.A_P[BB.isIlliquity]) # 非银行间贷款资产应变动，由于回收资产
        update_B_balanceSheet!(BB, BI, b, ib; byWay = "A_P") # 更新资产负债表，通过A_P或A_BI_all
        BB.Shock_L_exBI_s[BB.isIlliquity] = abs.(BB.A_P[BB.isIlliquity] - BB_t1.A_P[BB.isIlliquity]) # 银行内冲击传导至银行厂商贷款传染冲击
        # i0 = (BB.isBankrupt .&& BB.isIlliquity) # 计算状态之于银行集合其满足破产和流动性短缺
        # BB.Shock_BI_run_br_s[i0] = BB.A_BI_all[i0] # 流动性短缺的银行内冲击传导至银行倒闭冲击
        # update_B_Shock!(BB, BI,b,ib; byWay = "Shock_BI_run_br_s") # 汇总各银行之倒闭流动性挤兑冲击

        # ## # 银行内负债冲击：
        # i1 = (on .&& ((BB.Z_D - BB.Shock_D_s) + ((BB.Z_BI_all - BB.Shock_BI_def_s)) .< BB.Shock_B_Z)) # 计算条件之于银行集合其满足其应违约但是应被收回
        # BB.Shock_B_Z[i1] = (BB.Shock_D_s[i1] + BB.Shock_BI_def_s[i1]) - (BB.Z_D[i1] + BB.Z_BI_all[i1]) # 更新遭受实际银行内负债冲击
        # update_B_Shock!(BB, BI,b,ib; byWay = "Shock_B_Z")
        # update_B_state!(BB, BI; to = "illiquity", from = "healthy")
        # BB.Z_BI_all[b] = max.(BB.Z_BI_all[b] - BB.Shock_B_Z[b], 0.0) # 银行之银行间负债变动
        # update_B_balanceSheet!(BB, BI,b,ib; byWay = "Z_BI_all")
        # BB.A_Q[b] = max.(BB.A_Q[b] - BB.Shock_B_Z[b], 0.0) # 银行之流动资产变动
        # update_B_state!(BB, BI; to = "illiquity", from = "healthy") # 更新各银行之状态，从健康到破产
        # update_B_state!(BB, BI; to = "bankrupt", from = "illiquity") # 更新各银行之状态，从健康到破产
        # update_B_balanceSheet!(BB, BI,b,ib; byWay = "A_Q")
        # BB.A_BI_all[BB.isIlliquity] = BB_t0.A_BI_all[BB.isIlliquity] - ((BB.Shock_B_Z[BB.isIlliquity] - BB_t0.A_Q[BB.isIlliquity]) ./ (BB_t0.A_P[BB.isIlliquity] + BB_t0.A_BI_all[BB.isIlliquity]) .* BB_t0.A_BI_all[BB.isIlliquity]) # 银行间资产应变动，由于回收资产
        # update_B_balanceSheet!(BB, BI,b,ib; byWay = "A_BI_all") # 更新资产负债表，通过A_P或A_BI_all
        # BB.Shock_BI_run_ilq_s[b] = abs.(BB.A_BI_all[b] - BB_t0.A_BI_all[b]) # 计算应银行内冲击传导至银行间传染冲击
        # update_B_Shock!(BB, BI,b,ib; byWay = "Shock_BI_run_ilq_s") # 汇总各银行之流动性短缺流动性挤兑冲击
        # BB.A_P[BB.isIlliquity] = BB_t0.A_P[BB.isIlliquity] - ((BB.Shock_B_Z[BB.isIlliquity] - BB_t0.A_Q[BB.isIlliquity]) ./ (BB_t0.A_P[BB.isIlliquity] + BB_t0.A_BI_all[BB.isIlliquity]) .* BB_t0.A_P[BB.isIlliquity]) # 非银行间贷款资产应变动，由于回收资产
        # update_B_balanceSheet!(BB, BI,b,ib; byWay = "A_P") # 更新资产负债表，通过A_P或A_BI_all
        # BB.Shock_L_exBI_s[b] = abs.(BB.A_P[b] - BB_t0.A_P[b]) # 银行内冲击传导至银行厂商贷款传染冲击
        # i0 = (BB.isBankrupt .&& BB.isIlliquity) # 计算状态之于银行集合其满足破产和流动性短缺
        # BB.Shock_BI_run_br_s[i0] = BB.A_BI_all[i0] # 流动性短缺的银行内冲击传导至银行倒闭冲击
        # update_B_Shock!(BB, BI,b,ib; byWay = "Shock_BI_run_br_s") # 汇总各银行之倒闭流动性挤兑冲击


        ## 设置临时变量
        BB_t2 = deepcopy(BB)
        BI_t2 = deepcopy(BI)

        ## 破产清算阶段$t_{3}$：，当$\env.tau>1$时：
        println("t3 开始破产清算阶段")
        # br = BB.isBankrupt # 临时设置破产银行示性变量
        # cre_br = BI.listOfCreditors # 临时设置BI之列表之于上一回合破产的银行之债权方银行编号
        # BB.A_BI_all[BB.isBankrupt] .= 0.0 # 银行间资产应变动，由于回收资产
        # BB.A_P[BB.isBankrupt] .= 0.0 # 非银行间贷款资产应变动，由于回收资产
        BB.Shock_BI_run_br_s[BB.isBankrupt] = abs.(BB.A_BI_all[BB.isBankrupt] - BB_t2.A_BI_all[BB.isBankrupt]) # 倒闭的银行之银行内冲击传导至银行倒闭挤兑流动冲击
        update_B_Shock!(BB, BI, b, ib; byWay = "Shock_BI_run_br_s") # 汇总各银行之倒闭流动性挤兑冲击
        BB.Shock_L_exBI_s[BB.isBankrupt] = abs.(BB.A_P[BB.isBankrupt] - BB_t2.A_P[BB.isBankrupt]) # 银行内冲击传导至银行厂商贷款传染冲击
        # for i in findall(br) # 破产银行偿还银行间借款，破产银行对应债权银行之银行间资产变成各自债权银行之其它资产
        #     BB.A_other[cre_br[i]], BI.A_BI[cre_br[i], i] = transfer_B_capital(; target = BB.A_other[cre_br[i]], source = BI.A_BI[cre_br[i], i])
        #     # BB.A_other[cre_br[i]] += BI.A_BI[cre_br[i], i]
        #     # BI.A_BI[cre_br[i], i] .= 0.0
        # end
        # update_B_balanceSheet!(BB, BI,b,ib; byWay = "alter from A_BI") # 转换银行间资产负债邻接矩阵
        # update_B_balanceSheet!(BB, BI,b,ib; byWay = "A_other") # 更新各银行之资产负债表变量，通过其它资产
        # BB.A_P[br] .= 0.0 # 破产银行之非银行间贷款清零
        # BB.A_Q[br] .= 0.0 # 破产银行之流动资金清零
        # BB.A_R[br] .= 0.0 # 破产银行之存款准备金清零
        # BB.A_other[br] .= 0.0 # 破产银行之其它资产清零
        # update_B_balanceSheet!(BB, BI,b,ib; byWay = "A_exBI") # 更新各银行之资产负债表变量，通过非银行间资产
        # BB.Z_D[br] .= 0.0 # 破产银行之居民存款清零，为了偿还剩余存款负债
        # BB.Z_other[br] .= 0.0 # 破产银行之其它负债清零
        # BB.Z_BI_all[br] .= 0.0 # 破产银行之银行间贷款清零，为了偿还所有银行间负债
        # update_B_balanceSheet!(BB, BI,b,ib; byWay = "Z_exBI") # 更新各银行之资产负债表变量，通过非银行间负债
        # update_B_state!(BB, BI; to = "off", from = "bankrupt") # 更新各银行之状态，从破产到退出



        # ## 上一回合破产的银行清算阶段$t_{3}$，当$\env.tau>1$时：#FIXME
        # println("开始破产清算阶段t3")
        # br_t0 = BB_t0.isBankrupt # 临时设置上一回合破产银行示性变量
        # cre_br_t0 = BI_t0.listOfCreditors # 临时设置BI之列表之于上一回合破产的银行之债权方银行编号
        # for i in findall(br_t0) # 破产银行偿还银行间借款，破产银行对应债权银行之银行间资产变成各自债权银行之其它资产
        #     BB.A_other[cre_br_t0[i]], BI.A_BI[cre_br_t0[i], i] = transfer_B_capital(; target = BB.A_other[cre_br_t0[i]], source = BI.A_BI[cre_br_t0[i], i])
        #     # BB.A_other[cre_br_t0[i]] += BI.A_BI[cre_br_t0[i], i]
        #     # BI.A_BI[cre_br_t0[i], i] .= 0.0
        # end
        # update_B_balanceSheet!(BB, BI,b,ib; byWay = "alter from A_BI") # 转换银行间资产负债邻接矩阵
        # # update_B_balanceSheet!(BB, BI,b,ib; byWay = "sum A_BI") # 加总银行间资产变量
        # # update_B_balanceSheet!(BB, BI,b,ib; byWay = "sum Z_BI") # 加总银行间负债变量
        # update_B_balanceSheet!(BB, BI,b,ib; byWay = "A_other") # 更新各银行之资产负债表变量，通过其它资产
        # BB.A_BI_all[br_t0] .= 0.0 # 破产银行之银行间贷款清零
        # BB.A_P[br_t0] .= 0.0 # 破产银行之非银行间贷款清零
        # BB.A_Q[br_t0] .= 0.0 # 破产银行之流动资金清零
        # BB.A_R[br_t0] .= 0.0 # 破产银行之存款准备金清零
        # BB.A_other[br_t0] .= 0.0 # 破产银行之其它资产清零
        # update_B_balanceSheet!(BB, BI,b,ib; byWay = "A_exBI") # 更新各银行之资产负债表变量，通过非银行间资产
        # BB.Z_D[br_t0] .= 0.0 # 破产银行之居民存款清零
        # BB.Z_other[br_t0] .= 0.0 # 破产银行之其它负债清零
        # BB.Z_BI_all[br_t0] .= 0.0 # 破产银行之银行间贷款清零
        # update_B_balanceSheet!(BB, BI,b,ib; byWay = "Z_D") # 更新各银行之资产负债表变量，通过非银行间负债
        # update_B_state!(BB, BI; to = "off", from = "bankrupt") # 更新各银行之状态，从破产到退出

        ## 尾声阶段$t_{4}$，当$\env.tau>1$时：
        println("t4 开始尾声阶段")



        # update_B_state!(BB, BI; to = "any", from = "any") # 更新本轮银行B示性向量，被使用于下一回合


        ## 存储数据
        BB_tau[env.tau] = deepcopy(BB) # 存储该回合传染结果数据
        BI_tau[env.tau] = deepcopy(BI) # 存储该回合传染结果数据

        ## 清零银行内冲击变量
        update_B_Shock!(BB, BI, b, ib; byWay = "clear Shock_B") # 清零银行内资产负债冲击

        ## 判定本回合是否有银行转移状态从健康状态至其他状态，如果无则后续处理然后结束本轮，如果有则继续处理。
        if BB.isHealthy == BB_t0.isHealthy
            env.is_end_round = true
        end


    end # while

    println("传染过程结束")
    ## 收尾
    # update_B_balanceSheet!(BB, BI,b,ib; byWay = "calc all E_all") # 更新计算各银行之所有者权益
    # BB_tau[env.tau] = deepcopy(BB) # 存储该回合传染结果数据
    # BI_tau[env.tau] = deepcopy(BI) # 存储该回合传染结果数据
    #TODO 最终破产清算

    return BB, BI, BB_tau, BI_tau

    println("model_BI1111结束。")

end # end function


# end; # process


