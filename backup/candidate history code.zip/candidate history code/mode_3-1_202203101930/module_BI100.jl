
## 模块之银行间市场BI100

##########################################
#使用：在用；
#状态：进行中；
##########################################

# module ModuleBI100

include("./fun_initVariables.jl")
include("./functions.jl")



# testing
# print(obj_BI)

## 生成初始外生冲击
tau = 1 # 初始化传染轮次

## 存储初始轮次传染结果数据
obj_BB_tau[tau] = obj_BB
obj_BI_tau[tau] = obj_BI

while (tau <= p.max_num_tau) # 开始传染回合
    println("开始传染回合$tau")
    ## 初始阶段$t_{0}$：
    println("初始阶段")


    ## 临时设置变量
    obj_BB_t0 = deepcopy(obj_BB) # 临时设置BB变量，在阶段0
    obj_BI_t0 = deepcopy(obj_BI) # 临时设置BI变量，在阶段0
    sol = .!obj_BB.isInsolvent # 临时设置BB有偿付能力的示性变量，在阶段0
    ins = obj_BB.isInsolvent # 临时设置BB资不抵债的示性变量，在阶段0
    msol = calc_isHealthy(obj_BB) # 临时设置变量之于BB有偿付能力的遮罩，在阶段0
    mins = calc_isInsolvent(obj_BB) # 临时设置变量之于BI资不抵债的遮罩，在阶段0
    if tau > 1 # 后续轮次$\tau_{i}>1$之阶段$t_{0}$
        obj_BB.Loss_BI = obj_BB.Loss_def + obj_BB.Loss_run
    else # 初始轮次$\tau_{0}$之阶段$t_{0}$
        obj_BB.Loss_BI = obj_BB.Loss_exBI
    end

    ## 被冲击和传染阶段$t_{1}$：
    if tau > 1 # 后续轮次$\tau_{i}>1$之阶段$t_{1}$
        obj_BB.Loss_A[sol] = max.(loss_init_BI[sol], obj_BB.A_BI[sol])
        obj_BB.A_BI[sol] = max.(obj_BB.A_BI[sol] - obj_BB.Loss_A[sol], 0)
    else # 初始轮次$\tau_{0}$之阶段$t_{1}$
        obj_BB.Loss_A[sol] = max.(loss_init_BI[sol], obj_BB.Loss_exBI[sol])
        obj_BB.A_exBI[sol] = max.(obj_BB.A_exBI[sol] - obj_BB.Loss_A[sol], 0)
    end

    update_B_balanceSheet!(obj_BB) # 更新各银行之资产负债表变量 # 要加上示性变量避免资不抵债银行进入运算中

    update_isInsolvent!(obj_BB) # 更新截止本轮资不抵债的银行示性向量

    obj_BB.setOfInsolvent = calc_setOfInsolvent(obj_BB) # 获得截止本轮资不抵债的银行集合

    ## 判定本轮是否有银行资不抵债，如果无则结束本轮，如果有则这些银行标记为资不抵债，继续处理。
    if obj_BB.isInsolvent == obj_BB_t0.isInsolvent
        # tau = 0 # 归零传染轮次
        # TODO 直接跳转尾声阶段$t_{3}$
        break
    end

    ## 银行间资产负债违约冲击传染方式$i_{br} \stackrel{def,BI}{\longrightarrow} j_{cre}$：


    ## 违约偿付方式：负债偿付等级相同。
    ## 计算资不抵债银行导致对债权银行负债变动：
    obj_BB.Z_BI = update_B_Z_BI(obj_BI)
    update_B_Z_all!(obj_BB)
    update_setOfCreditorsInInsolvent!(obj_BB, obj_BI) # 更新集合之于资不抵债银行之债权方银行
    update_setOfDebtorsInInsolvent!(obj_BB, obj_BI) # 更新集合之于资不抵债银行之债务方银行
    rate_BB_Z_all_in_insolvent = obj_BB.Z_all ./ obj_BB_t0.Z_all
    # for i in obj_BB.setOfInsolvent
    #     obj_BI.Z_BI[i, obj_BI.haveExposure[i, :]] = obj_BI_t0.Z_BI[i, obj_BI_t0.haveExposure[i, :]] * rate_BB_Z_all_in_insolvent[i] # 计算资不抵债银行对应债权银行之负债实际价值时变形式：方式一
    #     alter_BI_A(obj_BI)
    # end
    for i in obj_BB.setOfInsolvent
        if obj_BB.setOfCreditorsInInsolvent[i] == []
            continue
        else
            obj_BI.Z_BI[i, obj_BB.setOfCreditorsInInsolvent[i][:]] .= obj_BI_t0.Z_BI[i, obj_BB.setOfCreditorsInInsolvent[i][:]] * rate_BB_Z_all_in_insolvent[i] # 计算资不抵债银行对应债权银行之负债实际价值时变形式：方式二
            alter_BI_A(obj_BI)
        end
    end

    ## 债权银行资产时变形式：
    obj_BB.A_BI .= obj_BB_t0.

    ## TODO 资不抵债和传染阶段$t_{2}$：


    ## TODO 尾声阶段$t_{3}$：


    ## 存储该轮次传染结果数据
    obj_BB_tau[tau] = obj_BB
    obj_BI_tau[tau] = obj_BI

    ## TODO 判断下一轮次传染是否进行

    global tau += 1 # 传染轮次累加一
end # while










# end; # module


