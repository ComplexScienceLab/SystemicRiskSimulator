## 计算损失

##########################################
#使用：在用；
#状态：进行中；
##########################################

include("./defineType.jl")
# include("./setParameters.jl")
# include("./fun_initVariables.jl")


## 函数区



## 更新各银行与各银行间之损失


"计算各银行之银行间损失。"
calc_B_Loss(interbank_Loss)=sum(interbank_Loss,dims=2)












