
## 模块集之银行内负债冲击

##########################################
#使用：备用；
#状态：未完；
##########################################

## # TODO 模块之银行内负债冲击1

function ()
    BB.A_Q[on] = max.(BB.A_Q[on] - BB.Shock_B_Z[on], 0) # 流动资产变动
    update_B_balanceSheet!(BB, BI, byWay = "A_Q")
    # i = findall(BB.Shock_B_Z[on] .> BB_t0.A_Q[on])
    # BB.A_BI_all[i] = BB.A_BI_all[i] .* (1 - (BB.Shock_B_Z[i] - BB_t0.A_Q[i]) ./ BB_t0.A_all[i]) # 银行间资产变动，由于回收资产
    # BB.A_P[i] = BB.A_P[i] .* (1 - (BB.Shock_B_Z[i] - BB_t0.A_Q[i]) ./ BB_t0.A_all[i]) # 非银行间贷款资产变动，由于回收资产
    BB.A_BI_all[BB.isIlliquity] = BB.A_BI_all[BB.isIlliquity] .* (1 - (BB.Shock_B_Z[BB.isIlliquity] - BB_t0.A_Q[BB.isIlliquity]) ./ BB_t0.A_all[BB.isIlliquity]) # 银行间资产变动，由于回收资产
    BB.A_P[BB.isIlliquity] = BB.A_P[BB.isIlliquity] .* (1 - (BB.Shock_B_Z[BB.isIlliquity] - BB_t0.A_Q[BB.isIlliquity]) ./ BB_t0.A_all[BB.isIlliquity]) # 非银行间贷款资产变动，由于回收资产
    update_B_balanceSheet!(BB, BI; byWay = "A_P") # 更新资产负债表，通过A_P或A_BI_all
    BB.Shock_BI_run_ilq_s[on] = abs.(BB.A_BI_all[on] - BB_t0.A_BI[on]) # 银行内冲击传导至银行间传染冲击
    update_B_Shock!(BB, BI; byWay = "Shock_BI_run_ilq_s")

end
