## 设置参数
# module SetParameters

##########################################
#使用：在用；
#状态：进行中；
##########################################

include("./defineType.jl")


p = Parameters("", 0, 0, 0, 0, []) # 初始化参数结构体
dict_initMethods = Dict([(0, "only init"), (1, "randomly"), (2, "import data"), (3, "set manually")]) # 字典之于初始化数据方式


######### 设置参数 #########
p.init_method = dict_initMethods[3] # 初始化数据方式
p.num_bank = 5 # 银行个数
p.num_assets = 3 # 资产种类数
p.max_num_tau = 10 # 最大传染轮次数
p.theta_Shock_exBI_t = 1.0 # 外生冲击类型占比
p.set_Shock_exB = [1] # 指定遭受初始外生冲击的银行示性集合


###########################



# end; # module





