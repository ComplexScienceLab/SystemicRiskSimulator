"过程：初始化各类变量"

## 初始化各类变量

##########################################
#使用：在用；
#状态：进行中；
##########################################

# module InitVariables
# export obj_BI,initObj

include("./setParameters.jl")
include("./defineType.jl")
include("./defineConst.jl")
include("./functions.jl")

using StructArrays


## 定义变量
tau = 1 # 初始化传染轮次编号





"仅初始化银行变量"
function init_B_variables_only()
    bank = BankCommercial{1,1}(
        RANGE1, # 编号id
        BLANK1, # 缩写abbr
        BLANK1, # 全名name
        ones(p.num_bank), # 总资产A_all：$A_all=A_BI+A_exBI$
        ones(p.num_bank), # 银行间资产加总A_BI_all
        ones(p.num_bank), # 非银行间资产A_exBI：$A_exBI=A_P+A_Q+A_R+A_other$
        ones(p.num_bank), # 银行贷款给生产部门之资产（非流动性资产）A_P
        ones(p.num_bank), # 银行持有超额准备金（流动性资产）A_Q
        ones(p.num_bank), # 银行持有法定准备金（非流动性资产）A_R
        ones(p.num_bank), # 银行持有的其它资产（非流动性资产）A_other
        ones(p.num_bank), # 总负债Z_all：$Z_total=Z_BI+Z_exBI$
        ones(p.num_bank), # 银行间负债加总Z_BI_all
        ones(p.num_bank), # 非银行间负债Z_exBI：$Z_exBI=Z_D+Z_other$
        ones(p.num_bank), # 银行获得居民部门存款（非流动性负债）Z_D
        ones(p.num_bank), # 银行持有的其他负债（非流动性负债）Z_other
        ones(p.num_bank), # 所有者权益E_all
        zeros(p.num_bank), # 总贷款Lo_all：$Lo_all=Lo_BI+Lo_exBI$
        zeros(p.num_bank), # 银行间贷款Lo_BI
        zeros(p.num_bank), # 非银行间贷款Lo_exBI：$Lo_exBI=Lo_P$
        zeros(p.num_bank), # 银行贷款给生产部门Lo_P
        zeros(p.num_bank), # 总借款Li_all：$Li_all=Li_BI+Li_exBI$
        zeros(p.num_bank), # 银行间借款Li_BI
        zeros(p.num_bank), # 非银行间借款Li_exBI：$Li_exBI=Li_D$
        zeros(p.num_bank), # 银行获得居民部门存款借款Li_D
        zeros(p.num_bank), # 银行外市场冲击Shock_exBI：$Shock_exBI_t = Shock_L_exBI_t and Shock_D_t$
        zeros(p.num_bank), # 银行之非银行间贷款挤兑流动冲击源头Shock_L_exBI_s
        zeros(p.num_bank), # 银行之非银行间贷款违约损失冲击目标Shock_L_exBI_t
        zeros(p.num_bank), # 银行存款违约损失冲击源头Shock_D_s
        zeros(p.num_bank), # 银行存款挤兑流动冲击目标Shock_D_t
        zeros(p.num_bank), # 银行内资产负债冲击Shock_B：$Shock_B=Shock_B_A+Shock_B_Z$
        zeros(p.num_bank), # 银行内资产负债之银行间资产端冲击Shock_B_A
        zeros(p.num_bank), # 银行内资产负债之银行间负债端冲击Shock_B_Z
        zeros(p.num_bank), # 银行间冲击源头Shock_BI_s：$Shock_BI_s=Shock_BI_def_s+Shock_BI_run_s$
        zeros(p.num_bank), # 银行间冲击目标Shock_BI_t：$Shock_BI_t=Shock_BI_def_t+Shock_BI_run_t$
        zeros(p.num_bank), # 银行间违约损失冲击源头Shock_BI_def_s
        zeros(p.num_bank), # 银行间违约损失冲击目标Shock_BI_def_t
        zeros(p.num_bank), # 银行间挤兑流动冲击源头Shock_BI_run_s：$Shock_BI_run_s=Shock_BI_run_ilq_s+Shock_BI_run_br_s$
        zeros(p.num_bank), # 银行间挤兑流动冲击目标Shock_BI_run_t：$Shock_BI_run_t+Shock_BI_run_ilq_t+Shock_BI_run_br_t$
        zeros(p.num_bank), # 银行间挤兑流动冲击源头Shock_BI_run_ilq_s
        zeros(p.num_bank), # 银行间挤兑流动冲击目标Shock_BI_run_ilq_t
        zeros(p.num_bank), # 银行间挤兑流动冲击源头Shock_BI_run_br_s
        zeros(p.num_bank), # 银行间挤兑流动冲击目标Shock_BI_run_br_t
        zeros(p.num_bank), # 银行间市场冲击损失Loss_BI
        zeros(p.num_bank), # 银行间资产负债违约冲击损失Loss_BI_def_t
        zeros(p.num_bank), # 银行间负债流动性挤兑冲击损失Loss_BI_run_t
        trues(p.num_bank), # 示性向量之于银行是否存在isOn
        falses(p.num_bank), # 示性向量之于银行是否已退出不存在isOff
        trues(p.num_bank), # 示性向量之于银行是否健康isHealthy
        falses(p.num_bank), # 示性向量之于银行是否资不抵债isInsolvent
        falses(p.num_bank), # 示性向量之于银行是否流动性短缺isIlliquity
        falses(p.num_bank), # 示性向量之于银行是否破产isBankrupt
        [], # 列表之于存在的银行编号listOfExist
        [], # 列表之于资不抵债的银行编号listOfInsolvent
        [], # 列表之于流动性短缺的银行编号listOfIlliquity
        []  # 列表之于破产的银行编号listOfBankrupt
    )
    ## 初始化银行间邻接矩阵
    interbank = BankInterbank{2}(
        # reshape(range(1, p.num_bank^2, step = 1), (p.num_bank, p.num_bank)), # 编号
        zeros(p.num_bank, p.num_bank), # 银行间资产邻接矩阵A_BI
        zeros(p.num_bank, p.num_bank), # 银行间负债邻接矩阵Z_BI
        zeros(p.num_bank, p.num_bank), # 银行间贷款邻接矩阵Lo_BI
        zeros(p.num_bank, p.num_bank), # 银行间借款邻接矩阵Li_BI
        zeros(p.num_bank, p.num_bank), # 银行间冲击Shock_BI：$Shock_BI=Shock_BI_def+Shock_BI_run$
        zeros(p.num_bank, p.num_bank), # 银行间违约损失冲击Shock_BI_def
        zeros(p.num_bank, p.num_bank), # 银行间挤兑流动冲击Shock_BI_run：$Shock_BI_run=Shock_BI_run_ilq+Shock_BI_run_br$
        zeros(p.num_bank, p.num_bank), # 流动性短缺银行银行间挤兑流动冲击Shock_BI_run_ilq
        zeros(p.num_bank, p.num_bank), # 破产银行银行间挤兑流动冲击    Shock_BI_run_br
        zeros(p.num_bank, p.num_bank), # 银行间市场冲击损失Loss_BI
        zeros(p.num_bank, p.num_bank), # 银行间资产负债违约冲击损失Loss_BI_def
        zeros(p.num_bank, p.num_bank), # 银行间负债流动性挤兑冲击损失Loss_BI_run
        # zeros(p.num_bank, p.num_bank), # 信息邻接矩阵之于是否有银行间敞口
        trues(p.num_bank, p.num_bank), # 信息邻接矩阵之于银行间存在的isOn
        falses(p.num_bank, p.num_bank), # 信息邻接矩阵之于银行间已退出不存在的isOff
        trues(p.num_bank, p.num_bank), # 信息邻接矩阵之于银行间健康的isHealthy
        falses(p.num_bank, p.num_bank), # 信息邻接矩阵之于银行间资不抵债的isInsolvent
        falses(p.num_bank, p.num_bank), # 信息邻接矩阵之于银行间流动性短缺的isIlliquity
        falses(p.num_bank, p.num_bank), # 信息邻接矩阵之于银行间破产的isBankrupt
        [], # 信息列表之于各银行之债权方银行编号listOfCreditors
        [], # 信息列表之于各银行之债务方银行编号listOfDebtors
        [], # 信息列表之于资不抵债的银行之债权方银行编号listOfCreditorsInInsolvent
        [], # 信息列表之于资不抵债的银行之债务方银行编号listOfDebtorsInInsolvent
        [], # 信息列表之于流动性短缺的银行之债权方银行编号listOfCreditorsInIlliquity
        [], # 信息列表之于流动性短缺的银行之债务方银行编号listOfDebtorsInIlliquity
        [], # 信息列表之于破产的银行之债权方银行编号listOfCreditorsInBankrupt
        [] # 信息列表之于破产的银行之债务方银行编号listOfDebtorsInBankrupt
    )

    # 初始化商业银行实例 #HACK 如果后续验证可以用ZEROS2，则启用之，代替原来的。
    # bank = BankCommercial{1,1}(
    #     RANGE1, # 编号id
    #     BLANK1, # 缩写abbr
    #     BLANK1, # 全名name
    #     ONES1, # 总资产A_all：$A_all=A_BI+A_exBI$
    #     ONES1, # 银行间资产加总A_BI_all
    #     ONES1, # 非银行间资产A_exBI：$A_exBI=A_P+A_Q+A_R+A_other$
    #     ONES1, # 银行贷款给生产部门之资产（非流动性资产）A_P
    #     ONES1, # 银行持有超额准备金（流动性资产）A_Q
    #     ONES1, # 银行持有法定准备金（非流动性资产）A_R
    #     ONES1, # 银行持有的其它资产（非流动性资产）A_other
    #     ONES1, # 总负债Z_all：$Z_total=Z_BI+Z_exBI$
    #     ONES1, # 银行间负债加总Z_BI_all
    #     ONES1, # 非银行间负债Z_exBI：$Z_exBI=Z_D+Z_other$
    #     ONES1, # 银行获得居民部门存款（非流动性负债）Z_D
    #     ONES1, # 银行持有的其他负债（非流动性负债）Z_other
    #     ONES1, # 所有者权益E_all
    #     ZEROS1, # 总贷款Lo_all：$Lo_all=Lo_BI+Lo_exBI$
    #     ZEROS1, # 银行间贷款Lo_BI
    #     ZEROS1, # 非银行间贷款Lo_exBI：$Lo_exBI=Lo_P$
    #     ZEROS1, # 银行贷款给生产部门Lo_P
    #     ZEROS1, # 总借款Li_all：$Li_all=Li_BI+Li_exBI$
    #     ZEROS1, # 银行间借款Li_BI
    #     ZEROS1, # 非银行间借款Li_exBI：$Li_exBI=Li_D$
    #     ZEROS1, # 银行获得居民部门存款借款Li_D
    #     ZEROS1, # 银行外市场冲击Shock_exBI：$Shock_exBI_t = Shock_L_exBI_t and Shock_D_t$
    #     ZEROS1, # 银行之非银行间贷款挤兑流动冲击源头Shock_L_exBI_s
    #     ZEROS1, # 银行之非银行间贷款违约损失冲击目标Shock_L_exBI_t
    #     ZEROS1, # 银行存款违约损失冲击源头Shock_D_s
    #     ZEROS1, # 银行存款挤兑流动冲击目标Shock_D_t
    #     ZEROS1, # 银行内资产负债冲击Shock_B：$Shock_B=Shock_B_A+Shock_B_Z$
    #     ZEROS1, # 银行内资产负债之银行间资产端冲击Shock_B_A
    #     ZEROS1, # 银行内资产负债之银行间负债端冲击Shock_B_Z
    #     ZEROS1, # 银行间冲击源头Shock_BI_s：$Shock_BI_s=Shock_BI_def_s+Shock_BI_run_s$
    #     ZEROS1, # 银行间冲击目标Shock_BI_t：$Shock_BI_t=Shock_BI_def_t+Shock_BI_run_t$
    #     ZEROS1, # 银行间违约损失冲击源头Shock_BI_def_s
    #     ZEROS1, # 银行间违约损失冲击目标Shock_BI_def_t
    #     ZEROS1, # 银行间挤兑流动冲击源头Shock_BI_run_s：$Shock_BI_run_s=Shock_BI_run_ilq_s+Shock_BI_run_br_s$
    #     ZEROS1, # 银行间挤兑流动冲击目标Shock_BI_run_t：$Shock_BI_run_t+Shock_BI_run_ilq_t+Shock_BI_run_br_t$
    #     ZEROS1, # 银行间挤兑流动冲击源头Shock_BI_run_ilq_s
    #     ZEROS1, # 银行间挤兑流动冲击目标Shock_BI_run_ilq_t
    #     ZEROS1, # 银行间挤兑流动冲击源头Shock_BI_run_br_s
    #     ZEROS1, # 银行间挤兑流动冲击目标Shock_BI_run_br_t
    #     ZEROS1, # 银行间市场冲击损失Loss_BI
    #     ZEROS1, # 银行间资产负债违约冲击损失Loss_BI_def_t
    #     ZEROS1, # 银行间负债流动性挤兑冲击损失Loss_BI_run_t
    #     TRUE1, # 示性向量之于银行是否存在isOn
    #     FALSE1, # 示性向量之于银行是否已退出不存在isOff
    #     TRUE1, # 示性向量之于银行是否健康isHealthy
    #     FALSE1, # 示性向量之于银行是否资不抵债isInsolvent
    #     FALSE1, # 示性向量之于银行是否流动性短缺isIlliquity
    #     FALSE1, # 示性向量之于银行是否破产isBankrupt
    #     [], # 列表之于存在的银行编号listOfExist
    #     [], # 列表之于资不抵债的银行编号listOfInsolvent
    #     [], # 列表之于流动性短缺的银行编号listOfIlliquity
    #     []  # 列表之于破产的银行编号listOfBankrupt
    # )
    # 初始化银行间邻接矩阵 #HACK 如果后续验证可以用ZEROS2，则启用之，代替原来的。
    #     # reshape(range(1, p.num_bank^2, step = 1), (p.num_bank, p.num_bank)), # 编号
    #     ZEROS2, # 银行间资产邻接矩阵A_BI
    #     ZEROS2, # 银行间负债邻接矩阵Z_BI
    #     ZEROS2, # 银行间贷款邻接矩阵Lo_BI
    #     ZEROS2, # 银行间借款邻接矩阵Li_BI
    #     ZEROS2, # 银行间冲击Shock_BI：$Shock_BI=Shock_BI_def+Shock_BI_run$
    #     ZEROS2, # 银行间违约损失冲击Shock_BI_def
    #     ZEROS2, # 银行间挤兑流动冲击Shock_BI_run：$Shock_BI_run=Shock_BI_run_ilq+Shock_BI_run_br$
    #     ZEROS2, # 流动性短缺银行银行间挤兑流动冲击Shock_BI_run_ilq
    #     ZEROS2, # 破产银行银行间挤兑流动冲击    Shock_BI_run_br
    #     ZEROS2, # 银行间市场冲击损失Loss_BI
    #     ZEROS2, # 银行间资产负债违约冲击损失Loss_BI_def
    #     ZEROS2, # 银行间负债流动性挤兑冲击损失Loss_BI_run
    #     # ZEROS2, # 信息邻接矩阵之于是否有银行间敞口
    #     TRUE2, # 信息邻接矩阵之于银行间存在的isOn
    #     FALSE2, # 信息邻接矩阵之于银行间已退出不存在的isOff
    #     TRUE2, # 信息邻接矩阵之于银行间健康的isHealthy
    #     FALSE2, # 信息邻接矩阵之于银行间资不抵债的isInsolvent
    #     FALSE2, # 信息邻接矩阵之于银行间流动性短缺的isIlliquity
    #     FALSE2, # 信息邻接矩阵之于银行间破产的isBankrupt
    #     [], # 信息列表之于各银行之债权方银行编号listOfCreditors
    #     [], # 信息列表之于各银行之债务方银行编号listOfDebtors
    #     [], # 信息列表之于资不抵债的银行之债权方银行编号listOfCreditorsInInsolvent
    #     [], # 信息列表之于资不抵债的银行之债务方银行编号listOfDebtorsInInsolvent
    #     [], # 信息列表之于流动性短缺的银行之债权方银行编号listOfCreditorsInIlliquity
    #     [], # 信息列表之于流动性短缺的银行之债务方银行编号listOfDebtorsInIlliquity
    #     [], # 信息列表之于破产的银行之债权方银行编号listOfCreditorsInBankrupt
    #     [] # 信息列表之于破产的银行之债务方银行编号listOfDebtorsInBankrupt
    # )

    return bank, interbank

end





#TODO"随机化初始化银行变量"
function init_B_variables_randomly()

end


#TODO"导入数据以初始化银行变量"
function init_B_variables_importData()

end

"手动设置以初始化银行变量"
function initVariables_setManually()
    bank = BankCommercial{1,1}(
        range(1, p.num_bank, step = 1), # 编号id
        ["1", "2", "3", "4", "5"], # 缩写abbr
        ["BK1", "BK2", "BK3", "BK4", "BK5"], # 全名name
        zeros(p.num_bank), # 总资产A_all：$A_all=A_BI+A_exBI$
        [2185.24, 398.37, 730.99, 1357.75, 2717.39], # 银行间资产加总A_BI_all
        zeros(p.num_bank), # 非银行间资产A_exBI：$A_exBI=A_P+A_Q+A_R+A_other$
        [1631.73, 4303.24, 3379.72, 4351.47, 620.69], # 银行贷款给生产部门之资产（非流动性资产）A_P
        # [433.75, 534.266, 467.134, 648.784, 379.324], # 银行持有超额准备金（流动性资产）A_Q
        [477.125, 587.693, 513.847, 713.662, 417.257], # 银行持有超额准备金（流动性资产）A_Q
        zeros(p.num_bank), # 银行持有法定准备金（非流动性资产）A_R
        # [86.75, 106.85, 93.43, 129.76, 75.86], # 银行持有法定准备金（非流动性资产）A_R
        zeros(p.num_bank), # 银行持有的其它资产（非流动性资产）A_other
        zeros(p.num_bank), # 总负债Z_all：$Z_total=Z_BI+Z_exBI$
        [959.6, 1844.24, 1253.34, 2851.85, 480.71], # 银行间负债加总Z_BI_all
        zeros(p.num_bank), # 非银行间负债Z_exBI：$Z_exBI=Z_D+Z_other$
        [3160.99, 3231.37, 3184.36, 3311.51, 3122.9], # 银行获得居民部门存款（非流动性负债）Z_D
        zeros(p.num_bank), # 银行持有的其他负债（非流动性负债）Z_other
        [216.83, 267.13, 233.56, 324.39, 189.66], # 所有者权益E_all
        zeros(p.num_bank), # 总贷款Lo_all：$Lo_all=Lo_BI+Lo_exBI$
        zeros(p.num_bank), # 银行间贷款Lo_BI
        zeros(p.num_bank), # 非银行间贷款Lo_exBI：$Lo_exBI=Lo_P$
        zeros(p.num_bank), # 银行贷款给生产部门Lo_P
        zeros(p.num_bank), # 总借款Li_all：$Li_all=Li_BI+Li_exBI$
        zeros(p.num_bank), # 银行间借款Li_BI
        zeros(p.num_bank), # 非银行间借款Li_exBI：$Li_exBI=Li_D$
        zeros(p.num_bank), # 银行获得居民部门存款借款Li_D
        zeros(p.num_bank), # 银行外市场冲击Shock_exBI_t：$Shock_exBI_t = Shock_L_exBI_t and Shock_D_t$
        zeros(p.num_bank), # 银行之非银行间贷款挤兑流动冲击源头Shock_L_exBI_s
        [1631.73, 0.0, 0.0, 0.0, 0.0], # 银行之非银行间贷款违约损失冲击目标Shock_L_exBI_t
        zeros(p.num_bank), # 银行存款违约损失冲击源头Shock_D_s
        [3160.99, 0.0, 0.0, 0.0, 0.0], # 银行存款挤兑流动冲击目标Shock_D_t
        zeros(p.num_bank), # 银行内资产负债冲击Shock_B：$Shock_B=Shock_B_A+Shock_B_Z$
        zeros(p.num_bank), # 银行内资产负债之银行间资产端冲击Shock_B_A
        zeros(p.num_bank), # 银行内资产负债之银行间负债端冲击Shock_B_Z
        zeros(p.num_bank), # 银行间冲击源头Shock_BI_s：$Shock_BI_s=Shock_BI_def_s+Shock_BI_run_s$
        zeros(p.num_bank), # 银行间冲击目标Shock_BI_t：$Shock_BI_t=Shock_BI_def_t+Shock_BI_run_t$
        zeros(p.num_bank), # 银行间违约损失冲击源头Shock_BI_def_s
        zeros(p.num_bank), # 银行间违约损失冲击目标Shock_BI_def_t
        zeros(p.num_bank), # 银行间挤兑流动冲击源头Shock_BI_run_s：$Shock_BI_run_s=Shock_BI_run_ilq_s+Shock_BI_run_br_s$
        zeros(p.num_bank), # 银行间挤兑流动冲击目标Shock_BI_run_t：$Shock_BI_run_t+Shock_BI_run_ilq_t+Shock_BI_run_br_t$
        zeros(p.num_bank), # 银行间挤兑流动冲击源头Shock_BI_run_ilq_s
        zeros(p.num_bank), # 银行间挤兑流动冲击目标Shock_BI_run_ilq_t
        zeros(p.num_bank), # 银行间挤兑流动冲击源头Shock_BI_run_br_s
        zeros(p.num_bank), # 银行间挤兑流动冲击目标Shock_BI_run_br_t
        zeros(p.num_bank), # 银行间市场冲击损失Loss_BI
        zeros(p.num_bank), # 银行间资产负债违约冲击损失Loss_BI_def_t
        zeros(p.num_bank), # 银行间负债流动性挤兑冲击损失Loss_BI_run_t
        trues(p.num_bank), # 示性向量之于银行是否存在isOn
        falses(p.num_bank), # 示性向量之于银行是否已退出不存在isOff
        trues(p.num_bank), # 示性向量之于银行是否健康isHealthy
        falses(p.num_bank), # 示性向量之于银行是否资不抵债isInsolvent
        falses(p.num_bank), # 示性向量之于银行是否流动性短缺isIlliquity
        falses(p.num_bank), # 示性向量之于银行是否破产isBankrupt
        [], # 列表之于存在的银行编号listOfExist
        [], # 列表之于资不抵债的银行编号listOfInsolvent
        [], # 列表之于流动性短缺的银行编号listOfIlliquity
        []  # 列表之于破产的银行编号listOfBankrupt
    )
    interbank = BankInterbank{2}(
        # reshape(range(1, p.num_bank^2, step = 1), (p.num_bank, p.num_bank)), # 编号
        [0 1728.55 0 134.46 322.23; 109.35 0 289.02 0 0; 730.99 0 0 0 0; 119.26 115.69 964.32 0 158.48; 0 0 0 2717.39 0], # 银行间资产邻接矩阵A_BI
        [0 1728.55 0 134.46 322.23; 109.35 0 289.02 0 0; 730.99 0 0 0 0; 119.26 115.69 964.32 0 158.48; 0 0 0 2717.39 0]', # 银行间负债邻接矩阵Z_BI
        zeros(p.num_bank, p.num_bank), # 银行间贷款邻接矩阵Lo_BI
        zeros(p.num_bank, p.num_bank), # 银行间借款邻接矩阵Li_BI
        zeros(p.num_bank, p.num_bank), # 银行间冲击Shock_BI：$Shock_BI=Shock_BI_def+Shock_BI_run$
        zeros(p.num_bank, p.num_bank), # 银行间违约损失冲击Shock_BI_def
        zeros(p.num_bank, p.num_bank), # 银行间挤兑流动冲击Shock_BI_run：$Shock_BI_run=Shock_BI_run_ilq+Shock_BI_run_br$
        zeros(p.num_bank, p.num_bank), # 流动性短缺银行银行间挤兑流动冲击Shock_BI_run_ilq
        zeros(p.num_bank, p.num_bank), # 破产银行银行间挤兑流动冲击Shock_BI_run_br
        zeros(p.num_bank, p.num_bank), # 银行间市场冲击损失Loss_BI
        zeros(p.num_bank, p.num_bank), # 银行间资产负债违约冲击损失Loss_BI_def
        zeros(p.num_bank, p.num_bank), # 银行间负债流动性挤兑冲击损失Loss_BI_run
        # zeros(p.num_bank, p.num_bank), # 信息邻接矩阵之于是否有银行间敞口#
        trues(p.num_bank, p.num_bank), # 信息邻接矩阵之于银行间存在的isOn
        falses(p.num_bank, p.num_bank), # 信息邻接矩阵之于银行间已退出不存在的isOff
        trues(p.num_bank, p.num_bank), # 信息邻接矩阵之于银行间健康的isHealthy
        falses(p.num_bank, p.num_bank), # 信息邻接矩阵之于银行间资不抵债的isInsolvent
        falses(p.num_bank, p.num_bank), # 信息邻接矩阵之于银行间流动性短缺的isIlliquity
        falses(p.num_bank, p.num_bank), # 信息邻接矩阵之于银行间破产的isBankrupt
        [], # 信息列表之于各银行之债权方银行编号listOfCreditors
        [], # 信息列表之于各银行之债务方银行编号listOfDebtors
        [], # 信息列表之于资不抵债的银行之债权方银行编号listOfCreditorsInInsolvent
        [], # 信息列表之于资不抵债的银行之债务方银行编号listOfDebtorsInInsolvent
        [], # 信息列表之于流动性短缺的银行之债权方银行编号listOfCreditorsInIlliquity
        [], # 信息列表之于流动性短缺的银行之债务方银行编号listOfDebtorsInIlliquity
        [], # 信息列表之于破产的银行之债权方银行编号listOfCreditorsInBankrupt
        [] # 信息列表之于破产的银行之债务方银行编号listOfDebtorsInBankrupt
    )

    # 初始化商业银行实例 #HACK 如果后续验证可以用ZEROS2，则启用之，代替原来的。
    # bank = BankCommercial{1,1}(
    #     RANGE1, # 编号id
    #     ["1", "2", "3", "4", "5"], # 缩写abbr
    #     ["BK1", "BK2", "BK3", "BK4", "BK5"], # 全名name
    #     ZEROS1, # 总资产A_all：$A_all=A_BI+A_exBI$
    #     [2185.24, 398.37, 730.99, 1357.75, 2717.39], # 银行间资产加总A_BI_all
    #     ZEROS1, # 非银行间资产A_exBI：$A_exBI=A_P+A_Q+A_R+A_other$
    #     [1631.73, 4303.24, 3379.72, 4351.47, 620.69], # 银行贷款给生产部门之资产（非流动性资产）A_P
    #     # [433.75, 534.266, 467.134, 648.784, 379.324], # 银行持有超额准备金（流动性资产）A_Q
    #     [477.125, 587.693, 513.847, 713.662, 417.257], # 银行持有超额准备金（流动性资产）A_Q
    #     ZEROS1, # 银行持有法定准备金（非流动性资产）A_R
    #     # [86.75, 106.85, 93.43, 129.76, 75.86], # 银行持有法定准备金（非流动性资产）A_R
    #     ZEROS1, # 银行持有的其它资产（非流动性资产）A_other
    #     ZEROS1, # 总负债Z_all：$Z_total=Z_BI+Z_exBI$
    #     [959.6, 1844.24, 1253.34, 2851.85, 480.71], # 银行间负债加总Z_BI_all
    #     ZEROS1, # 非银行间负债Z_exBI：$Z_exBI=Z_D+Z_other$
    #     [3160.99, 3231.37, 3184.36, 3311.51, 3122.9], # 银行获得居民部门存款（非流动性负债）Z_D
    #     ZEROS1, # 银行持有的其他负债（非流动性负债）Z_other
    #     [216.83, 267.13, 233.56, 324.39, 189.66], # 所有者权益E_all
    #     ZEROS1, # 总贷款Lo_all：$Lo_all=Lo_BI+Lo_exBI$
    #     ZEROS1, # 银行间贷款Lo_BI
    #     ZEROS1, # 非银行间贷款Lo_exBI：$Lo_exBI=Lo_P$
    #     ZEROS1, # 银行贷款给生产部门Lo_P
    #     ZEROS1, # 总借款Li_all：$Li_all=Li_BI+Li_exBI$
    #     ZEROS1, # 银行间借款Li_BI
    #     ZEROS1, # 非银行间借款Li_exBI：$Li_exBI=Li_D$
    #     ZEROS1, # 银行获得居民部门存款借款Li_D
    #     ZEROS1, # 银行外市场冲击Shock_exBI：$Shock_exBI_t = Shock_L_exBI_t and Shock_D_t$
    #     ZEROS1, # 银行之非银行间贷款挤兑流动冲击源头Shock_L_exBI_s
    #     [1631.73, 0.0, 0.0, 0.0, 0.0], # 银行之非银行间贷款违约损失冲击目标Shock_L_exBI_t
    #     ZEROS1, # 银行存款违约损失冲击源头Shock_D_s
    #     ZEROS1, # 银行存款挤兑流动冲击目标Shock_D_t
    #     ZEROS1, # 银行内资产负债冲击Shock_B：$Shock_B=Shock_B_A+Shock_B_Z$
    #     ZEROS1, # 银行内资产负债之银行间资产端冲击Shock_B_A
    #     ZEROS1, # 银行内资产负债之银行间负债端冲击Shock_B_Z
    #     ZEROS1, # 银行间冲击源头Shock_BI_s：$Shock_BI_s=Shock_BI_def_s+Shock_BI_run_s$
    #     ZEROS1, # 银行间冲击目标Shock_BI_t：$Shock_BI_t=Shock_BI_def_t+Shock_BI_run_t$
    #     ZEROS1, # 银行间违约损失冲击源头Shock_BI_def_s
    #     ZEROS1, # 银行间违约损失冲击目标Shock_BI_def_t
    #     ZEROS1, # 银行间挤兑流动冲击源头Shock_BI_run_s：$Shock_BI_run_s=Shock_BI_run_ilq_s+Shock_BI_run_br_s$
    #     ZEROS1, # 银行间挤兑流动冲击目标Shock_BI_run_t：$Shock_BI_run_t+Shock_BI_run_ilq_t+Shock_BI_run_br_t$
    #     ZEROS1, # 银行间挤兑流动冲击源头Shock_BI_run_ilq_s
    #     ZEROS1, # 银行间挤兑流动冲击目标Shock_BI_run_ilq_t
    #     ZEROS1, # 银行间挤兑流动冲击源头Shock_BI_run_br_s
    #     ZEROS1, # 银行间挤兑流动冲击目标Shock_BI_run_br_t
    #     ZEROS1, # 银行间市场冲击损失Loss_BI
    #     ZEROS1, # 银行间资产负债违约冲击损失Loss_BI_def_t
    #     ZEROS1, # 银行间负债流动性挤兑冲击损失Loss_BI_run_t
    #     TRUE1, # 示性向量之于银行是否存在isOn
    #     FALSE1, # 示性向量之于银行是否已退出不存在isOff
    #     TRUE1, # 示性向量之于银行是否健康isHealthy
    #     FALSE1, # 示性向量之于银行是否资不抵债isInsolvent
    #     FALSE1, # 示性向量之于银行是否流动性短缺isIlliquity
    #     FALSE1, # 示性向量之于银行是否破产isBankrupt
    #     [], # 列表之于存在的银行编号listOfExist
    #     [], # 列表之于资不抵债的银行编号listOfInsolvent
    #     [], # 列表之于流动性短缺的银行编号listOfIlliquity
    #     []  # 列表之于破产的银行编号listOfBankrupt
    # )
    # 初始化银行间邻接矩阵 #HACK 如果后续验证可以用ZEROS2，则启用之，代替原来的。
    # interbank = BankInterbank{2}(
    #     # reshape(range(1, p.num_bank^2, step = 1), (p.num_bank, p.num_bank)), # 编号
    #     [0 1728.55 0 134.46 322.23; 109.35 0 289.02 0 0; 730.99 0 0 0 0; 119.26 115.69 964.32 0 158.48; 0 0 0 2717.39 0], # 银行间资产邻接矩阵A_BI
    #     [0 1728.55 0 134.46 322.23; 109.35 0 289.02 0 0; 730.99 0 0 0 0; 119.26 115.69 964.32 0 158.48; 0 0 0 2717.39 0]', # 银行间负债邻接矩阵Z_BI
    #     ZEROS2, # 银行间贷款邻接矩阵Lo_BI
    #     ZEROS2, # 银行间借款邻接矩阵Li_BI
    #     ZEROS2, # 银行间冲击Shock_BI：$Shock_BI=Shock_BI_def+Shock_BI_run$
    #     ZEROS2, # 银行间违约损失冲击Shock_BI_def
    #     ZEROS2, # 银行间挤兑流动冲击Shock_BI_run：$Shock_BI_run=Shock_BI_run_ilq+Shock_BI_run_br$
    #     ZEROS2, # 流动性短缺银行银行间挤兑流动冲击Shock_BI_run_ilq
    #     ZEROS2, # 破产银行银行间挤兑流动冲击Shock_BI_run_br
    #     ZEROS2, # 银行间市场冲击损失Loss_BI
    #     ZEROS2, # 银行间资产负债违约冲击损失Loss_BI_def
    #     ZEROS2, # 银行间负债流动性挤兑冲击损失Loss_BI_run
    #     # ZEROS2, # 信息邻接矩阵之于是否有银行间敞口#
    #     TRUE2, # 信息邻接矩阵之于银行间存在的isOn
    #     FALSE2, # 信息邻接矩阵之于银行间已退出不存在的isOff
    #     TRUE2, # 信息邻接矩阵之于银行间健康的isHealthy
    #     FALSE2, # 信息邻接矩阵之于银行间资不抵债的isInsolvent
    #     FALSE2, # 信息邻接矩阵之于银行间流动性短缺的isIlliquity
    #     FALSE2, # 信息邻接矩阵之于银行间破产的isBankrupt
    #     [], # 信息列表之于各银行之债权方银行编号listOfCreditors
    #     [], # 信息列表之于各银行之债务方银行编号listOfDebtors
    #     [], # 信息列表之于资不抵债的银行之债权方银行编号listOfCreditorsInInsolvent
    #     [], # 信息列表之于资不抵债的银行之债务方银行编号listOfDebtorsInInsolvent
    #     [], # 信息列表之于流动性短缺的银行之债权方银行编号listOfCreditorsInIlliquity
    #     [], # 信息列表之于流动性短缺的银行之债务方银行编号listOfDebtorsInIlliquity
    #     [], # 信息列表之于破产的银行之债权方银行编号listOfCreditorsInBankrupt
    #     [] # 信息列表之于破产的银行之债务方银行编号listOfDebtorsInBankrupt
    # )

    return bank, interbank
end


## 不同的方式
"""
初始化银行变量
# Arguments
`init_method::String`: 参数，初始化方式；
- `only init`: 仅单纯初始化；
- `randomly`: 生成随机数据以初始化；
- `import data`: 导入数据以初始化
- `manually`: 手动设置以初始化；
"""
function init_B_variables(; init_method::String)
    if init_method == "only init"
        BB, BI = init_B_variables_only()
        BB_tau = StructArray([BB for i = 1:p.max_num_tau]) # 初始化带传染轮次变量的商业银行实例数组
        BI_tau = StructArray([BI for i = 1:p.max_num_tau]) # 初始化带传染轮次变量的银行间市场实例数组
    elseif init_method == "randomly"
        BB, BI = init_B_variables_randomly()
        BB_tau = StructArray([BB for i = 1:p.max_num_tau]) # 初始化带传染轮次变量的商业银行实例数组
        BI_tau = StructArray([BI for i = 1:p.max_num_tau]) # 初始化带传染轮次变量的银行间市场实例数组
    elseif init_method == "import data"
        BB, BI = init_B_variables_only()
        BB_tau = StructArray([BB for i = 1:p.max_num_tau]) # 初始化带传染轮次变量的商业银行实例数组
        BI_tau = StructArray([BI for i = 1:p.max_num_tau]) # 初始化带传染轮次变量的银行间市场实例数组
        ## 导入数据以初始化银行变量
        BB, BI, BB_tau, BI_tau = init_B_variables_importData()
    elseif init_method == "set manually"
        BB, BI = initVariables_setManually() # 手动设置以初始化银行变量
        BB_tau = StructArray([BB for i = 1:p.max_num_tau]) # 初始化带传染轮次变量的商业银行实例数组
        BI_tau = StructArray([BI for i = 1:p.max_num_tau]) # 初始化带传染轮次变量的银行间市场实例数组
    else
        throw(DomainError(init_method, "关键词取值错误！"))
    end

    ## 更新各银行之变量，在第一回合初始时
    a = TypeState{1}(BB.isOn .|| BB.isOff) # 临时设置BB示性变量
    ia = TypeState{2}((BB.isOn .|| BB.isOff) .&& (BB.isOn .|| BB.isOff)') # 临时设置BI示性变量
    update_B_Shock!(BB, BI, a, ia; byWay = "all") # 更新各银行之所有冲击变量，在第一回合开始时
    update_B_balanceSheet!(BB, BI, a, ia; byWay = "all") # 更新各银行之资产负债表变量
    update_B_state!(BB, BI; to = "any", from = "any") # 更新各银行之状态示性变量

    ## 存储初始数据
    BB_tau_0 = deepcopy(BB)
    BI_tau_0 = deepcopy(BI)

    return BB, BI, BB_tau_0, BI_tau_0, BB_tau, BI_tau
end

