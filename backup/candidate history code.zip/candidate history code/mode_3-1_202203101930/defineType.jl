## 定义类型，模式3-1

##########################################
#使用：在用；
#状态：进行中；
##########################################

# module DefineType
# export Objects,Assets,Liabilities,Equity,Loans,Borrows,Loss,States,BankCommercial



# 定义个体抽象类型
# abstract type Object end
# abstract type Bank <: Object end
# abstract type BB <: Bank end # 定义商业银行BankCommercial个体抽象类型
# abstract type BS <: Bank end # 定义影子银行BankShadow个体抽象类型


## 定义类型
TypeIds{NDIMS1} = Array{Int16,NDIMS1} # 向量编号类型
TypeAbbrs{NDIMS1} = Array{String,NDIMS1} # 向量缩写类型
TypeNames{NDIMS1} = Array{String,NDIMS1} # 向量名称类型
TypeMoney{NDIMS2} = Array{Float32,NDIMS2} # 向量资金类型
TypeState{NDIMS2} = Array{Bool,NDIMS2} # 一维向量状态类型


# "定义个体复合类型。"
# mutable struct Objects{NDIMS2}
#     id::TypeIds{NDIMS2} # 编号
#     abbr::TypeAbbrs{NDIMS2} # 缩写
#     name::TypeNames{NDIMS2} # 全名
# end


"定义商业银行复合类型。"
mutable struct BankCommercial{NDIMS1,NDIMS2}
    id::TypeIds{NDIMS1} # 编号
    abbr::TypeAbbrs{NDIMS1} # 缩写
    name::TypeNames{NDIMS1} # 全名
    A_all::TypeMoney{NDIMS2} # 总资产：$A_all=A_BI+A_exBI$
    A_BI_all::TypeMoney{NDIMS2} # 银行间资产加总
    A_exBI::TypeMoney{NDIMS2} # 非银行间资产：$A_exBI=A_P+A_Q+A_R+A_other$
    A_P::TypeMoney{NDIMS2} # 银行贷款给生产部门之资产（非流动性资产）
    A_Q::TypeMoney{NDIMS2} # 银行持有超额准备金（流动性资产）
    A_R::TypeMoney{NDIMS2} # 银行持有法定准备金（非流动性资产）
    A_other::TypeMoney{NDIMS2} # 银行持有的其它资产（非流动性资产）
    Z_all::TypeMoney{NDIMS2} # 总负债：$Z_total=Z_BI+Z_exBI$
    Z_BI_all::TypeMoney{NDIMS2} # 银行间负债加总
    Z_exBI::TypeMoney{NDIMS2} # 非银行间负债：$Z_exBI=Z_D+Z_other$
    Z_D::TypeMoney{NDIMS2} # 银行获得居民部门存款（非流动性负债）
    Z_other::TypeMoney{NDIMS2} # 银行持有的其他负债（非流动性负债）Z_other
    E_all::TypeMoney{NDIMS2} # 所有者权益
    Lo_all::TypeMoney{NDIMS2} # 总贷款：$Lo_all=Lo_BI+Lo_exBI$
    Lo_BI::TypeMoney{NDIMS2} # 银行间贷款
    Lo_exBI::TypeMoney{NDIMS2} # 非银行间贷款：$Lo_exBI=Lo_P$
    Lo_P::TypeMoney{NDIMS2} # 银行贷款给生产部门
    Li_all::TypeMoney{NDIMS2} # 总借款：$Li_all=Li_BI+Li_exBI$
    Li_BI::TypeMoney{NDIMS2} # 银行间借款
    Li_exBI::TypeMoney{NDIMS2} # 非银行间借款：$Li_exBI=Li_D$
    Li_D::TypeMoney{NDIMS2} # 银行获得居民部门存款借款
    Shock_exBI_t::TypeMoney{NDIMS2} # 银行外市场冲击$Shock_exBI_t = Shock_L_exBI_t and Shock_D_t$
    Shock_L_exBI_s::TypeMoney{NDIMS2} # 银行之非银行间贷款挤兑流动冲击源头
    Shock_L_exBI_t::TypeMoney{NDIMS2} # 银行之非银行间贷款违约损失冲击目标
    Shock_D_s::TypeMoney{NDIMS2} # 银行存款违约损失冲击源头
    Shock_D_t::TypeMoney{NDIMS2} # 银行存款挤兑流动冲击目标
    Shock_B::TypeMoney{NDIMS2} # 银行内资产负债冲击$Shock_B=Shock_B_A+Shock_B_Z$
    Shock_B_A::TypeMoney{NDIMS2} # 银行内资产负债之银行间资产端冲击
    Shock_B_Z::TypeMoney{NDIMS2} # 银行内资产负债之银行间负债端冲击
    Shock_BI_s::TypeMoney{NDIMS2} # 银行间冲击源头$Shock_BI_s=Shock_BI_def_s+Shock_BI_run_s$
    Shock_BI_t::TypeMoney{NDIMS2} # 银行间冲击目标$Shock_BI_t=Shock_BI_def_t+Shock_BI_run_t$
    Shock_BI_def_s::TypeMoney{NDIMS2} # 银行间违约损失冲击源头
    Shock_BI_def_t::TypeMoney{NDIMS2} # 银行间违约损失冲击目标
    Shock_BI_run_s::TypeMoney{NDIMS2} # 银行间挤兑流动冲击源头$Shock_BI_run_s=Shock_BI_run_ilq_s+Shock_BI_run_br_s$
    Shock_BI_run_t::TypeMoney{NDIMS2} # 银行间挤兑流动冲击目标$Shock_BI_run_t+Shock_BI_run_ilq_t+Shock_BI_run_br_t$
    Shock_BI_run_ilq_s::TypeMoney{NDIMS2} # 银行间流动性短缺挤兑流动冲击源头
    Shock_BI_run_ilq_t::TypeMoney{NDIMS2} # 银行间流动性短缺挤兑流动冲击目标
    Shock_BI_run_br_s::TypeMoney{NDIMS2} # 银行间倒闭挤兑流动冲击源头
    Shock_BI_run_br_t::TypeMoney{NDIMS2} # 银行间倒闭挤兑流动冲击目标
    Loss_BI::TypeMoney{NDIMS2} # 银行间市场冲击损失
    Loss_BI_def_t::TypeMoney{NDIMS2} # 银行间资产负债违约冲击损失
    Loss_BI_run_t::TypeMoney{NDIMS2} # 银行间负债流动性挤兑冲击损失
    isOn::TypeState{NDIMS2} # 示性向量之于银行是否存在
    isOff::TypeState{NDIMS2} # 示性向量之于银行是否已退出不存在
    isHealthy::TypeState{NDIMS2} # 示性向量之于银行是否健康
    isInsolvent::TypeState{NDIMS2} # 示性向量之于银行是否资不抵债
    isIlliquity::TypeState{NDIMS2} # 示性向量之于银行是否流动性短缺
    isBankrupt::TypeState{NDIMS2} # 示性向量之于银行是否破产
    listOfExist::Array{Any} # 列表之于存在的银行编号
    listOfInsolvent::Array{Any} # 列表之于资不抵债的银行编号
    listOfIlliquity::Array{Any} # 列表之于流动性短缺的银行编号
    listOfBankrupt::Array{Any} # 列表之于破产的银行编号
end
# isDefault::TypeState{NDIMS2} # 示性向量之于银行是否违约
# TODO 增加监管约束之状态



"定义银行间邻接矩阵复合类型。"
mutable struct BankInterbank{NDIMS2}
    # id::TypeIds{NDIMS2} # 编号
    A_BI::TypeMoney{NDIMS2} # 银行间资产邻接矩阵
    Z_BI::TypeMoney{NDIMS2} # 银行间负债邻接矩阵
    Lo_BI::TypeMoney{NDIMS2} # 银行间贷款邻接矩阵
    Li_BI::TypeMoney{NDIMS2} # 银行间借款邻接矩阵
    Shock_BI::TypeMoney{NDIMS2} # 银行间冲击$Shock_BI=Shock_BI_def+Shock_BI_run$
    Shock_BI_def::TypeMoney{NDIMS2} # 银行间违约损失冲击
    Shock_BI_run::TypeMoney{NDIMS2} # 银行间挤兑流动冲击$Shock_BI_run=Shock_BI_run_ilq+Shock_BI_run_br$
    Shock_BI_run_ilq::TypeMoney{NDIMS2} # 流动性短缺银行银行间挤兑流动冲击
    Shock_BI_run_br::TypeMoney{NDIMS2} # 破产银行银行间挤兑流动冲击
    Loss_BI::TypeMoney{NDIMS2} # 银行间市场冲击损失
    Loss_BI_def::TypeMoney{NDIMS2} # 银行间资产负债违约冲击损失
    Loss_BI_run::TypeMoney{NDIMS2} # 银行间负债流动性挤兑冲击损失
    # isExposure::TypeState{NDIMS2} # 信息邻接矩阵之于是否有银行间敞口
    isOn::TypeState{NDIMS2} # 信息邻接矩阵之于银行间存在的
    isOff::TypeState{NDIMS2} # 信息邻接矩阵之于银行间已退出不存在的
    isHealthy::TypeState{NDIMS2} # 信息邻接矩阵之于银行间健康的
    isInsolvent::TypeState{NDIMS2} # 信息邻接矩阵之于银行间资不抵债的
    isIlliquity::TypeState{NDIMS2} # 信息邻接矩阵之于银行间流动性短缺的
    isBankrupt::TypeState{NDIMS2} # 信息邻接矩阵之于银行间破产的
    listOfCreditors::Array{Any} # 信息列表之于各银行之债权方银行编号
    listOfDebtors::Array{Any} # 信息列表之于各银行之债务方银行编号
    listOfCreditorsInInsolvent::Array{Any} # 信息列表之于资不抵债的银行之债权方银行编号
    listOfDebtorsInInsolvent::Array{Any} # 信息列表之于资不抵债的银行之债务方银行编号
    listOfCreditorsInIlliquity::Array{Any} # 信息列表之于流动性短缺的银行之债权方银行编号
    listOfDebtorsInIlliquity::Array{Any} # 信息列表之于流动性短缺的银行之债务方银行编号
    listOfCreditorsInBankrupt::Array{Any} # 信息列表之于破产的银行之债权方银行编号
    listOfDebtorsInBankrupt::Array{Any} # 信息列表之于破产的银行之债务方银行编号
end



"定义设置参数类型。"
mutable struct Parameters
    init_method::String # 初始化方法
    num_bank::Int64 # 银行个数
    num_assets::Int64 # 资产总类数
    max_num_tau::Int64 # 最大传染轮次数
    theta_Shock_exBI_t::Float64 # 外生冲击类型占比
    set_Shock_exB::Vector # 指定遭受初始外生冲击的银行示性列表
end




# # end;
