## 函数区：构建银行与银行间相关状态及其转换

##########################################
#使用：在用；
#状态：完善中；
##########################################

include("./defineType.jl")


function init_listOfRelationInStateOfBanks!(bank::BankCommercial,interbank::BankInterbank)
    interbank.listOfCreditors = calc_listOfRelationInStateOfBanks(interbank; isState = bank.isOn, goal = "creditor")
    interbank.listOfDebtors = calc_listOfRelationInStateOfBanks(interbank; isState = bank.isOn, goal = "debtor")
end


"计算示性向量之于银行健康的。"
function calc_isHealthy!(bank::BankCommercial, interbank::BankInterbank)
    condition = ((bank.E_all .>= LESS1 .&& bank.A_Q .>= LESS1) .&& (bank.Shock_B_A + LESS1 .<= bank.A_P .&& bank.Shock_B_Z + LESS1 .<= bank.A_Q) .&& bank.isOn)
    if bank.isHealthy != condition
        bank.isHealthy = condition
        interbank.isHealthy = (bank.isHealthy .&& bank.isHealthy')
    end
end

"计算示性向量之于银行健康的，来自资不抵债的。" # 内容同于calc_isHealthy!。
function calc_isHealthy_from_isInsolvent!(bank::BankCommercial, interbank::BankInterbank)
    condition = ((bank.E_all .>= LESS1 .&& bank.A_Q .>= LESS1) .&& (bank.Shock_B_A + LESS1 .<= bank.A_P .&& bank.Shock_B_Z + LESS1 .<= bank.A_Q) .&& bank.isOn)
    if bank.isHealthy != condition
        bank.isHealthy = condition
        interbank.isHealthy = (bank.isHealthy .&& bank.isHealthy')
    end
end

"更新示性向量之于银行健康的，来自资不抵债的。"
function update_isHealthy_from_isInsolvent!(bank::BankCommercial, interbank::BankInterbank)
    condition = (.!(bank.isInsolvent .|| bank.isIlliquity) .&& bank.isOn)
    if bank.isHealthy != condition
        bank.isHealthy = condition
        interbank.isHealthy = (bank.isHealthy .&& bank.isHealthy')
    end
end

"计算示性向量之于银行健康的，来自流动性短缺的。" # 内容同于calc_isHealthy!。
function calc_isHealthy_from_isIlliquity!(bank::BankCommercial, interbank::BankInterbank)
    condition = ((bank.E_all .>= LESS1 .&& bank.A_Q .>= LESS1) .&& (bank.Shock_B_Z + LESS1 .<= bank.A_Q .&& bank.Shock_B_Z + LESS1 .<= bank.A_Q) .&& bank.isOn)
    if bank.isHealthy != condition
        bank.isHealthy = condition
        interbank.isHealthy = (bank.isHealthy .&& bank.isHealthy')
    end
end

"更新示性向量之于银行健康的，来自流动性短缺的。" # 内容同于update_isHealthy_from_isInsolvent!
function update_isHealthy_from_isIlliquity!(bank::BankCommercial, interbank::BankInterbank)
    condition = (.!(bank.isInsolvent .|| bank.isIlliquity) .&& bank.isOn)
    if bank.isHealthy != condition
        bank.isHealthy = condition
        interbank.isHealthy = (bank.isHealthy .&& bank.isHealthy')
    end
end



"计算示性向量之于银行资不抵债的。"
function calc_isInsolvent!(bank::BankCommercial, interbank::BankInterbank)
    condition = ((bank.A_all .< bank.Z_all + LESS1 .|| bank.E_all .< LESS1#=  .|| bank.Shock_B_A + LESS1 .> bank.E_all =#) .&& bank.isOn)
    if bank.isInsolvent != condition
        bank.isInsolvent = condition
        interbank.isInsolvent = (bank.isInsolvent .|| bank.isInsolvent')
        interbank.listOfCreditorsInInsolvent = calc_listOfRelationInStateOfBanks(interbank; isState = bank.isInsolvent, goal = "creditor")
        interbank.listOfDebtorsInInsolvent = calc_listOfRelationInStateOfBanks(interbank; isState = bank.isInsolvent, goal = "debtor")
    end
end

"计算示性向量之于银行资不抵债的，来自健康的。" # 内容同于calc_isInsolvent!
function calc_isInsolvent_from_isHealthy!(bank::BankCommercial, interbank::BankInterbank)
    condition = ((bank.A_all .< bank.Z_all + LESS1 .|| bank.E_all .< LESS1#=  .|| bank.Shock_B_A + LESS1 .> bank.E_all =#) .&& bank.isOn)
    if bank.isInsolvent != condition
        bank.isInsolvent = condition
        interbank.isInsolvent = (bank.isInsolvent .|| bank.isInsolvent')
        interbank.listOfCreditorsInInsolvent = calc_listOfRelationInStateOfBanks(interbank; isState = bank.isInsolvent, goal = "creditor")
        interbank.listOfDebtorsInInsolvent = calc_listOfRelationInStateOfBanks(interbank; isState = bank.isInsolvent, goal = "debtor")
    end
end

"更新示性向量之于银行资不抵债的，来自健康的。" # 内容同于calc_isInsolvent!
function update_isInsolvent_from_isHealthy!(bank::BankCommercial, interbank::BankInterbank)
    condition = ((bank.A_all .< bank.Z_all + LESS1 .|| bank.E_all .< LESS1#=  .|| bank.Shock_B_A + LESS1 .> bank.E_all =#) .&& bank.isOn)
    if bank.isInsolvent != condition
        bank.isInsolvent = condition
        interbank.isInsolvent = (bank.isInsolvent .|| bank.isInsolvent')
        interbank.listOfCreditorsInInsolvent = calc_listOfRelationInStateOfBanks(interbank; isState = bank.isInsolvent, goal = "creditor")
        interbank.listOfDebtorsInInsolvent = calc_listOfRelationInStateOfBanks(interbank; isState = bank.isInsolvent, goal = "debtor")
    end
end

"计算示性向量之于银行流动性短缺的。"
function calc_isIlliquity!(bank::BankCommercial, interbank::BankInterbank)
    condition = ((bank.A_Q .< LESS1#=  .|| bank.Shock_B_Z + LESS1 .>= bank.A_Q =#) .&& bank.isOn)
    if bank.isIlliquity != condition
        bank.isIlliquity = condition
        interbank.isIlliquity = (bank.isIlliquity .|| bank.isIlliquity')
        interbank.listOfCreditorsInIlliquity = calc_listOfRelationInStateOfBanks(interbank; isState = bank.isIlliquity, goal = "creditor")
        interbank.listOfDebtorsInIlliquity = calc_listOfRelationInStateOfBanks(interbank; isState = bank.isIlliquity, goal = "debtor")
    end
end

"计算示性向量之于银行流动性短缺的，来自健康的。" # 内容同于calc_isIlliquity!
function calc_isIlliquity_from_isHealthy!(bank::BankCommercial, interbank::BankInterbank)
    condition = ((bank.A_Q .< LESS1#=  .|| bank.Shock_B_Z + LESS1 .>= bank.A_Q =#) .&& bank.isOn)
    if bank.isIlliquity != condition
        bank.isIlliquity = condition
        interbank.isIlliquity = (bank.isIlliquity .|| bank.isIlliquity')
        interbank.listOfCreditorsInIlliquity = calc_listOfRelationInStateOfBanks(interbank; isState = bank.isIlliquity, goal = "creditor")
        interbank.listOfDebtorsInIlliquity = calc_listOfRelationInStateOfBanks(interbank; isState = bank.isIlliquity, goal = "debtor")
    end
end

"更新示性向量之于银行流动性短缺的，来自健康的。" # 内容同于calc_isIlliquity!
function update_isIlliquity_from_isHealthy!(bank::BankCommercial, interbank::BankInterbank)
    condition = ((bank.A_Q .< LESS1#=  .|| bank.Shock_B_Z + LESS1 .>= bank.A_Q =#) .&& bank.isOn)
    if bank.isIlliquity != condition
        bank.isIlliquity = condition
        interbank.isIlliquity = (bank.isIlliquity .|| bank.isIlliquity')
        interbank.listOfCreditorsInIlliquity = calc_listOfRelationInStateOfBanks(interbank; isState = bank.isIlliquity, goal = "creditor")
        interbank.listOfDebtorsInIlliquity = calc_listOfRelationInStateOfBanks(interbank; isState = bank.isIlliquity, goal = "debtor")
    end
end

"计算示性向量之于银行破产的。"
function calc_isBankrupt!(bank::BankCommercial, interbank::BankInterbank)
    condition = (bank.isInsolvent .|| bank.isIlliquity)
    if bank.isBankrupt != condition
        bank.isBankrupt = condition
        interbank.isBankrupt = (bank.isBankrupt .&& bank.isBankrupt')
        interbank.listOfCreditorsInBankrupt = calc_listOfRelationInStateOfBanks(interbank; isState = bank.isBankrupt, goal = "creditor")
        interbank.listOfDebtorsInBankrupt = calc_listOfRelationInStateOfBanks(interbank; isState = bank.isBankrupt, goal = "debtor")
    end
end

"计算示性向量之于破产的，来自资不抵债的。" # 同于calc_isBankrupt!
function calc_isBankrupt_from_isInsolvent!(bank::BankCommercial, interbank::BankInterbank)
    condition = (bank.isInsolvent .|| bank.isIlliquity)
    if bank.isBankrupt != condition
        bank.isBankrupt = condition
        interbank.isBankrupt = (bank.isBankrupt .&& bank.isBankrupt')
        interbank.listOfCreditorsInBankrupt = calc_listOfRelationInStateOfBanks(interbank; isState = bank.isBankrupt, goal = "creditor")
        interbank.listOfDebtorsInBankrupt = calc_listOfRelationInStateOfBanks(interbank; isState = bank.isBankrupt, goal = "debtor")
    end
end

"计算示性向量之于破产的，来自流动性短缺的。" # 同于calc_isBankrupt!
function calc_isBankrupt_from_isIlliquity!(bank::BankCommercial, interbank::BankInterbank)
    condition = (bank.isInsolvent .|| bank.isIlliquity)
    if bank.isBankrupt != condition
        bank.isBankrupt = condition
        interbank.isBankrupt = (bank.isBankrupt .&& bank.isBankrupt')
        interbank.listOfCreditorsInBankrupt = calc_listOfRelationInStateOfBanks(interbank; isState = bank.isBankrupt, goal = "creditor")
        interbank.listOfDebtorsInBankrupt = calc_listOfRelationInStateOfBanks(interbank; isState = bank.isBankrupt, goal = "debtor")
    end
end

"计算示性向量之于银行存在的。"
function together_isOn!(bank::BankCommercial, interbank::BankInterbank)
    condition = (bank.isHealthy .|| bank.isInsolvent .|| bank.isIlliquity .|| bank.isBankrupt)
    if bank.isOn != condition
        bank.isOn = condition
        interbank.isOn = (bank.isOn .&& bank.isOn')
        # interbank.listOfCreditorsInOn = calc_listOfRelationInStateOfBanks(interbank; isState = bank.isOn, goal = "creditor") #HACK，未定义，无用。
        # interbank.listOfDebtorsInOn = calc_listOfRelationInStateOfBanks(interbank; isState = bank.isOn, goal = "debtor") #HACK，未定义，无用。
    end
end

"更新示性向量之于银行破产的，来自退出的。" #BUG，有一定不稳定的风险。
function update_isBankrupt_from_isOff!(bank::BankCommercial, interbank::BankInterbank)
    condition = (bank.isOff)
    if bank.isBankrupt == condition
        bank.isBankrupt[:] = FALSE1
        interbank.isBankrupt = (bank.isBankrupt .&& bank.isBankrupt')
        interbank.listOfCreditorsInBankrupt = calc_listOfRelationInStateOfBanks(interbank; isState = bank.isBankrupt, goal = "creditor")
        interbank.listOfDebtorsInBankrupt = calc_listOfRelationInStateOfBanks(interbank; isState = bank.isBankrupt, goal = "debtor")
    end
end

"更新示性向量之于银行存在的，来自退出的。"
function update_isOn_from_isOff!(bank::BankCommercial, interbank::BankInterbank)
    condition = (.!bank.isOff)
    if bank.isOn != condition
        bank.isOn = condition
        interbank.isOn = (bank.isOn .&& bank.isOn')
        interbank.listOfCreditorsInBankrupt = calc_listOfRelationInStateOfBanks(interbank; isState = bank.isBankrupt, goal = "creditor")
        interbank.listOfDebtorsInBankrupt = calc_listOfRelationInStateOfBanks(interbank; isState = bank.isBankrupt, goal = "debtor")
    end
end

"计算示性向量之于银行退出的。"
function calc_isOff!(bank::BankCommercial, interbank::BankInterbank)
    condition = bank.isBankrupt .|| bank.isOff
    if bank.isOff != condition
        bank.isOff = condition
        interbank.isOff = (bank.isOff .&& bank.isOff')
    end
end

"更新示性向量之于银行退出的，来自存在的。"
function update_isOff_from_isOn!(bank::BankCommercial, interbank::BankInterbank)
    condition = .!bank.isOn
    if bank.isOff != condition
        bank.isOff = condition
        interbank.isOff = (bank.isOff .&& bank.isOff')
    end
end

"计算示性向量之于银行退出的，来自破产的。"
function calc_isOff_from_isBankrupt!(bank::BankCommercial, interbank::BankInterbank)
    calc_isOff!(bank, interbank)
    interbank.listOfCreditorsInBankrupt = []
    interbank.listOfDebtorsInBankrupt = []
end

"""
计算信息列表之于各状态银行之各关联银行。
# Arguments
- `interbank::BankInterbank`: 银行间主体。
- `listOfRelationInStateOfBanks::Array`: 列表之于各银行之各状态之关系。
- `isState::Vector`: 示性向量之于各银行之状态。
- `goal::String`: 参数，确定计算债务方或债权方。
    - `debtor`: 计算对应的债务方银行；
    - `creditor`: 计算对应的债权方银行；
# Returns
- `listOfRelationInStateOfBanks`: 返回对应状态下的债权或者债务关系的银行列表；
"""
function calc_listOfRelationInStateOfBanks(interbank::BankInterbank; isState::Vector, goal::String)
    # 计算示性矩阵之于银行间风险敞口的
    if goal == "debtor"
        isExposure = ((interbank.A_BI .> 0.0) .&& isState)
    elseif goal == "creditor"
        isExposure = ((interbank.Z_BI .> 0.0) .&& isState)
    else
        throw(DomainError(byWay, "关键词取值错误！"))
    end
    listOfRelationInStateOfBanks = [[] for i in 1:p.num_bank]
    for i in 1:p.num_bank
        listOfRelationInStateOfBanks[i] = findall(isExposure[i, :]) # 获取对应状态下的债权或者债务关系的银行列表
    end
    return listOfRelationInStateOfBanks
end


"""
更新各银行之状态

# Arguments

`to::String`: 参数，转移状态目标；
- `any`: 到任意状态；
- `healthy`: 到健康状态；
- `insolvent`: 到资不抵债状态；
- `illiquity`: 到流动性短缺状态；
- `bankrupt`: 到破产状态；
- `off`: 到退出状态；

`from::String`: 参数，转移状态源头；
- `any`: 从任意状态出发；
- `healthy`: 从健康状态出发；
- `insolvent`: 从资不抵债状态出发；
- `illiquity`: 从流动性短缺状态出发；
- `bankrupt`: 从破产状态出发；
- `off`: 从退出状态出发；
"""
function update_B_state!(bank::BankCommercial, interbank::BankInterbank; to::String = "any", from::String = "any")
    if to == "any" #FIXME 这个可能有缺陷
        if from == "any"
            init_listOfRelationInStateOfBanks!(bank,interbank)
            calc_isInsolvent!(bank, interbank)
            calc_isIlliquity!(bank, interbank)
            calc_isHealthy!(bank, interbank)
            calc_isBankrupt!(bank, interbank)
            together_isOn!(bank, interbank)
            # calc_isOff!(bank, interbank)
            # calc_isOn!(bank, interbank)
        elseif from == "healthy"
            calc_isInsolvent_from_isHealthy!(bank, interbank)
            update_isHealthy_from_isInsolvent!(bank, interbank)
            calc_isIlliquity_from_isHealthy!(bank, interbank)
            update_isHealthy_from_isIlliquity!(bank, interbank)
        elseif from == "insolvent"
            calc_isHealthy_from_isInsolvent!(bank, interbank)
            update_isInsolvent_from_isHealthy!(bank, interbank)
            calc_isBankrupt_from_isInsolvent!(bank, interbank)
        elseif from == "illiquity"
            calc_isHealthy_from_isIlliquity!(bank, interbank)
            update_isIlliquity_from_isHealthy!(bank, interbank)
            calc_isBankrupt_from_isIlliquity!(bank, interbank)
        elseif from == "bankrupt"
            calc_isOff_from_isBankrupt!(bank, interbank)
            update_isOn_from_isOff!(bank, interbank)
            interbank.listOfCreditors = calc_listOfRelationInStateOfBanks(interbank; isState = bank.isOn, goal = "creditor")
            interbank.listOfDebtors = calc_listOfRelationInStateOfBanks(interbank; isState = bank.isOn, goal = "debtor")
        elseif from == "off"
            println("无须更新！")
        else
            throw(DomainError(byWay, "关键词from取值错误！"))
        end
    elseif to == "healthy"
        if from == "any"
            calc_isHealthy!(bank, interbank)
            update_isInsolvent_from_isHealthy!(bank, interbank)
            update_isIlliquity_from_isHealthy!(bank, interbank)
        elseif from == "healthy"
            println("无须更新！")
        elseif from == "insolvent"
            calc_isHealthy_from_isInsolvent!(bank, interbank)
            calc_isInsolvent_from_isHealthy!(bank, interbank)
        elseif from == "illiquity"
            calc_isHealthy_from_isIlliquity!(bank, interbank)
            update_isIlliquity_from_isHealthy!(bank, interbank)
        elseif from == "bankrupt"
            println("无须更新！")
        elseif from == "off"
            println("无须更新！")
        else
            throw(DomainError(byWay, "关键词from取值错误！"))
        end
    elseif to == "insolvent"
        if from == "any"
            calc_isInsolvent!(bank, interbank)
            update_isHealthy_from_isInsolvent!(bank, interbank)
        elseif from == "healthy"
            calc_isInsolvent_from_isHealthy!(bank, interbank)
            update_isHealthy_from_isInsolvent!(bank, interbank)
        elseif from == "insolvent"
            println("无须更新！")
        elseif from == "illiquity"
            # calc_isIlliquity_from_isHealthy!(bank, interbank) # 错误，可以删除！
            # calc_isHealthy_from_isIlliquity!(bank, interbank) # 错误，可以删除！
            # calc_isHealthy_from_isInsolvent!(bank, interbank) # 错误，可以删除！
            # calc_isInsolvent_from_isHealthy!(bank, interbank) # 错误，可以删除！
            println("无须更新！")
        elseif from == "bankrupt"
            println("无须更新！")
        elseif from == "off"
            println("无须更新！")
        else
            throw(DomainError(byWay, "关键词from取值错误！"))
        end
    elseif to == "illiquity"
        if from == "any"
            calc_isIlliquity!(bank, interbank)
            update_isHealthy_from_isIlliquity!(bank, interbank)
        elseif from == "healthy"
            calc_isIlliquity_from_isHealthy!(bank, interbank)
            update_isHealthy_from_isIlliquity!(bank, interbank)
        elseif from == "insolvent"
            # calc_isHealthy_from_isInsolvent!(bank, interbank) # 错误，可以删除！
            # update_isInsolvent_from_isHealthy!(bank, interbank) # 错误，可以删除！
            # update_isIlliquity_from_isHealthy!(bank, interbank) # 错误，可以删除！
            println("无须更新！")
        elseif from == "illiquity"
            println("无须更新！")
        elseif from == "bankrupt"
            println("无须更新！")
        elseif from == "off"
            println("无须更新！")
        else
            throw(DomainError(byWay, "关键词from取值错误！"))
        end
    elseif to == "bankrupt"
        if from == "any"
            calc_isBankrupt!(bank, interbank)
        elseif from == "healthy"
            calc_isInsolvent_from_isHealthy!(bank, interbank)
            update_isHealthy_from_isInsolvent!(bank, interbank)
            calc_isIlliquity!(bank, interbank)
            update_isHealthy_from_isIlliquity!(bank, interbank)
            calc_isBankrupt_from_isInsolvent!(bank, interbank)
            calc_isBankrupt_from_isIlliquity!(bank, interbank)
        elseif from == "insolvent"
            calc_isBankrupt_from_isInsolvent!(bank, interbank)
        elseif from == "illiquity"
            calc_isBankrupt_from_isIlliquity!(bank, interbank)
        elseif from == "bankrupt"
            println("无须更新！")
        elseif from == "off"
            println("无须更新！")
        else
            throw(DomainError(byWay, "关键词from取值错误！"))
        end
    elseif to == "off"
        if from == "any"
            calc_isOff!(bank, interbank)
            update_isOn_from_isOff!(bank, interbank)
        elseif from == "healthy"
            println("无须更新！")
        elseif from == "insolvent"
            println("无须更新！")
        elseif from == "illiquity"
            println("无须更新！")
        elseif from == "bankrupt"
            calc_isOff_from_isBankrupt!(bank, interbank)
            update_isOn_from_isOff!(bank, interbank)
            update_isBankrupt_from_isOff!(bank, interbank)
            interbank.listOfCreditors = calc_listOfRelationInStateOfBanks(interbank; isState = bank.isOn, goal = "creditor")
            interbank.listOfDebtors = calc_listOfRelationInStateOfBanks(interbank; isState = bank.isOn, goal = "debtor")
        elseif from == "off"
            println("无须更新！")
        else
            throw(DomainError(byWay, "关键词from取值错误！"))
        end
    elseif to == "on"
        if from == "any"
            together_isOn!(bank, interbank)
            update_isOff_from_isOn!(bank, interbank)
        else
            throw(DomainError(byWay, "关键词from取值错误！"))
        end
    else
        throw(DomainError(to, "关键词to取值错误！"))
    end
end


# """
# #使用 可能废弃！更新各银行与银行间之状态示性变量。
# # Arguments
# `byWay::String`: 参数，通过该参数指定的变量作为已知状态，更新其他相关的各银行与银行间之状态。
# - `all`: 更新所有状态；
# - `healthy`: 已知各银行处于健康状态；
# - `insolvent`: 已知各银行处于资不抵债状态；
# - `illiquity`: 已知各银行处于流动性短缺状态；
# - `bankrupt`: 已知各银行处于破产状态；
# - `off`: 已知各银行处于退出状态；
# - `on`: 已知各银行处于存在状态；
# """
# function update_B_state!(bank::BankCommercial, interbank::BankInterbank; byWay::String = "all")
#     if byWay == "all"
#         calc_isHealthy!(bank, interbank)
#         calc_isInsolvent!(bank, interbank)
#         interbank.listOfCreditorsInInsolvent = calc_listOfRelationInStateOfBanks(interbank; isState = bank.isInsolvent, goal = "creditor")
#         calc_isIlliquity!(bank, interbank)
#         interbank.listOfDebtorsInIlliquity = calc_listOfRelationInStateOfBanks(interbank; isState = bank.isIlliquity, goal = "debtor")
#         calc_isBankrupt!(bank, interbank)
#         calc_isOff!(bank, interbank)
#         together_isOn!(bank, interbank)
#         interbank.listOfCreditorsInBankrupt = calc_listOfRelationInStateOfBanks(interbank; isState = bank.isBankrupt, goal = "creditor")
#         interbank.listOfDebtorsInBankrupt = calc_listOfRelationInStateOfBanks(interbank; isState = bank.isBankrupt, goal = "debtor")
#     elseif byWay == "healthy"
#         calc_isHealthy!(bank, interbank)
#         calc_isInsolvent!(bank, interbank)
#         interbank.listOfCreditorsInInsolvent = calc_listOfRelationInStateOfBanks(interbank; isState = bank.isInsolvent, goal = "creditor")
#         calc_isIlliquity!(bank, interbank)
#         interbank.listOfCreditorsInIlliquity = calc_listOfRelationInStateOfBanks(interbank; isState = bank.isIlliquity, goal = "creditor")
#     elseif byWay == "insolvent"
#         calc_isInsolvent!(bank, interbank)
#         interbank.listOfCreditorsInInsolvent = calc_listOfRelationInStateOfBanks(interbank; isState = bank.isInsolvent, goal = "creditor")
#         calc_isHealthy!(bank, interbank)
#         # calc_isBankrupt!(bank, interbank)
#         # interbank.listOfCreditorsInBankrupt = calc_listOfRelationInStateOfBanks(interbank; isState = bank.isBankrupt, goal = "creditor")
#         # interbank.listOfDebtorsInBankrupt = calc_listOfRelationInStateOfBanks(interbank; isState = bank.isBankrupt, goal = "debtor")
#     elseif byWay == "illiquity"
#         calc_isIlliquity!(bank, interbank)
#         interbank.listOfCreditorsInIlliquity = calc_listOfRelationInStateOfBanks(interbank; isState = bank.isIlliquity, goal = "creditor")
#         calc_isHealthy!(bank, interbank)
#         # calc_isBankrupt!(bank, interbank)
#         # interbank.listOfCreditorsInBankrupt = calc_listOfRelationInStateOfBanks(interbank; isState = bank.isBankrupt, goal = "creditor")
#         # interbank.listOfDebtorsInBankrupt = calc_listOfRelationInStateOfBanks(interbank; isState = bank.isBankrupt, goal = "debtor")
#     elseif byWay == "bankrupt"
#         calc_isBankrupt!(bank, interbank)
#         interbank.listOfCreditorsInBankrupt = calc_listOfRelationInStateOfBanks(interbank; isState = bank.isBankrupt, goal = "creditor")
#         interbank.listOfDebtorsInBankrupt = calc_listOfRelationInStateOfBanks(interbank; isState = bank.isBankrupt, goal = "debtor")
#         transferTo_isBankrupt!()
#         # calc_isOff!(bank, interbank)
#         # calc_isOn!(bank, interbank)
#     elseif byWay == "off"
#         calc_isOff!(bank, interbank)
#         together_isOn!(bank, interbank)
#         interbank.listOfCreditors = calc_listOfRelationInStateOfBanks(interbank; isState = bank.isOn, goal = "creditor")
#         interbank.listOfDebtors = calc_listOfRelationInStateOfBanks(interbank; isState = bank.isOn, goal = "debtor")
#     elseif byWay == "on"
#         together_isOn!(bank, interbank)
#         interbank.listOfCreditors = calc_listOfRelationInStateOfBanks(interbank; isState = bank.isOn, goal = "creditor")
#         interbank.listOfDebtors = calc_listOfRelationInStateOfBanks(interbank; isState = bank.isOn, goal = "debtor")
#     else
#         throw(DomainError(byWay, "关键词取值错误！"))
#     end
# end


# #使用 废弃

# "计算列表之于各银行之债权方银行。"
# function calc_listOfCreditors!(bank::BankCommercial, interbank::BankInterbank)
#     empty!(interbank.listOfCreditors)
#         for i in findall(bank.isOn)
#         interbank.listOfCreditors[i] = findall(interbank.isExposure[:, i])
#     end
# end

# "计算列表之于各银行之债务方银行。"
# function calc_listOfDebtors!(bank::BankCommercial, interbank::BankInterbank)
#     empty!(interbank.listOfDebtors)
#         for i in findall(bank.isOn)
#         interbank.listOfDebtors[i] = findall(interbank.isExposure[i, :])
#     end
# end

# "计算列表之于资不抵债银行之债权方银行。"
# function calc_listOfCreditorsInInsolvent!(bank::BankCommercial, interbank::BankInterbank)
#     empty!(interbank.listOfCreditors)
#     for i in findall(bank.isInsolvent)
#         interbank.listOfCreditorsInInsolvent[i] = findall(interbank.isExposure[:, i])
#     end
# end


# "计算列表之于资不抵债银行之债务方银行。"
# function calc_listOfDebtorsInInsolvent!(bank::BankCommercial, interbank::BankInterbank)
#     empty!(interbank.listOfDebtors)
#     for i in findall(bank.isInsolvent)
#         interbank.listOfDebtorsInInsolvent[i] = findall(interbank.isExposure[i, :])
#     end
# end

# "计算列表之于流动性短缺银行之债权方银行。"
# function calc_listOfCreditorsInIlliquity!(bank::BankCommercial, interbank::BankInterbank)
#     empty!(interbank.listOfCreditors)
#     for i in findall(bank.isIlliquity)
#         interbank.listOfCreditorsInIlliquity[i] = findall(interbank.isExposure[:, i])
#     end
# end


# "计算列表之于流动性短缺银行之债务方银行。"
# function calc_listOfDebtorsInIlliquity!(bank::BankCommercial, interbank::BankInterbank)
#     empty!(interbank.listOfDebtors)
#     for i in findall(bank.isIlliquity)
#         interbank.listOfDebtorsInIlliquity[i] = findall(interbank.isExposure[i, :])
#     end
# end

# "计算列表之于破产银行之债权方银行。"
# function calc_listOfCreditorsInBankrupt!(bank::BankCommercial, interbank::BankInterbank)
#     empty!(interbank.listOfCreditors)
#     for i in findall(bank.isBankrupt)
#         interbank.listOfCreditorsInBankrupt[i] = findall(interbank.isExposure[:, i])
#     end
# end


# "计算列表之于破产银行之债务方银行。"
# function calc_listOfDebtorsInBankrupt!(bank::BankCommercial, interbank::BankInterbank)
#     empty!(interbank.listOfDebtors)
#     for i in findall(bank.isBankrupt)
#         interbank.listOfDebtorsInBankrupt[i] = findall(interbank.isExposure[i, :])
#     end
# end


# "更新信息列表之于各状态银行之各关联银行"
# function update_listOfRelationInStateOfBanks!(bank::BankCommercial, interbank::BankInterbank)
#     interbank.listOfCreditors = calc_listOfRelationInStateOfBanks(interbank; isState = bank.isOn, goal = "creditor")
#     interbank.listOfDebtors = calc_listOfRelationInStateOfBanks(interbank; isState = bank.isOn, goal = "debtor")
#     interbank.listOfCreditorsInInsolvent = calc_listOfRelationInStateOfBanks(interbank; isState = bank.isInsolvent, goal = "creditor")
#     interbank.listOfDebtorsInInsolvent = calc_listOfRelationInStateOfBanks(interbank; isState = bank.isInsolvent, goal = "debtor")
#     interbank.listOfCreditorsInIlliquity = calc_listOfRelationInStateOfBanks(interbank; isState = bank.isIlliquity, goal = "creditor")
#     interbank.listOfDebtorsInIlliquity = calc_listOfRelationInStateOfBanks(interbank; isState = bank.isIlliquity, goal = "debtor")
#     interbank.listOfCreditorsInBankrupt = calc_listOfRelationInStateOfBanks(interbank; isState = bank.isBankrupt, goal = "creditor")
#     interbank.listOfDebtorsInBankrupt = calc_listOfRelationInStateOfBanks(interbank; isState = bank.isBankrupt, goal = "debtor")
# end