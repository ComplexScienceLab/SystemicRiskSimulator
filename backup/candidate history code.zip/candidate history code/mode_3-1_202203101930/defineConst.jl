
## 定义银行数组常量

##########################################
#使用：在用；
#状态：基本完成；
##########################################

include("./setParameters.jl")

const FALSE1 = falses(p.num_bank) # 一维false布尔向量常量
const FALSE2 = falses(p.num_bank, p.num_bank) # 二维方阵false布尔向量常量
const TRUE1 = trues(p.num_bank) # 一维true布尔向量常量
const TRUE2 = trues(p.num_bank, p.num_bank) # 二维方阵true布尔向量常量
const BLANK1 = fill("", p.num_bank) # 一维空字符串向量常量
const BLANK2 = fill("", p.num_bank, p.num_bank) # 一维方阵空字符串向量常量
const ZEROS1 = zeros(p.num_bank) # 一维零向量常量
const ZEROS2 = zeros(p.num_bank, p.num_bank) # 二维方阵零向量常量
const LESS1 = zeros(p.num_bank) .+ 0.01 # 一维接近零的正数向量常量
const LESS2 = zeros(p.num_bank, p.num_bank) .+ 0.1 # 二维方阵接近零的正数常量
const ONES1 = ones(p.num_bank) # 一维幺向量常量
const ONES2 = ones(p.num_bank, p.num_bank) # 二维方阵幺向量常量
const MISSING1 = fill(missing, p.num_bank) # 一维缺失值向量常量
const MISSING2 = fill(missing, p.num_bank, p.num_bank) # 二维方阵确失值常量
const RANGE1 = range(1, p.num_bank, step = 1) # 一维步进向量常量