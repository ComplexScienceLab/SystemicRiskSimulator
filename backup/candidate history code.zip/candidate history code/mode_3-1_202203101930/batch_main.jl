

# 批处理主程序

## 主程序

include("./fun_initVariables.jl")
include("./fun_model.jl")

## test变量
test_tau = 1

## 主循环
## 初始化银行变量
BB, BI, BB_tau_0, BI_tau_0, BB_tau, BI_tau = init_B_variables(; init_method = p.init_method)



include("model_BI1111.jl")
# include("model_BI1111-20220305.jl")
model_BI1111(BB, BI)
















