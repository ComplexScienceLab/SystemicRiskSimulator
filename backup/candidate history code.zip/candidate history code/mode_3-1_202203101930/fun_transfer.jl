"计算商业银行之资金转移。"

## 函数区：集成各功能模块函数

##########################################
#使用/在用；
#状态/进行中；
##########################################

include("./defineType.jl")
# include("./setParameters.jl")
# include("./fun_initVariables.jl")


## 函数区

### 转移资金
"""
转移资金。
# Arguments
`target`：转移目的地；
`source`：转移源；
"""
function transfer_B_capital(target::TypeMoney{1}, source::TypeMoney{1}, flow::TypeMoney{1})
    target .+= flow[:]
    source .-= flow[:]
    return target, source
end
