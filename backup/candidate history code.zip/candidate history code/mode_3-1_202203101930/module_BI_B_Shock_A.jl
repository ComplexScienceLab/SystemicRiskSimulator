
## 函数区：模块集之银行内资产冲击1

##########################################
#使用：备用；
#状态：未完；
##########################################

## # TODO 模块之银行内资产冲击1。早已过期，需要重新被新版覆盖。

function ()
    BB.E_all[on] = max.(BB.E_all[on] - BB.Shock_B_A[on], 0) # 银行之所有者权益变动
    update_B_balanceSheet!(BB, BI, byWay = "E_all and Z_all")
    # i = findall(BB.Shock_B_A[on] .> BB_t0.A_P[on])
    # BB.Z_BI_all[i] = BB.Z_BI_all[i] .* (1 - (BB.Shock_B_A[i] - BB_t0.E_all[i]) ./ BB_t0.Z_all[i]) # 银行间负债变动，由于违约
    # BB.Z_D[i] = BB.Z_D[i] .* (1 - (BB.Shock_B_A[i] - BB_t0.E_all[i]) ./ BB_t0.Z_all[i]) # 存款负债变动，由于违约
    BB.Z_BI_all[BB.isInsolvent] = BB.Z_BI_all[BB.isInsolvent] .* (1 - (BB.Shock_B_A[BB.isInsolvent] - BB_t0.E_all[BB.isInsolvent]) ./ BB_t0.Z_all[BB.isInsolvent]) # 银行间负债变动，由于违约
    BB.Z_D[BB.isInsolvent] = BB.Z_D[BB.isInsolvent] .* (1 - (BB.Shock_B_A[BB.isInsolvent] - BB_t0.E_all[BB.isInsolvent]) ./ BB_t0.Z_all[BB.isInsolvent]) # 存款负债变动，由于违约
    update_B_balanceSheet!(BB, BI; byWay = "Z_D") # 更新资产负债表，通过Z_D或Z_BI_all
    BB.Shock_BI_def_s[on] = abs.(BB.Z_BI_all[on] - BB_t0.Z_BI[on]) # 银行内冲击传导至银行间传染冲击
    update_B_Shock!(BB, BI; byWay = "Shock_BI_def_s")
end
