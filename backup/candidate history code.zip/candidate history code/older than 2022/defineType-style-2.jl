## 定义类型，风格2-1

##########################################
# 使用：不用；
# 状态：放弃；
##########################################

module module DefineType_style_2

## 定义类型

## 定义个体抽象类型
abstract type Object end
abstract type Bank <: Object end
abstract type BB <: Bank end # 定义商业银行BankCommercial个体抽象类型
abstract type BS <: Bank end # 定义影子银行BankShadow个体抽象类型

## 定义个体常用属性
primitive type Id <: Unsigned 16 end # 编号值
primitive type Abbr <: AbstractString 16 end # 缩写
primitive type Name <: AbstractString 16 end # 名称
# abstract type Num{T} end # 个体数量

## 定义资金类型
abstract type Money{T} <: AbstractFloat end
primitive type Assets{T} <: Money{T} 64 end
struct Liabilities{T} <: Money{T} end
struct Equity{T} <: Money{T} end
struct Loans{T} <: Money{T} end
struct Borrows{T} <: Money{T} end



# ## 定义个体复合类型
# struct Objectstrcut{T}
#     id::TypeId
#     abbr::TypeAbbr
#     name::TypeName
#     assets::TypeAssets{Object} # 资产
#     liabilites::TypeLiabilities{Object} # 负债
#     equity::TypeEquity{Object} # 所有者权益
#     loans::TypeLoans{Object} # 贷款量
#     borrows::TypeBorrows{Object} # 借款量
# end

# ## 定义银行复合类型
# struct Bank{T <: Object}
#     id::TypeId
#     abbr::TypeAbbr
#     name::TypeName
#     assets::TypeAssets{Bank} # 资产
#     liabilites::TypeLiabilities{Bank} # 负债
#     equity::TypeEquity{Bank} # 所有者权益
#     loans::TypeLoans{Bank} # 贷款量
#     borrows::TypeBorrows{Bank} # 借款量
# end

# ## 定义商业银行复合类型，继承自银行
# mutable struct BankCommercial{T <: Bank}
#     id::TypeId
#     abbr::TypeAbbr
#     name::TypeName
#     assets::TypeAssets{BB} # 资产
#     liabilites::TypeLiabilities{BB} # 负债
#     equity::TypeEquity{BB} # 所有者权益
#     loans::TypeLoans{BB} # 贷款量
#     borrows::TypeBorrows{BB} # 借款量
# end

# ## 定义影子银行复合类型，继承自银行
# mutable struct BankShadow{T <: Bank}
#     id::TypeId
#     abbr::TypeAbbr
#     name::TypeName
#     assets::TypeAssets{BS} # 资产
#     liabilites::TypeLiabilities{BS} # 负债
#     equity::TypeEquity{BS} # 所有者权益
#     loans::TypeLoans{BS} # 贷款量
#     borrows::TypeBorrows{BS} # 借款量
# end








end;