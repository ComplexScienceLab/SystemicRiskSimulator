
## 模块之银行间市场BI100

##########################################
# 使用：在用；
# 状态：进行中；
##########################################

# module ModuleBI100

include("initVariables.jl")

# using .InitVariables


# testing
# print(obj_BI)

## 生成初始外生冲击
tau = 1 # 初始化传染轮次
while tau <= max_num_tau
    println("开始传染回合$tau")
    ## 初始阶段$t_{0}$：
    println("初始阶段")

    ## 临时留存BI之变量，在阶段0
    obj_BB_t0=deepcopy(obj_BB)

    if tau > 1 # 后续轮次$\tau_{i}>1$之阶段$t_{0}$
        obj_BB.loss.BI = obj_BB.loss.def + obj_BB.loss.run
    else # 初始轮次$\tau_{0}$之阶段$t_{0}$
        obj_BB.loss.BI = obj_BB.loss.exBI
    end
    
    ## 冲击和被传染阶段$t_{1}$：
    if tau > 1 # 后续轮次$\tau_{i}>1$之阶段$t_{1}$
        obj_BB.loss.a = max(loss_init_BI, obj_BB.a.BI)
        obj_BB.e.total = max(obj_BB.e.total - loss_init_BI, ZEROS1)
        obj_BB.a.total = obj_BB.a.total - obj_BB.loss.a
        obj_BB.z.total = max(min(obj_BB.z.total, obj_BB.a.total), ZEROS1)
    else # 初始轮次$\tau_{0}$之阶段$t_{1}$
        obj_BB.loss.a = max(loss_init_BI, obj_BB.loss.exBI)
        obj_BB.e.total = max(loss_init_BI - obj_BB.a.total, ZEROS1)
        obj_BB.a.total = obj_BB.a.total - obj_BB.loss.a
        obj_BB.z.total = max(min(obj_BB.z.total, obj_BB.a.total - obj_BB.loss.a), ZEROS1)
    end

    ## 判定本轮是否有银行资不抵债，如果无则结束本轮，如果有则这些银行标记为资不抵债，继续处理。
    isInsolvent = (obj_BB.loss.a .> obj_BB.e.total)
    if isInsolvent == obj_BB.s.isInsolvent
        tau = 0 # 归零传染轮次
        break
    end
    obj_BB.s.isInsolvent = isInsolvent
    ## 计算损失比例
    obj_BB.i.z=obj_BB.i.z

    ## 资不抵债和传染阶段$t_{2}$：
    

    ## 尾声阶段$t_{3}$：
    
    ## 生成资不抵债银行之债权方银行集合、资不抵债银行之债务方银行集合
    isCreditorsOfInsolventBank=
    
    ## 存储该轮次传染结果数据
    
    ## 判断下一轮次传染是否进行
    
    global tau += 1 # 传染轮次累加一
end










# end; # module


