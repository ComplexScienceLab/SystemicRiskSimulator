## 函数区：处理资不抵债状态

##########################################
# 使用：在用；
# 状态：进行中；
##########################################

## 更新资不抵债的银行示性向量
function update_isInsolvent!(isInsolvent::BankCommercial, E_all::BankCommercial)
    isInsolvent = E_all .< 0
    return isInsolvent
end

## 计算集合之于资不抵债的银行
calc_setOfInsolvent(isInsolvent::BankCommercial) = Set(findall(isInsolvent .== 1))

## 计算集合之于资不抵债银行之债权方银行
function calc_setOfCreditorsInInsolvent(isInsolvent::BankCommercial, isExposure::BankCommercial)
    setOfCreditorsInInsolvent = []
    for i = 1:length(isInsolvent)
        append!(setOfCreditorsInInsolvent, [isExposure[i, :]])
    end
    return setOfCreditorsInInsolvent
end

## 计算集合之于资不抵债银行之债务方银行
function calc_setOfDebtorsInInsolvent(isInsolvent::BankCommercial, haveExposure::BankCommercial)
    setOfDebtorsInInsolvent = []
    for i = 1:length(isInsolvent)
        append!(setOfDebtorsInInsolvent, [haveExposure[:, i]])
    end
    return setOfDebtorsInInsolvent
end

## 更新集合之于资不抵债银行之债权方银行
function update_setOfCreditorsInInsolvent!(setOfCreditorsInInsolvent, isInsolvent::BankCommercial, haveExposure::BankCommercial)
    for i = 1:length(isInsolvent)
        append!(setOfCreditorsInInsolvent, [haveExposure[i, :]])
    end
    return setOfCreditorsInInsolvent
end

## 更新集合之于资不抵债银行之债务方银行
function update_setOfDebtorsInInsolvent!(setOfDebtorsInInsolvent, isInsolvent::BankCommercial, haveExposure::BankCommercial)
    for i = 1:length(isInsolvent)
        append!(setOfDebtorsInInsolvent, [haveExposure[:, i]])
    end
    return setOfDebtorsInInsolvent
end


