## 定义类型，风格3-1

##########################################
# 使用：在用；
# 状态：进行中；
##########################################

# module DefineType
# export Objects,Assets,Liabilities,Equity,Loans,Borrows,Loss,States,BankCommercial



## 定义个体抽象类型
# abstract type Object end
# abstract type Bank <: Object end
# abstract type BB <: Bank end # 定义商业银行BankCommercial个体抽象类型
# abstract type BS <: Bank end # 定义影子银行BankShadow个体抽象类型


## 定义个体常用属性
TypeIds{N} = Array{Int16,N} # 向量编号类型
TypeAbbrs{N} = Array{String,N} # 向量缩写类型
TypeNames{N} = Array{String,N} # 向量名称类型

## 定义资金类型
TypeMoneyVector = Vector{Float64} # 一维向量资金类型
TypeMoneyMatrix = Matrix{Float64} # 二维向量资金类型

## 定义状态类型
TypeStateVector = Vector{Bool} # 一维向量状态类型
TypeStateMatrix = Matrix{Bool} # 二维向量状态类型
# TypeIsInsolvent = TypeState # 是否资不抵债

## 定义个体复合类型
mutable struct Objects{N}
    id::TypeIds{N}
    abbr::TypeAbbrs{N}
    name::TypeNames{N}
end

## 定义资产复合类型
mutable struct Assets
    total::TypeMoneyVector # 总资产：$total=BI+exBI$
    BI::TypeMoneyVector # 银行间资产
    exBI::TypeMoneyVector # 非银行间资产：$exBI=p+r$
    p::TypeMoneyVector # 银行贷款给生产部门之资产（非流动性资产）
    r::TypeMoneyVector # 银行持有准备金（流动性资产）
end

## 定义负债复合类型
mutable struct Liabilities
    total::TypeMoneyVector # 总负债：$total=BI+exBI$
    BI::TypeMoneyVector # 银行间负债
    exBI::TypeMoneyVector # 非银行间负债：$exBI=
    dd::TypeMoneyVector # 银行获得居民部门存款（非流动性负债）
end

## 定义所有者权益复合类型
mutable struct Equity
    total::TypeMoneyVector # 所有者权益
end

## 定义贷款复合类型
mutable struct Loans
    total::TypeMoneyVector # 总贷款
    BI::TypeMoneyVector # 银行间贷款
    exBI::TypeMoneyVector # 非银行间贷款
end

## 定义借款复合类型
mutable struct Borrows
    total::TypeMoneyVector # 总借款
    BI::TypeMoneyVector # 银行间借款
    exBI::TypeMoneyVector # 非银行间借款
end

## 定义损失复合类型
mutable struct Loss
    exBI::TypeMoneyVector # 非银行间市场冲击损失
    BI::TypeMoneyVector # 银行间市场冲击损失
    def::TypeMoneyVector # 银行间资产负债违约冲击损失
    run::TypeMoneyVector # 银行间负债流动性挤˛兑冲击损失
    a::TypeMoneyVector # 银行资产损失
end

## 定义状态复合类型
mutable struct States
    isInsolvent::TypeStateVector # 是否资不抵债
    # isInsolvent::TypeStateVector # 是否资不抵债
    # isDefault::TypeStateVector # 是否违约
    # 增加监管约束之状态
end

## 定义银行间邻接矩阵
mutable struct BankInterbank
    o::Objects
    a::TypeMoneyMatrix # 银行间资产邻接矩阵
    z::TypeMoneyMatrix # 银行间负债邻接矩阵
    lo::TypeMoneyMatrix # 银行间贷款邻接矩阵
    li::TypeMoneyMatrix # 银行间借款邻接矩阵

end

## 定义商业银行复合类型
mutable struct BankCommercial
    o::Objects # objects::Objects
    a::Assets # assets::Assets
    z::Liabilities # liabilities::Liabilities
    e::Equity # equity::Equity
    lo::Loans # loans::Loans
    li::Borrows # borrows::Borrows
    loss::Loss # loss::Loss
    s::States # states::States
    # i::BankInterbank # interbank::Interbank
end


## 函数区

## 计算各银行之总银行间资产负债
calc_B_A_BI(x) = sum(x, dims = 1)' # 计算各银行之银行间总资产
calc_B_Z_BI(x) = sum(x, dims = 2) # 计算各银行之银行间总负债








# end;
