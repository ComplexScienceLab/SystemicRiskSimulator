## 计算商业银行之资产负债表结构

##########################################
# 使用：在用；
# 状态：进行中；
##########################################

include("defineType.jl")
# include("setParameters.jl")
# include("initVariables.jl")


## 函数区



## 更新各银行之银行间市场变量





## 更新银行间资产矩阵，通过借贷变化
# update_BI_A(Z_BI_ij) = Z_BI_ij'

## 更新银行间负债矩阵，通过借贷变化
# update_BI_Z(A_BI_ij) = A_BI_ij'

## 转换银行间负债矩阵
alter_BI_Z(A_BI::BankInterbank) = A_BI'

## 转换银行间资产矩阵
alter_BI_A(Z_BI::BankInterbank) = Z_BI'

## update_B_setOfInsolvent()


## 更新各银行之资产负债表变量

## 更新各银行之所有者权益$E_all$
function update_B_E_all!(E_all::BankCommercial, A_all::BankCommercial, Z_all::BankCommercial)
    # E_all .= max.(A_all - Z_all, 0)
    E_all .= A_all - Z_all
end

## 更新各银行之银行总资产$A_all$
function update_B_A_all!(A_all::BankCommercial, A_BI::BankCommercial, A_exBI::BankCommercial)
    A_all .= A_BI + A_exBI
end

## 更新各银行之非银行间资产
function update_B_A_exBI!(A_exBI::BankCommercial, A_P::BankCommercial, A_R::BankCommercial)
    A_exBI .= A_P + A_R
end

## 更新各银行之银行总负债
function update_B_Z_all!(Z_all::BankCommercial, Z_BI::BankCommercial, Z_exBI::BankCommercial)
    Z_all .= Z_BI + Z_exBI
end

## 更新各银行之非银行间负债
function update_B_Z_exBI!(Z_exBI::BankCommercial, Z_DD::BankCommercial)
    Z_exBI .= Z_DD
end

## 更新各银行之总贷款流量
function update_B_Lo_all!(Lo_all::BankCommercial, Lo_BI::BankCommercial, Lo_exBI::BankCommercial)
    Lo_all .= Lo_BI + Lo_exBI
end

## 更新各银行之非银行间贷款流量
function update_B_Lo_exBI!(Lo_exBI::BankCommercial, Lo_P::BankCommercial)
    Lo_exBI .= Lo_P
end

## 更新各银行之总借款流量
function update_B_Li_all!(Li_all::BankCommercial, Li_BI::BankCommercial, Li_exBI::BankCommercial)
    Li_all .= Li_BI + Li_exBI
end

## 更新各银行之非银行间借款流量
function update_B_Li_exBI!(Li_exBI::BankCommercial, Li_DD::BankCommercial)
    Li_exBI .= Li_DD
end











