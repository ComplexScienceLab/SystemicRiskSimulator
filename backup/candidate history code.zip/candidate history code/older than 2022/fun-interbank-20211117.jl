## 函数区：构建银行间市场主体结构

##########################################
# 使用：在用；
# 状态：进行中；
##########################################


## 计算遮罩之于银行间资不抵债的
calc_maskOfInsolvent(isInsolvent::BankCommercial) = Bool.(isInsolvent) .| Bool.(isInsolvent)'

## 计算遮罩之于银行间有偿付能力的
calc_maskOfSolvent(isSolvent::BankCommercial) = .!Bool.(isSolvent) .| .!Bool.(isSolvent)'

## 更新各银行之银行间总资产
update_B_A_BI(A_BI::BankInterbank) = sum(A_BI, dims = 2)

## 更新各银行之银行间总负债
update_B_Z_BI(Z_BI::BankInterbank) = sum(Z_BI, dims = 1)'