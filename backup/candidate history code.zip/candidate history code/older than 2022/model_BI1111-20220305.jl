

## 模块之银行间市场BI1111

##########################################
#使用：备份于2022-03-05；
#状态：停止；
##########################################


function model_BI1111(BB::BankCommercial, BI::BankInterbank)


    ## 生成初始外生冲击
    tau = 0 # 初始化传染轮次

    ## # 初始时刻$t_{0}$：
    println("初始时刻$tau")

    # ## 更新各银行之变量 # HACK多余，已经在初始化过程定义，此处可以删除
    # update_B_Shock!(BB, BI, byWay = "all") # 更新各银行之所有冲击变量，在第一回合开始时
    # update_B_balanceSheet!(BB, BI; byWay = "all") # 更新各银行之资产负债表变量
    # update_B_state!(BB, BI; to = "any", from = "any") # 更新本轮银行B示性向量

    BB_t0 = deepcopy(BB) # 临时设置BB变量，被读取于阶段1
    BI_t0 = deepcopy(BI) # 临时设置BI变量，被读取于阶段1
    on = BB_t0.isOn # 临时设置BB有存在的示性变量，被读取于阶段1

    while (tau <= p.max_num_tau)

        tau += 1 # 传染轮次累加一
        println("开始传染回合$tau")

        ## 银行资产负债冲击阶段$t_{1}$，当$\tau>1$时：
        if tau > 1

            #BUG方案1
            # ## ## 银行内资产冲击 #BUG如何考虑叠加状态？如何防止变量被银行内负债冲击过程覆盖？
            # # BB.Shock_B_A[on] = BB.Shock_BI_def_t[on] # 银行间违约冲击传导至银行内资产冲击 # HACK多余，可以删除
            # # update_B_Shock!(BB, BI; byWay = "Shock_B_A") # 更新各银行之冲击变量，通过银行内资产冲击 # HACK多余，可以删除
            # # update_B_state!(BB, BI; to = "bankrupt",from = "healthy") # 更新各银行之状态，从健康到破产 # HACK多余，可以删除
            # BB.A_BI_all[on] = max.(BB.A_BI_all[on] - BB.Shock_B_A[on], 0.0) # 银行之银行间资产变动
            # update_B_balanceSheet!(BB, BI, byWay = "A_BI_all")
            # BB.E_all[on] = max.(BB.E_all[on] - BB.Shock_B_A[on], 0.0) # 银行之所有者权益变动
            # # update_B_balanceSheet!(BB, BI, byWay = "E_all and A_all")
            # BB.Z_BI_all[BB.isInsolvent] = BB.Z_BI_all[BB.isInsolvent] .* (ONES1[BB.isInsolvent] - (BB.Shock_B_A[BB.isInsolvent] - BB_t0.E_all[BB.isInsolvent]) ./ BB_t0.Z_all[BB.isInsolvent]) # 银行间负债变动，由于违约
            # BB.Z_D[BB.isInsolvent] = BB.Z_D[BB.isInsolvent] .* (ONES1[BB.isInsolvent] - (BB.Shock_B_A[BB.isInsolvent] - BB_t0.E_all[BB.isInsolvent]) ./ BB_t0.Z_all[BB.isInsolvent]) # 存款负债变动，由于违约
            # update_B_balanceSheet!(BB, BI; byWay = "Z_D") # 更新资产负债表，通过Z_D或Z_BI_all
            # BB.Shock_BI_def_s[on] = abs.(BB.Z_BI_all[on] - BB_t0.Z_BI_all[on]) # 银行内冲击传导至银行间传染冲击
            # BB.Shock_BI_run_br_s[BB.isBankrupt.&&BB.isInsolvent] = BB.A_BI_all[BB.isBankrupt.&&BB.isInsolvent] # 银行内冲击传导至银行倒闭冲击
            # update_B_Shock!(BB, BI; byWay = "Shock_BI_run_br_s") # 汇总各银行之倒闭流动性挤兑冲击、违约损失冲击

            # ## ## 银行内负债冲击 #BUG如何考虑叠加状态？如何防止变量被银行内资产冲击过程覆盖？
            # # BB.Shock_B_Z[on] = BB.Shock_BI_run_t[on] # 流动性短缺银行银行间挤兑流动冲击、破产银行银行间挤兑流动冲击传导至银行内负债冲击 # HACK多余，可以删除
            # # update_B_Shock!(BB, BI; byWay = "Shock_B_Z") # HACK多余，可以删除
            # # update_B_state!(BB, BI; to = "bankrupt",from = "healthy")  # 更新各银行之状态，从健康到破产 # HACK多余，可以删除
            # BB.Z_BI_all[on] = max.(BB.Z_BI_all[on] - BB.Shock_B_Z[on], 0.0) # 银行之银行间负债变动
            # update_B_balanceSheet!(BB, BI, byWay = "Z_BI_all")
            # BB.A_Q[on] = max.(BB.A_Q[on] - BB.Shock_B_Z[on], 0.0) # 银行之流动资产变动
            # update_B_balanceSheet!(BB, BI, byWay = "A_Q")
            # BB.A_BI_all[BB.isIlliquity] = BB.A_BI_all[BB.isIlliquity] .* (ONES1[BB.isIlliquity] - (BB.Shock_B_Z[BB.isIlliquity] - BB_t0.A_Q[BB.isIlliquity]) ./ BB_t0.A_all[BB.isIlliquity]) # 银行间资产变动，由于回收资产
            # BB.A_P[BB.isIlliquity] = BB.A_P[BB.isIlliquity] .* (ONES1[BB.isIlliquity] - (BB.Shock_B_Z[BB.isIlliquity] - BB_t0.A_Q[BB.isIlliquity]) ./ BB_t0.A_all[BB.isIlliquity]) # 非银行间贷款资产变动，由于回收资产
            # update_B_balanceSheet!(BB, BI; byWay = "A_P") # 更新资产负债表，通过A_P或A_BI_all
            # BB.Shock_BI_run_ilq_s[on] = abs.(BB.A_BI_all[on] - BB_t0.A_BI_all[on]) # 银行内冲击传导至银行间传染冲击
            # BB.Shock_BI_run_br_s[BB.isBankrupt.&&BB.isIlliquity] = BB.A_BI_all[BB.isBankrupt.&&BB.isIlliquity] # 银行内冲击传导至银行倒闭冲击
            # update_B_Shock!(BB, BI; byWay = "Shock_BI_run_br_s") # 汇总各银行之倒闭流动性挤兑冲击、流动性短缺流动性挤兑冲击

            # BUG方案2
            # ## # 设置临时变量
            # A_BI_all_01 = copy(BB.A_BI_all)
            # Z_BI_all_01 = copy(BB.Z_BI_all)
            # A_BI_all_02 = copy(BB.A_BI_all)
            # Z_BI_all_02 = copy(BB.Z_BI_all)

            # ## ## 银行内资产冲击 #BUG如何考虑叠加状态？如何防止变量被银行内负债冲击过程覆盖？
            # # BB.Shock_B_A[on] = BB.Shock_BI_def_t[on] # 银行间违约冲击传导至银行内资产冲击 # HACK多余，可以删除
            # # update_B_Shock!(BB, BI; byWay = "Shock_B_A") # 更新各银行之冲击变量，通过银行内资产冲击 # HACK多余，可以删除
            # # update_B_state!(BB, BI; to = "bankrupt",from = "healthy") # 更新各银行之状态，从健康到破产 # HACK多余，可以删除
            # A_BI_all_01[on] = max.(A_BI_all_01_01[on] - BB.Shock_B_A[on], 0.0) # 银行之银行间资产变动
            # update_B_balanceSheet!(BB, BI, byWay = "A_BI_all")
            # BB.E_all[on] = max.(BB.E_all[on] - BB.Shock_B_A[on], 0.0) # 银行之所有者权益变动
            # # update_B_balanceSheet!(BB, BI, byWay = "E_all and A_all")
            # Z_BI_all_01[BB.isInsolvent] = Z_BI_all_01[BB.isInsolvent] .* (ONES1[BB.isInsolvent] - (BB.Shock_B_A[BB.isInsolvent] - BB_t0.E_all[BB.isInsolvent]) ./ BB_t0.Z_all[BB.isInsolvent]) # 银行间负债变动，由于违约
            # BB.Z_D[BB.isInsolvent] = BB.Z_D[BB.isInsolvent] .* (ONES1[BB.isInsolvent] - (BB.Shock_B_A[BB.isInsolvent] - BB_t0.E_all[BB.isInsolvent]) ./ BB_t0.Z_all[BB.isInsolvent]) # 存款负债变动，由于违约
            # update_B_balanceSheet!(BB, BI; byWay = "Z_D") # 更新资产负债表，通过Z_D或Z_BI_all
            # BB.Shock_BI_def_s[on] = abs.(Z_BI_all_01[on] - BB_t0.Z_BI_all[on]) # 银行内冲击传导至银行间传染冲击
            # BB.Shock_BI_run_br_s[BB.isBankrupt.&&BB.isInsolvent] = A_BI_all_01[BB.isBankrupt.&&BB.isInsolvent] # 银行内冲击传导至银行倒闭冲击
            # update_B_Shock!(BB, BI; byWay = "Shock_BI_run_br_s") # 汇总各银行之倒闭流动性挤兑冲击、违约损失冲击

            # ## ## 银行内负债冲击 #BUG如何考虑叠加状态？如何防止变量被银行内资产冲击过程覆盖？
            # # BB.Shock_B_Z[on] = BB.Shock_BI_run_t[on] # 流动性短缺银行银行间挤兑流动冲击、破产银行银行间挤兑流动冲击传导至银行内负债冲击 # HACK多余，可以删除
            # # update_B_Shock!(BB, BI; byWay = "Shock_B_Z") # HACK多余，可以删除
            # # update_B_state!(BB, BI; to = "bankrupt",from = "healthy")  # 更新各银行之状态，从健康到破产 # HACK多余，可以删除
            # Z_BI_all_02[on] = max.(Z_BI_all_02[on] - BB.Shock_B_Z[on], 0.0) # 银行之银行间负债变动
            # update_B_balanceSheet!(BB, BI, byWay = "Z_BI_all")
            # BB.A_Q[on] = max.(BB.A_Q[on] - BB.Shock_B_Z[on], 0.0) # 银行之流动资产变动
            # update_B_balanceSheet!(BB, BI, byWay = "A_Q")
            # A_BI_all_02[BB.isIlliquity] = A_BI_all_02[BB.isIlliquity] .* (ONES1[BB.isIlliquity] - (BB.Shock_B_Z[BB.isIlliquity] - BB_t0.A_Q[BB.isIlliquity]) ./ BB_t0.A_all[BB.isIlliquity]) # 银行间资产变动，由于回收资产
            # BB.A_P[BB.isIlliquity] = BB.A_P[BB.isIlliquity] .* (ONES1[BB.isIlliquity] - (BB.Shock_B_Z[BB.isIlliquity] - BB_t0.A_Q[BB.isIlliquity]) ./ BB_t0.A_all[BB.isIlliquity]) # 非银行间贷款资产变动，由于回收资产
            # update_B_balanceSheet!(BB, BI; byWay = "A_P") # 更新资产负债表，通过A_P或A_BI_all
            # BB.Shock_BI_run_ilq_s[on] = abs.(A_BI_all_02[on] - BB_t0.A_BI_all[on]) # 银行内冲击传导至银行间传染冲击
            # BB.Shock_BI_run_br_s[BB.isBankrupt.&&BB.isIlliquity] = A_BI_all_02[BB.isBankrupt.&&BB.isIlliquity] # 银行内冲击传导至银行倒闭冲击
            # update_B_Shock!(BB, BI; byWay = "Shock_BI_run_br_s") # 汇总各银行之倒闭流动性挤兑冲击、流动性短缺流动性挤兑冲击

            # ## ## 合并银行间资产、银行间负债变化
            # BB.A_BI_all = A_BI_all_01 + A_BI_all_02
            # BB.Z_BI_all = Z_BI_all_01 + Z_BI_all_02

            #BUG方案3
            A_BI_all_01 = copy(BB.A_BI_all)
            Z_BI_all_01 = copy(BB.Z_BI_all)
            A_BI_all_02 = copy(BB.A_BI_all)
            Z_BI_all_02 = copy(BB.Z_BI_all)

            ## ## 银行内资产冲击 #BUG如何考虑叠加状态？如何防止变量被银行内负债冲击过程覆盖？
            # BB.Shock_B_A[on] = BB.Shock_BI_def_t[on] # 银行间违约冲击传导至银行内资产冲击 # HACK多余，可以删除
            # update_B_Shock!(BB, BI; byWay = "Shock_B_A") # 更新各银行之冲击变量，通过银行内资产冲击 # HACK多余，可以删除
            # update_B_state!(BB, BI; to = "bankrupt",from = "healthy") # 更新各银行之状态，从健康到破产 # HACK多余，可以删除
            BB.A_BI_all[on] = max.(BB.A_BI_all[on] - BB.Shock_B_A[on], 0.0) # 银行之银行间资产变动
            update_B_balanceSheet!(BB, BI, byWay = "A_BI_all")
            BB.E_all[on] = max.(BB.E_all[on] - BB.Shock_B_A[on], 0.0) # 银行之所有者权益变动
            # update_B_balanceSheet!(BB, BI, byWay = "E_all and A_all")
            BB.Z_BI_all[BB.isInsolvent] = ((BB.Shock_B_A[BB.isInsolvent] - BB_t0.E_all[BB.isInsolvent]) ./ (BB_t0.Z_BI_all[BB.isInsolvent] + BB_t0.Z_D[BB.isInsolvent])) .* BB_t0.Z_BI_all[BB.isInsolvent] + BB_t0.Z_BI_all[BB.isInsolvent] # 银行间负债变动，由于违约
            update_B_balanceSheet!(BB, BI; byWay = "Z_BI_all") # 更新资产负债表，通过Z_D或Z_BI_all
            BB.Z_D[BB.isInsolvent] = ((BB.Shock_B_A[BB.isInsolvent] - BB_t0.E_all[BB.isInsolvent]) ./ (BB_t0.Z_BI_all[BB.isInsolvent] + BB_t0.Z_D[BB.isInsolvent])) .* BB_t0.Z_D[BB.isInsolvent] + BB_t0.Z_D[BB.isInsolvent] # 存款负债变动，由于违约
            update_B_balanceSheet!(BB, BI; byWay = "Z_D") # 更新资产负债表，通过Z_D或Z_BI_all
            BB.Shock_BI_def_s[on] = abs.(BB.Z_BI_all[on] - BB_t0.Z_BI_all[on]) # 银行内冲击传导至银行间传染冲击
            update_B_Shock!(BB, BI; byWay = "Shock_BI_def_s") # 汇总各银行之倒闭流动性挤兑冲击、违约损失冲击
            BB.Shock_D_s[on] = abs.(BB.Z_D[on] - BB_t0.Z_D[on]) # 银行内冲击传导至银行存款传染冲击
            i0 = (BB.isBankrupt .&& BB.isInsolvent) # 计算状态之于银行集合其满足破产和资不抵债
            BB.Shock_BI_run_br_s[i0] = BB.A_BI_all[i0] # 资不抵债的和银行内冲击传导至银行倒闭冲击
            update_B_Shock!(BB, BI; byWay = "Shock_BI_run_br_s") # 汇总各银行之倒闭流动性挤兑冲击、违约损失冲击

            ## ## 银行内负债冲击 #BUG如何考虑叠加状态？如何防止变量被银行内资产冲击过程覆盖？
            # BB.Shock_B_Z[on] = BB.Shock_BI_run_t[on] # 流动性短缺银行银行间挤兑流动冲击、破产银行银行间挤兑流动冲击传导至银行内负债冲击 # HACK多余，可以删除
            # update_B_Shock!(BB, BI; byWay = "Shock_B_Z") # HACK多余，可以删除
            # update_B_state!(BB, BI; to = "bankrupt",from = "healthy")  # 更新各银行之状态，从健康到破产 # HACK多余，可以删除
            i1 = (on .&& ((BB.Z_D - BB.Shock_D_s) + ((BB.Z_BI_all - BB.Shock_BI_def_s)) .< BB.Shock_B_Z)) # 计算条件之于银行集合其满足其应违约但是应被收回
            BB.Shock_B_Z[i1] = (BB.Shock_D_s[i1] + BB.Shock_BI_def_s[i1]) - (BB.Z_D[i1] + BB.Z_BI_all[i1]) # 更新遭受实际银行内负债冲击
            update_B_Shock!(BB, BI; byWay = "Shock_B_Z")
            update_B_state!(BB, BI; to = "illiquity", from = "any")
            BB.Z_BI_all[on] = max.(BB.Z_BI_all[on] - BB.Shock_B_Z[on], 0.0) # 银行之银行间负债变动
            update_B_balanceSheet!(BB, BI, byWay = "Z_BI_all")
            BB.A_Q[on] = max.(BB.A_Q[on] - BB.Shock_B_Z[on], 0.0) # 银行之流动资产变动
            update_B_balanceSheet!(BB, BI, byWay = "A_Q")
            BB.A_BI_all[BB.isIlliquity] = ((BB.Shock_B_Z[BB.isIlliquity] - BB.A_Q[BB.isIlliquity]) ./ (BB_t0.A_P[BB.isIlliquity] + BB_t0.A_BI_all[BB.isIlliquity]) .* BB_t0.A_BI_all[BB.isIlliquity]) + BB_t0.A_BI_all[BB.isIlliquity] # 银行间资产应变动，由于回收资产
            update_B_balanceSheet!(BB, BI; byWay = "A_BI_all") # 更新资产负债表，通过A_P或A_BI_all
            BB.Shock_BI_run_ilq_s[on] = abs.(BB.A_BI_all[on] - BB_t0.A_BI_all[on]) # 计算应银行内冲击传导至银行间传染冲击
            update_B_Shock!(BB, BI; byWay = "Shock_BI_run_ilq_s") # 汇总各银行之流动性短缺流动性挤兑冲击
            # i2 = (on .&& (BB.Shock_BI_run_ilq_s + BB.Shock_B_A .> BB.A_BI_all)) # 计算条件之于银行集合其满足其应收回但是应被损失 # HACK多余，可以删除
            # BB.Shock_BI_run_ilq_s[i2] = BB.A_BI_all[i2] - BB.Shock_B_A[i2] # 更新造成实际银行间流动性挤兑冲击 # HACK多余，可以删除
            BB.A_P[BB.isIlliquity] = ((BB.Shock_B_Z[BB.isIlliquity] - BB.A_Q[BB.isIlliquity]) ./ (BB_t0.A_P[BB.isIlliquity] + BB_t0.A_BI_all[BB.isIlliquity]) .* BB_t0.A_P[BB.isIlliquity]) + BB_t0.A_P[BB.isIlliquity] # 非银行间贷款资产应变动，由于回收资产
            update_B_balanceSheet!(BB, BI; byWay = "A_P") # 更新资产负债表，通过A_P或A_BI_all
            BB.Shock_L_exBI_s[on] = abs.(BB.A_P[on] - BB_t0.A_P[on]) # 银行内冲击传导至银行厂商贷款传染冲击
            i0 = (BB.isBankrupt .&& BB.isIlliquity) # 计算状态之于银行集合其满足破产和流动性短缺
            BB.Shock_BI_run_br_s[i0] = BB.A_BI_all[i0] # 流动性短缺的银行内冲击传导至银行倒闭冲击
            update_B_Shock!(BB, BI; byWay = "Shock_BI_run_br_s") # 汇总各银行之倒闭流动性挤兑冲击


        ## # 初始外生冲击阶段$t_{1}$，当$\tau=1$时：
        else
            if p.theta_Shock_exBI_t == 1.0
                ## ## 银行之非银行间贷款违约损失冲击
                update_B_Shock!(BB, BI; byWay = "Shock_L_exBI_t") # 生成综合外生冲击
                BB.Shock_B_A[on] = BB.Shock_exBI_t[on] # 银行外冲击传导至银行内资产冲击
                update_B_Shock!(BB, BI; byWay = "Shock_B_A")
                BB.A_P[on] -= BB.Shock_B_A[on] # 银行之非银行间资产变动
                update_B_balanceSheet!(BB, BI, byWay = "A_P")
                update_B_state!(BB, BI; to = "bankrupt", from = "healthy") # 更新各银行之状态，从健康到破产
                BB.E_all[on] = max.(BB.E_all[on] - BB.Shock_B_A[on], 0.0) # 银行之所有者权益
                # update_B_balanceSheet!(BB, BI, byWay = "E_all and A_all") # 计算各银行之总负债Z_BI_all
                BB.Z_BI_all[BB.isInsolvent] = ((BB.Shock_B_A[BB.isInsolvent] - BB_t0.E_all[BB.isInsolvent]) ./ (BB_t0.Z_BI_all[BB.isInsolvent] + BB_t0.Z_D[BB.isInsolvent])) .* BB_t0.Z_BI_all[BB.isInsolvent] + BB_t0.Z_BI_all[BB.isInsolvent] # 银行间负债变动，由于违约
                update_B_balanceSheet!(BB, BI; byWay = "Z_BI_all") # 汇总各银行之非银行间负债Z_exBI、总负债Z_all，被动地计算所有者权益
                BB.Z_D[BB.isInsolvent] = ((BB.Shock_B_A[BB.isInsolvent] - BB_t0.E_all[BB.isInsolvent]) ./ (BB_t0.Z_BI_all[BB.isInsolvent] + BB_t0.Z_D[BB.isInsolvent])) .* BB_t0.Z_D[BB.isInsolvent] + BB_t0.Z_D[BB.isInsolvent] # 存款负债变动，由于违约
                update_B_balanceSheet!(BB, BI; byWay = "Z_D") # 汇总各银行之非银行间负债Z_exBI、总负债Z_all，被动地计算所有者权益
                BB.Shock_BI_def_s[on] = abs.(BB.Z_BI_all[on] - BB_t0.Z_BI_all[on]) # 银行内冲击传导至银行间传染冲击
                update_B_Shock!(BB, BI; byWay = "Shock_BI_def_s") # 汇总各银行之违约损失冲击
                BB.Shock_D_s[on] = abs.(BB.Z_D[on] - BB_t0.Z_D[on]) # 银行内冲击传导至银行存款传染冲击
                i0 = (BB.isBankrupt .&& BB.isInsolvent) # 计算状态之于银行集合其满足破产和资不抵债
                BB.Shock_BI_run_br_s[i0] = BB.A_BI_all[i0] # 资不抵债的和银行内冲击传导至银行倒闭冲击
                update_B_Shock!(BB, BI; byWay = "Shock_BI_run_br_s") # 汇总各银行之倒闭流动性挤兑冲击
            elseif p.theta_Shock_exBI_t == 0.0 #TODO如何考虑叠加状态？
                ## ## 银行存款挤兑流动冲击
                update_B_Shock!(BB, BI; byWay = "Shock_D_t") # 生成综合外生冲击
                BB.Shock_B_Z[on] = BB.Shock_exBI_t[on] # 银行外冲击传导至银行内负债冲击
                update_B_Shock!(BB, BI; byWay = "Shock_B_Z")
                update_B_state!(BB, BI; to = "bankrupt", from = "healthy") # 更新各银行之状态，从健康到破产
                BB.Z_D[on] -= BB.Shock_B_Z[on] # 存款负债变动
                update_B_balanceSheet!(BB, BI, byWay = "Z_D")
                BB.A_Q[on] = max.(BB.A_Q[on] - BB.Shock_B_Z[on], 0.0) # 流动资产变动
                update_B_balanceSheet!(BB, BI, byWay = "A_Q")
                BB.A_BI_all[BB.isIlliquity] = ((BB.Shock_B_Z[BB.isIlliquity] - BB.A_Q[BB.isIlliquity]) ./ (BB_t0.A_P[BB.isIlliquity] + BB_t0.A_BI_all[BB.isIlliquity]) .* BB_t0.A_BI_all[BB.isIlliquity]) + BB_t0.A_BI_all[BB.isIlliquity] # 银行间资产应变动，由于回收资产
                update_B_balanceSheet!(BB, BI; byWay = "A_BI_all") # 更新资产负债表，通过A_P或A_BI_all
                BB.A_P[BB.isIlliquity] = ((BB.Shock_B_Z[BB.isIlliquity] - BB.A_Q[BB.isIlliquity]) ./ (BB_t0.A_P[BB.isIlliquity] + BB_t0.A_BI_all[BB.isIlliquity]) .* BB_t0.A_P[BB.isIlliquity]) + BB_t0.A_P[BB.isIlliquity] # 非银行间贷款资产应变动，由于回收资产
                update_B_balanceSheet!(BB, BI; byWay = "A_P") # 更新资产负债表，通过A_P或A_BI_all
                BB.Shock_BI_run_ilq_s[on] = abs.(BB.A_BI_all[on] - BB_t0.A_BI[on]) # 银行内冲击传导至银行间传染冲击
                update_B_Shock!(BB, BI; byWay = "Shock_BI_run_ilq_s") # 汇总各银行之流动性短缺流动性挤兑冲击
                BB.Shock_L_exBI_s[on] = abs.(BB.A_P[on] - BB_t0.A_P[on]) # 银行内冲击传导至银行厂商贷款传染冲击
                i0 = (BB.isBankrupt .&& BB.isIlliquity) # 计算状态之于银行集合其满足破产和流动性短缺
                BB.Shock_BI_run_br_s[i0] = BB.A_BI_all[i0] # 流动性短缺的银行内冲击传导至银行倒闭冲击
                update_B_Shock!(BB, BI; byWay = "Shock_BI_run_br_s") # 汇总各银行之倒闭流动性挤兑冲击
            else
                throw(DomainError(p.theta_Shock_exBI_t, "参数暂时只能取值1或者0！"))
            end
        end

        ## # 判定本轮是否有银行转移状态从健康状态至其他状态，如果无则后续处理然后结束本轮，如果有则继续处理。
        if BB.isHealthy == BB_t0.isHealthy
            break
        end



        ## # 银行间传染冲击阶段$t_{2}$：

        ## 临时设置变量，用于被读取于阶段2
        A_BI_all_t1 = copy(BB.A_BI_all) # 临时设置变量``A_{BI}[i,t_{1}]``，被读取于阶段2
        Z_all_t1 = copy(BB.Z_all) # 临时设置变量``Z_{B}[i,t_{1}]``，被读取于阶段2
        A_BI_t1 = copy(BI.A_BI) # 临时设置变量``A_{BI}[i,t_{1}]``，被读取于阶段2

        update_B_Shock!(BB, BI; byWay = "clear Shock_B") # 清零银行内资产负债冲击

        ## ## 银行间违约损失冲击传染方式$i_{br} \stackrel{def,BI}{\longrightarrow} j_{cre}$：#BUG如何考虑叠加状态？如何防止变量被流动性短缺银行银行间挤兑流动冲击传染过程覆盖？
        isv = BB.isInsolvent # 临时设置BB资不抵债的示性变量，在阶段1
        cre_isv = BI.listOfCreditorsInInsolvent # 临时设置BI之列表之于资不抵债的银行之债权方银行编号
        for i in findall(isv) # 资不抵债银行违约，导致其对各债权银行负债变动，造成银行间违约冲击
            BI.Z_BI[i, cre_isv[i]] *= BB.Z_all[i] ./ BB_t0.Z_all[i]
            BI.Shock_BI_def[cre_isv[i], i] = BI_t0.Z_BI[i, cre_isv[i]] .* BB.Shock_BI_def_s[i] ./ BB_t0.Z_BI_all[i]
        end
        # HACK以下部分是否提取出来在阶段2结束之前使用
        update_B_balanceSheet!(BB, BI; byWay = "alter from Z_BI") # 转换银行间资产负债邻接矩阵
        update_B_Shock!(BB, BI; byWay = "Shock_BI_def") # 加总各单个债权银行遭受总银行间违约损失冲击
        # BB.A_BI_all[on] -= BB.Shock_BI_def_t[on] # HACK（仅作说明）各资不抵债银行对应债权银行之银行间资产变动（不是在此处出现，在银行内冲击阶段出现）。可以删除。
        BB.Shock_B_A[on] = BB.Shock_BI_def_t[on] # 银行间冲击传导为银行内冲击
        update_B_Shock!(BB, BI; byWay = "Shock_B_A") # 汇总各银行之银行内资产负债冲击

        ## ## 流动性短缺银行银行间挤兑流动冲击传染方式 $i_{ilq} \stackrel{BI,run}{\longrightarrow} k_{deb}$ #BUG如何考虑叠加状态？如何防止变量被银行间违约损失冲击传染过程覆盖？
        ilq = BB.isIlliquity # 临时设置BB流动性短缺的示性变量，在阶段1
        deb_ilq = BI.listOfDebtorsInIlliquity # 临时设置BI之列表之于流动性短缺的银行之债务方银行编号
        for i in findall(ilq) # 流动性短缺银行收回资产，导致其对各债务银行之资产变动，造成流动性短缺银行间挤兑流动冲击
            BI.A_BI[i, deb_ilq[i]] *= BB.A_BI_all[i] ./ BB_t0.A_BI_all[i]
            BI.Shock_BI_run_ilq[deb_ilq[i], i] = BI.A_BI[i, deb_ilq[i]] .* BB.Shock_BI_run_ilq_s[i] ./ BB_t0.Z_BI_all[i] # 注意这里用BI.A_BI而非BI.Z_BI是因为转换资产负债表过程被放在后面了
        end
        # HACK以下部分是否提取出来在阶段2结束之前使用
        update_B_balanceSheet!(BB, BI; byWay = "alter from A_BI") # 转换银行间资产负债邻接矩阵
        update_B_Shock!(BB, BI; byWay = "Shock_BI_run_ilq") # 加总各单个债务银行遭受总银行间挤兑流动冲击
        # BB.A_BI_all[on] -= BB.Shock_BI_run_ilq_t[on] # HACK（仅作说明）各流动性短缺银行对应债务银行之银行间负债变动（不是在此处出现，而是在银行内冲击阶段出现）。可以删除。
        BB.Shock_B_Z[on] = BB.Shock_BI_run_t[on] # 银行间冲击传导为银行内冲击
        update_B_Shock!(BB, BI; byWay = "Shock_B_Z") # 汇总各银行之银行内资产负债冲击


        ## ## 破产银行银行间挤兑流动冲击传染方式 $i_{br} \stackrel{BI,run}{\longrightarrow} k_{deb}$。
        update_B_state!(BB, BI; to = "bankrupt", from = "any") # 更新示性向量之于破产银行状态
        br = BB.isBankrupt # 临时设置BB破产的示性变量
        deb_br = BI.listOfDebtorsInBankrupt # 临时设置BI之列表之于破产的银行之债务方银行编号
        for i in findall(br) # 破产银行收回其银行间资产，用于偿还其银行间负债。此举导致其对各债务银行之资产变动，造成破产银行银行间挤兑流动冲击
            BI.Shock_BI_run_br[deb_br[i], i] = BI.A_BI[i, deb_br[i]]
            BI.A_BI[i, deb_br[i]] .= 0.0
        end
        # HACK以下部分是否提取出来在阶段2结束之前使用
        update_B_balanceSheet!(BB, BI; byWay = "alter from A_BI") # 转换银行间资产负债邻接矩阵
        update_B_Shock!(BB, BI; byWay = "Shock_BI_run_br") # 加总各单个债务银行遭受总银行间挤兑流动冲击
        # BB.A_BI_all[on] -= BB.Shock_BI_run_br_t[on] # HACK（仅作说明）各流动性短缺银行对应债务银行之银行间负债变动（不是在此处出现，在银行内冲击阶段出现）。可以删除。
        BB.Shock_B_Z[on] = BB.Shock_BI_run_t[on] # 银行间冲击传导为银行内冲击
        update_B_Shock!(BB, BI; byWay = "Shock_B_Z") # 更新各银行之冲击变量，通过银行内负债冲击





        ## ## 尾声时刻

        update_B_balanceSheet!(BB, BI; byWay = "calc all E_all") # 更新计算各银行之所有者权益
        BB_tau[tau] = deepcopy(BB) # 存储该轮次传染结果数据
        BI_tau[tau] = deepcopy(BI) # 存储该轮次传染结果数据

        BB_t0 = deepcopy(BB) # 临时设置BB变量，被读取于下一回合之阶段1
        BI_t0 = deepcopy(BI) # 临时设置BI变量，被读取于下一回合之阶段1
        on = BB.isOn # 临时设置BB有存在的示性变量，被读取于下一回合之阶段1

        ## 更新各银行之变量，
        update_B_Shock!(BB, BI; byWay = "clear Shock_BI and Shock_exBI") # 清零各银行之不必要的冲击变量，被使用于下一回合，从第二回合开始
        update_B_balanceSheet!(BB, BI; byWay = "all") # 更新各银行之资产负债表变量，被使用于下一回合
        update_B_state!(BB, BI; to = "any", from = "any") # 更新本轮银行B示性向量，被使用于下一回合

    end # while

    ## # 破产清算阶段$t_{3}$：#FIXME #NOW，有问题需要解决：为什么程序运行至第二回合破产清算阶段，程序计算出来的总资产量不对等于手算出来的总资产量？
    cre_br = BI.listOfCreditorsInBankrupt # 临时设置BI之列表之于破产的银行之债权方银行编号
    for i in findall(br) # 破产银行偿还银行间借款，破产银行对应债权银行之银行间资产变成各自债权银行之其它资产
        BB.A_other[cre_br[i]] += BI.A_BI[cre_br[i], i]
        BI.A_BI[cre_br[i], i] .= 0.0
    end
    update_B_balanceSheet!(BB, BI; byWay = "alter from A_BI") # 转换银行间资产负债邻接矩阵
    update_B_balanceSheet!(BB, BI; byWay = "sum A_BI") # 加总银行间资产变量
    update_B_balanceSheet!(BB, BI; byWay = "sum Z_BI") # 加总银行间负债变量
    update_B_balanceSheet!(BB, BI; byWay = "A_other") # 更新各银行之资产负债表变量，通过其它资产
    BB.A_BI_all[br] .= 0.0 # 破产银行之银行间贷款清零
    BB.A_P[br] .= 0.0 # 破产银行之非银行间贷款清零
    BB.A_Q[br] .= 0.0 # 破产银行之流动资金清零
    BB.A_R[br] .= 0.0 # 破产银行之存款准备金清零
    BB.A_other[br] .= 0.0 # 破产银行之其它资产清零
    update_B_balanceSheet!(BB, BI; byWay = "A_exBI") # 更新各银行之资产负债表变量，通过非银行间资产
    BB.Z_D[br] .= 0.0 # 破产银行之居民存款清零
    BB.Z_other[br] .= 0.0 # 破产银行之其它负债清零
    BB.Z_BI_all[br] .= 0.0 # 破产银行之银行间贷款清零
    update_B_balanceSheet!(BB, BI; byWay = "Z_D") # 更新各银行之资产负债表变量，通过非银行间负债
    update_B_state!(BB, BI; to = "off", from = "bankrupt") # 更新各银行之状态，从破产到退出



    ## 收尾
    update_B_balanceSheet!(BB, BI; byWay = "calc all E_all") # 更新计算各银行之所有者权益
    BB_tau[tau] = deepcopy(BB) # 存储该轮次传染结果数据
    BI_tau[tau] = deepcopy(BI) # 存储该轮次传染结果数据


    return BB, BI, BB_tau, BI_tau

    println("model_BI1111结束。")

end # end function


# end; # module


