## 定义各类变量

##########################################
# 使用：在用；
# 状态：进行中；
##########################################

# module InitVariables
# export obj_BI,initObj

include("setParameters.jl")
include("defineType.jl")

using StructArrays
# using .DefineType

## 初始化银行数组常量
const FALSE1 = fill(false, num_bank) # 一维false布尔向量常量
const FALSE2 = fill(false, num_bank, num_bank) # 二维方阵false布尔向量常量
const BLANK1 = fill("", num_bank) # 一维空字符串向量常量
const BLANK2 = fill("", num_bank, num_bank) # 一维方阵空字符串向量常量
const ZEROS1 = zeros(num_bank) # 一维零向量常量
const ZEROS2 = zeros(num_bank, num_bank) # 二维方阵零向量常量
const ONES1 = ones(num_bank) # 一维幺向量常量
const ONES2 = ones(num_bank, num_bank) # 二维方阵幺向量常量

## 定义银行相关变量
# ids = range(1,num_bank,step=1) # 各银行ID
# assetsBB = ZEROS1 # 各银行资产
# liabilitiesBB = ZEROS1 # 各银行负债
# equityBB = ZEROS1 # 各银行所有者权益
# loan{BB} = zeros(num_bank,numAssets) # 各银行贷款量
# borrowBB = zeros(num_bank,numAssets) # 各银行负债量
#
#
# ## 定义银行间市场损失量
#
# lossBI = ZEROS1
## 定义各类变量

##########################################
# 使用：在用；
# 状态：进行中；
##########################################

## 初始化个体实例
## 初始化基础个体常用属性实例
object_BB = Objects{1}(range(1, num_bank, step = 1), BLANK1, BLANK1)
object_BI = Objects{2}(reshape(range(1, num_bank^2, step = 1), (num_bank, num_bank)), BLANK2, BLANK2)

## 初始化资产实例
assets = Assets(ZEROS1, ZEROS1, ZEROS1, ZEROS1, ZEROS1)

## 初始化负债实例
liabilities = Liabilities(ZEROS1, ZEROS1, ZEROS1, ZEROS1)

## 初始化所有者权益实例
equity = Equity(ZEROS1)

## 初始化贷款实例
loans = Loans(ZEROS1, ZEROS1, ZEROS1)

## 初始化借款实例
borrows = Borrows(ZEROS1, ZEROS1, ZEROS1)

## 初始化损失资金实例
loss = Loss(ZEROS1, ZEROS1, ZEROS1, ZEROS1, ZEROS1)

## 初始化状态实例
states = States(FALSE1)

## 初始化银行间邻接矩阵
obj_BI = BankInterbank(object_BI, ZEROS2, ZEROS2, ZEROS2, ZEROS2)

## 初始化商业银行实例
obj_BB = BankCommercial(object_BB, assets, liabilities, equity, loans, borrows, loss, states)

## 初始化带传染轮次变量的商业银行实例数组
obj_BB_tau = StructArray([BankCommercial(object_BB, assets, liabilities, equity, loans, borrows, loss, states) for i = 1:max_num_tau])

## 初始化实例函数（暂时不用）
# function initObj()
#     ## 初始化个体实例
#     object = Objects(range(1, num_bank, step=1), blank1, blank1)
#     ## 初始化资产实例
#     assets = Assets(ZEROS1, ZEROS1, ZEROS1)
#     ## 初始化负债实例
#     liabilities = Liabilities(ZEROS1, ZEROS1, ZEROS1, ZEROS1)
#     ## 初始化所有者权益实例
#     equity = Equity(ZEROS1)
#     ## 初始化贷款实例
#     loans = Loans(ZEROS1, ZEROS1, ZEROS1)
#     ## 初始化借款实例
#     borrows = Borrows(ZEROS1, ZEROS1, ZEROS1)
#     ## 初始化损失资金实例
#     loss = Loss(ZEROS1, ZEROS1, ZEROS1, ZEROS1)
#     ## 初始化状态实例
#     states = States(fill(false, num_bank))
#     ## 初始化商业银行实例
#     obj_BI = BankCommercial(object, assets, liabilities, equity, loans, borrows, loss, states)
#     return obj_BI
# end
# ## 初始化银行间市场结构体
# obj_BI = initObj()



## 
## 初始化主要变量，通过导入外部变量值数据
loss_init_BI = ONES1 # 初始化银行间初始损失
loss_init_exBI = ZEROS1 # 初始化非银行间初始损失
## 导入初始化的非银行间初始损失
loss_def_BI = ZEROS1 # 初始化银行间违约损失
loss_run_BI = ZEROS1 # 初始化银行间挤兑损失
loss_a_B = ZEROS1 # 初始化银行资产损失


## 初始化其他变量
tau = 1 # 初始化传染轮次编号

# tau = Vector{Int16}(range(1, 1, step=1)) # 初始化传染轮次数组

# println(append!(tau,maximum(tau)+1))

# loss_init_BI=obj_BI.loss.def+obj_BI.loss.run

# testing...



# end; # module

