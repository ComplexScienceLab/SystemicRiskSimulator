## 定义类型，风格3-1

##########################################
# 使用：在用；
# 状态：进行中；
##########################################

module DefineType_style_3_1_20211110

## 定义个体抽象类型
# abstract type Object end
# abstract type Bank <: Object end
# abstract type BB <: Bank end # 定义商业银行BankCommercial个体抽象类型
# abstract type BS <: Bank end # 定义影子银行BankShadow个体抽象类型

## 定义个体常用属性
TypeId = Array{Int16} # 编号值
TypeAbbr = Array{String} # 缩写
TypeName = Array{String} # 名称

## 定义资金类型
TypeMoney = Array{Float64} # 资金

## 定义资产类型
TypeAssets = TypeMoney
TypeAssetstotal = TypeAssets # 总资产
TypeAssetsBI = TypeAssets # 银行间资产
TypeAssetsunBI = TypeAssets # 非银行间资产

## 定义负债类型
TypeLiabilities = TypeMoney
TypeLiabilitiestotal = TypeLiabilities # 总负债
TypeLiabilitiesBI = TypeLiabilities # 银行间负债
TypeLiabilitiesunBI = TypeLiabilities # 非银行间负债
TypeLiabilitiesdeposits = TypeLiabilities # 银行存款

## 定义所有者权益类型
TypeEquity = TypeMoney # 所有者权益

## 定义贷款类型
TypeLoans = TypeMoney
TypeLoanstotal = TypeLoans # 总贷款
TypeLoansBI = TypeLoans # 银行间贷款
TypeLoansunBI = TypeLoans # 非银行间贷款

## 定义借款类型
TypeBorrows = TypeMoney
TypeBorrowstotal = TypeBorrows # 总贷款
TypeBorrowsBI = TypeBorrows # 银行间贷款
TypeBorrowsunBI = TypeBorrows # 非银行间贷款

## 定义损失类型
TypeLoss = TypeMoney
TypeLoss_exBI = TypeLoss # 非银行间贷款
TypeLoss_default = TypeLoss # 总冲击损失
TypeLoss_run = TypeLoss # 银行间贷款

## 定义状态类型
TypeState = Array{Bool}
TypeIsInsolvent = TypeState # 是否资不抵债


## 定义个体复合类型
mutable struct Objects
    id::TypeId
    abbr::TypeAbbr
    name::TypeName
end

## 定义资产复合类型
mutable struct Assets
    total::TypeAssetstotal
    BI::TypeAssetsBI
    unBI::TypeAssetsunBI
end

## 定义负债复合类型
mutable struct Liabilities
    total::TypeLiabilitiestotal
    BI::TypeLiabilitiesBI
    unBI::TypeLiabilitiesunBI
    D::TypeLiabilitiesdeposits
end

## 定义所有者权益复合类型
mutable struct Equity
    E::TypeEquity
end

## 定义贷款复合类型
mutable struct Loans
    total::TypeLoanstotal
    BI::TypeLoansBI
    unBI::TypeLoansunBI
end

## 定义借款复合类型
mutable struct Borrows
    total::TypeBorrowstotal
    BI::TypeBorrowsBI
    unBI::TypeBorrowsunBI
end

## 定义损失复合类型
mutable struct Loss
    unBI::TypeLoss_exBI
    def::TypeLoss_default
    run::TypeLoss_run
end



## 定义状态复合类型
mutable struct States
    isInsolvent::TypeIsInsolvent
end

## 定义商业银行复合类型
mutable struct BankCommercial
    i::Objects
    a::Assets
    z::Liabilities
    e::Equity
    lo::Loans
    li::Borrows
    loss::Loss
    s::States
end


end;
