## 函数：模块之于银行传染与冲击

##########################################
#状态/开发
##########################################

"函数：银行外部违约损失传染"
function exBank_insolvent_contagion!(BB::BankCommercial, BI::BankInterbank, b::TypeState{1}, ib::TypeState{2}, para::ParameterVariables)
    ## # 银行外部违约损失传染阶段
    # if para.theta_Shock_exBI_t == 1.0 #HACK无用
    BB.Shock_P_def_t[para.idx_Shock_exBI_t] = para.Shock_exBI_t[para.idx_Shock_exBI_t] # 生成厂商贷款违约损失冲击
    update_B_Shock!(BB, BI, b, ib; byWay = "Shock_P_def_t") # 厂商贷款违约损失冲击传导至银行内资产冲击
    # update_B_Shock!(BB, BI, b, ib; byWay = "Shock_P_def_t") # 生成综合外生冲击 #HACK无用
    # BB.Shock_B_A[b] = BB.Shock_P_def_t[b] # 厂商贷款违约损失冲击传导至银行内资产冲击 #HACK（仅作说明）Shock_B_A==Shock_def_t，已经替代Shock_B_A以Shock_def_t。
    # update_B_Shock!(BB, BI, b, ib; byWay = "Shock_B_A") #HACK无用
    # elseif para.theta_Shock_exBI_t != 0.0 #HACK无用
    #     throw(DomainError(para.theta_Shock_exBI_t, "参数暂时只能取值1或者0！")) #HACK无用
    # end # if #HACK无用

    return BB, BI
end # function


"函数：银行外部违约损失冲击"
function exBank_insolvent_shock!(BB::BankCommercial, BI::BankInterbank, BB_t1::BankCommercial, BI_t1::BankInterbank, b::TypeState{1}, ib::TypeState{2}, para::ParameterVariables)
    ## # 银行外部违约损失冲击阶段
    # update_B_Shock!(BB, BI, b, ib; byWay = "clear Shock_BI and Shock_exBI") # 清零银行间和银行外冲击变量 #HACK可能无意义
    # if para.theta_Shock_exBI_t == 1.0 #HACK无用
    BB.A_P[b] -= BB.Shock_def_t[b] # 银行之非银行间资产变动
    update_B_balanceSheet!(BB, BI, b, ib; byWay = "A_P")
    update_B_state!(BB, BI; to = "insolvent", from = "healthy") # 更新各银行之状态，从健康到资不抵债
    # update_B_state!(BB, BI; to = "bankrupt", from = "insolvent") # 更新各银行之状态，从资不抵债到破产
    BB.E_all[BB.on] = max.(BB.E_all[BB.on] - BB.Shock_def_t[BB.on], 0.0) # 银行之所有者权益
    # update_B_balanceSheet!(BB, BI,b,ib; byWay = "E_all and A_all") # 计算各银行之总负债Z_BI_all #HACK无意义
    BB.Shock_BI_def_s[BB.isv] = abs.((BB.Shock_def_t[BB.isv] - BB_t1.E_all[BB.isv]) ./ (BB_t1.Z_BI_all[BB.isv] + BB_t1.Z_D[BB.isv]) .* BB_t1.Z_BI_all[BB.isv]) # 银行内冲击传导至银行间传染冲击
    update_B_Shock!(BB, BI, b, ib; byWay = "Shock_BI_def_s") # 汇总各银行之违约损失冲击
    BB.Z_BI_all[BB.isv] = BB_t1.Z_BI_all[BB.isv] - BB.Shock_BI_def_s[BB.isv] # 银行间负债变动，由于违约
    update_B_balanceSheet!(BB, BI, b, ib; byWay = "Z_BI_all") # 汇总各银行之非银行间负债Z_exBI、总负债Z_all，被动地计算所有者权益
    BB.Shock_D_def_s[BB.isv] = abs.((BB.Shock_def_t[BB.isv] - BB_t1.E_all[BB.isv]) ./ (BB_t1.Z_BI_all[BB.isv] + BB_t1.Z_D[BB.isv]) .* BB_t1.Z_D[BB.isv]) # 银行内冲击传导至银行存款传染冲击
    BB.Z_D[BB.isv] = BB_t1.Z_D[BB.isv] - BB.Shock_D_def_s[BB.isv] # 存款负债变动，由于违约
    update_B_balanceSheet!(BB, BI, b, ib; byWay = "Z_D") # 汇总各银行之非银行间负债Z_exBI、总负债Z_all，被动地计算所有者权益
    # elseif para.theta_Shock_exBI_t != 0.0 #HACK无用
    #     throw(DomainError(para.theta_Shock_exBI_t, "参数暂时只能取值1或者0！")) #HACK无用
    # end # if #HACK无用

    # update_B_Shock!(BB, BI, b, ib; byWay = "clear Shock_B_A and Shock_B_Z") # 清零银行内资产负债冲击

    BB.Shock_P_def_t[BB.isv] = ZEROS1[BB.isv] # 清零银行间和银行外冲击变量
    update_B_Shock!(BB, BI, b, ib; byWay = "Shock_P_def_t")
    # update_B_Shock!(BB, BI, b, ib; byWay = "clear Shock_BI and Shock_exBI") # 清零银行间和银行外冲击变量 #HACK无意义

    return BB, BI, BB_t1, BI_t1
end # function




"函数：资不抵债银行间违约损失传染"
function interBank_insolvent_contagion!(BB::BankCommercial, BI::BankInterbank, BB_t1::BankCommercial, BI_t1::BankInterbank, b::TypeState{1}, ib::TypeState{2}, para::ParameterVariables)
    ## # 资不抵债银行间违约损失传染阶段
    for i in findall(BB.isv) # 资不抵债银行违约，导致其对各债权银行负债变动，造成银行间违约冲击
        BI.Shock_BI_def[BI.cre[i], i] = BI.Z_BI[i, BI.cre[i]] .* BB.Shock_BI_def_s[i] ./ BB_t1.Z_BI_all[i]
        BI.Z_BI[i, BI.cre[i]] -= BI.Shock_BI_def[BI.cre[i], i]
    end
    # HACK以下部分是否提取出来在阶段1结束之前使用
    update_B_balanceSheet!(BB, BI, b, ib; byWay = "alter to A_BI from Z_BI") # 转换银行间资产负债邻接矩阵
    update_B_Shock!(BB, BI, b, ib; byWay = "Shock_BI_def") # 加总各单个债权银行遭受总银行间违约损失冲击
    # BB.A_BI_all[b] -= BB.Shock_BI_def_t[b] # HACK（仅作说明）各资不抵债银行对应债权银行之银行间资产变动（不是在此处出现，在银行内冲击阶段出现）。可以删除。
    # BB.Shock_B_A[b] = BB.Shock_BI_def_t[b] # 银行间冲击传导为银行内冲击 #HACK（仅作说明）Shock_B_A==Shock_def_t，已经替代Shock_B_A以Shock_def_t。
    # update_B_Shock!(BB, BI, b, ib; byWay = "Shock_B_A") # 汇总各银行之银行内资产负债冲击 #HACK无用

    return BB, BI
end # function


"函数：资不抵债银行间违约损失冲击"
function interBank_insolvent_shock!(BB::BankCommercial, BI::BankInterbank, BB_t1::BankCommercial, BI_t1::BankInterbank, b::TypeState{1}, ib::TypeState{2}, para::ParameterVariables)
    ## # 资不抵债银行间违约损失冲击阶段
    # update_B_Shock!(BB, BI, b, ib; byWay = "clear Shock_BI and Shock_exBI") # 清零各银行之不必要的冲击变量 #HACK可能无意义
    BB.A_BI_all[b] = max.(BB.A_BI_all[b] - BB.Shock_def_t[b], 0.0) # 银行之银行间资产变动
    update_B_balanceSheet!(BB, BI, b, ib; byWay = "A_BI_all")
    BB.E_all[BB.on] = max.(BB.E_all[BB.on] - BB.Shock_def_t[BB.on], 0.0) # 银行之所有者权益变动
    update_B_state!(BB, BI; to = "insolvent", from = "healthy") # 更新各银行之状态，从健康到资不抵债
    # update_B_state!(BB, BI; to = "bankrupt", from = "insolvent") # 更新各银行之状态，从资不抵债到破产
    # update_B_balanceSheet!(BB, BI,b,ib; byWay = "E_all and A_all") #HACK冗余，可以删除
    BB.Z_BI_all[BB.isv] = BB_t1.Z_BI_all[BB.isv] - ((BB.Shock_def_t[BB.isv] - BB_t1.E_all[BB.isv]) ./ (BB_t1.Z_BI_all[BB.isv] + BB_t1.Z_D[BB.isv]) .* BB_t1.Z_BI_all[BB.isv]) # 银行间负债变动，由于违约
    update_B_balanceSheet!(BB, BI, b, ib; byWay = "Z_BI_all") # 更新资产负债表，通过Z_D或Z_BI_all
    BB.Z_D[BB.isv] = BB_t1.Z_D[BB.isv] - ((BB.Shock_def_t[BB.isv] - BB_t1.E_all[BB.isv]) ./ (BB_t1.Z_BI_all[BB.isv] + BB_t1.Z_D[BB.isv]) .* BB_t1.Z_D[BB.isv]) # 存款负债变动，由于违约
    update_B_balanceSheet!(BB, BI, b, ib; byWay = "Z_D") # 更新资产负债表，通过Z_D或Z_BI_all
    BB.Shock_BI_def_s[BB.isv] = abs.(BB.Z_BI_all[BB.isv] - BB_t1.Z_BI_all[BB.isv]) # 银行内冲击传导至银行间传染冲击
    update_B_Shock!(BB, BI, b, ib; byWay = "Shock_BI_def_s") # 汇总各银行之倒闭流动性挤兑冲击、违约损失冲击
    BB.Shock_D_def_s[BB.isv] = abs.(BB.Z_D[BB.isv] - BB_t1.Z_D[BB.isv]) # 银行内冲击传导至银行存款传染冲击

    # update_B_Shock!(BB, BI, b, ib; byWay = "clear Shock_B_A and Shock_B_Z") # 清零银行内资产负债冲击

    return BB, BI, BB_t1, BI_t1
end # function


"函数：银行外部挤兑流动冲击。考虑情况：存在部分债务银行之部分债务因为流动性短缺从而无法偿还。"
function exBank_illiquity_shock!(BB::BankCommercial, BI::BankInterbank, b::TypeState{1}, ib::TypeState{2}, para::ParameterVariables) #= BB_t1::BankCommercial, BI_t1::BankInterbank,  =#
    ## # 银行外部挤兑流动冲击阶段
    # update_B_Shock!(BB, BI, b, ib; byWay = "clear Shock_BI and Shock_exBI") # 清零银行间和银行外冲击变量 #HACK无用
    # if para.theta_Shock_exBI_t == 0.0 #HACK无用
    BB.Shock_D_run_t[para.idx_Shock_exBI_t] = para.Shock_exBI_t[para.idx_Shock_exBI_t] # 生成居民存款挤兑流动冲击
    update_B_Shock!(BB, BI, b, ib; byWay = "Shock_D_run_t") # 居民存款挤兑流动冲击传导至银行内负债冲击
    update_B_state!(BB, BI; to = "illiquity", from = "healthy") # 更新各银行之状态，从健康到流动性短缺
    # elseif para.theta_Shock_exBI_t != 1.0 #HACK无用
    #     throw(DomainError(para.theta_Shock_exBI_t, "参数暂时只能取值1或者0！")) #HACK无用
    # end # if #HACK无用

    # update_B_Shock!(BB, BI, b, ib; byWay = "clear Shock_B_A and Shock_B_Z")

    return BB, BI#= , BB_t1, BI_t1 =#
end # function


"函数：银行外部挤兑流动传染"
function exBank_illiquity_contagion!(BB::BankCommercial, BI::BankInterbank, b::TypeState{1}, ib::TypeState{2}, para::ParameterVariables)
    ## # 银行外部挤兑流动传染阶段
    # if para.theta_Shock_exBI_t == 0.0 #HACK无用
    # update_B_Shock!(BB, BI, b, ib; byWay = "Shock_D_run_t") # 生成综合外生冲击 #HACK无用
    # BB.Shock_B_Z[b] = BB.Shock_D_run_t[b] # 银行外冲击传导至银行内负债冲击 #HACK（仅作说明）Shock_B_Z==Shock_run_t，已经替代Shock_B_Z以Shock_run_t。
    # update_B_Shock!(BB, BI, b, ib; byWay = "Shock_B_Z") #HACK无用
    BB.Shock_P_run_s[BB.ilq] = abs.((BB.Shock_run_t[BB.ilq] - BB.A_Q[BB.ilq]) ./ (BB.A_P[BB.ilq] + BB.A_BI_all[BB.ilq]) .* BB.A_P[BB.ilq]) # 银行内冲击传导至银行厂商贷款传染冲击
    BB.Shock_BI_run_ilq_s[BB.ilq] = abs.((BB.Shock_run_t[BB.ilq] - BB.A_Q[BB.ilq]) ./ (BB.A_P[BB.ilq] + BB.A_BI_all[BB.ilq]) .* BB.A_BI_all[BB.ilq]) # 计算应银行内冲击传导至银行间传染冲击
    update_B_Shock!(BB, BI, b, ib; byWay = "Shock_BI_run_ilq_s")
    for i in findall(BB.on) # 流动性短缺银行计划收回资产，导致其对各债务银行之资产变动，造成流动性短缺银行间挤兑流动冲击
        BI.Shock_BI_run_ilq[BI.deb[i], i] = BI.A_BI[i, BI.deb[i]] .* BB.Shock_BI_run_ilq_s[i] ./ BB_t1.A_BI_all[i]
    end
    update_B_Shock!(BB, BI, b, ib; byWay = "Shock_BI_run_ilq") # 加总各单个债务银行遭受总银行间挤兑流动冲击
    # BB.Shock_B_Z[b] += BB.Shock_BI_run_ilq_t[b] # 银行间冲击传导为银行内冲击 #HACK（仅作说明）Shock_B_Z==Shock_run_t，已经替代Shock_B_Z以Shock_run_t。
    # update_B_Shock!(BB, BI, b, ib; byWay = "Shock_B_Z") # 汇总各银行之银行内资产负债冲击 #HACK无用
    update_B_state!(BB, BI; to = "illiquity", from = "healthy") # 更新各银行之状态，从健康到流动性短缺
    # elseif para.theta_Shock_exBI_t != 1.0 #HACK无用
    #     throw(DomainError(para.theta_Shock_exBI_t, "参数暂时只能取值1或者0！")) #HACK无用
    # end # if #HACK无用

    return BB, BI
end # function


# "函数：银行外部挤兑流动冲击。假设所有流动性短缺或者破产银行都能收回其债务银行之所有资金。" #状态/停用 #HACK可能会被删除
# function exBank_illiquity_shock_old!(BB::BankCommercial, BI::BankInterbank, BB_t1::BankCommercial, BI_t1::BankInterbank, b::TypeState{1}, ib::TypeState{2},para::ParameterVariables)
#     ## # 银行外部挤兑流动冲击阶段
#     update_B_Shock!(BB, BI, b, ib; byWay = "clear Shock_BI and Shock_exBI") # 清零银行间和银行外冲击变量
#     if para.theta_Shock_exBI_t == 0.0
#         BB.Z_D[b] -= BB.Shock_B_Z[b] # 存款负债变动
#         update_B_balanceSheet!(BB, BI, b, ib; byWay = "Z_D")
#         BB.A_Q[b] = max.(BB.A_Q[b] - BB.Shock_B_Z[b], 0.0) # 流动资产变动
#         update_B_balanceSheet!(BB, BI, b, ib; byWay = "A_Q")
#         update_B_state!(BB, BI; to = "illiquity", from = "healthy") # 更新各银行之状态，从健康到流动性短缺
#         # update_B_state!(BB, BI; to = "bankrupt", from = "illiquity") # 更新各银行之状态，从流动性短缺到破产
#         BB.A_BI_all[BB.ilq] = BB_t1.A_BI_all[BB.ilq] - ((BB.Shock_B_Z[BB.ilq] - BB_t1.A_Q[BB.ilq]) ./ (BB_t1.A_P[BB.ilq] + BB_t1.A_BI_all[BB.ilq]) .* BB_t1.A_BI_all[BB.ilq]) # 银行间资产应变动，由于回收资产
#         update_B_balanceSheet!(BB, BI, b, ib; byWay = "A_BI_all") # 更新资产负债表，通过A_BI_all
#         BB.Shock_BI_run_ilq_s[BB.ilq] = abs.(BB.A_BI_all[BB.ilq] - BB_t1.A_BI_all[BB.ilq]) # 银行内冲击传导至银行间传染冲击
#         update_B_Shock!(BB, BI, b, ib; byWay = "Shock_BI_run_ilq_s") # 汇总各银行之流动性短缺流动性挤兑冲击
#         BB.A_P[BB.ilq] = BB_t1.A_P[BB.ilq] - ((BB.Shock_B_Z[BB.ilq] - BB_t1.A_Q[BB.ilq]) ./ (BB_t1.A_P[BB.ilq] + BB_t1.A_BI_all[BB.ilq]) .* BB_t1.A_P[BB.ilq]) # 非银行间贷款资产应变动，由于回收资产
#         update_B_balanceSheet!(BB, BI, b, ib; byWay = "A_P") # 更新资产负债表，通过A_P
#         BB.Shock_P_run_s[BB.ilq] = abs.(BB.A_P[BB.ilq] - BB_t1.A_P[BB.ilq]) # 银行内冲击传导至银行厂商贷款传染冲击
#     elseif para.theta_Shock_exBI_t != 1.0
#         throw(DomainError(para.theta_Shock_exBI_t, "参数暂时只能取值1或者0！"))
#     end # if

#     return BB, BI, BB_t1, BI_t1
# end # function




"函数：银行外部挤兑流动分配借贷流量阶段"
function exBank_illiquity_allocate!(BB::BankCommercial, BI::BankInterbank, b::TypeState{1}, ib::TypeState{2}, para::ParameterVariables)
    ## # 银行外部挤兑流动分配借贷流量阶段

    # update_B_state!(BB, BI; to = "needed collect A_P", from = "any")
    # update_B_state!(BB, BI; to = "enabled collect A_P", from = "any")
    # BB.Li_P[BB.eLiP] = BB.Shock_P_run_s[BB.eLiP] # 计算银行收回厂商贷款流量
    # update_B_transfer!(BB, BI, b, ib; byWay = "Li_P")

    update_B_state!(BB, BI; to = "needed repay Z_D", from = "any")
    update_B_state!(BB, BI; to = "enabled repay Z_D", from = "any")
    BB.Bo_D[BB.eBoD] = min.(BB.A_Q[BB.eBoD], BB.Shock_D_run_t[BB.eBoD]) # 计算银行偿还居民借款流量
    update_B_transfer!(BB, BI, b, ib; byWay = "Bo_D")

    return BB, BI
end # function


"函数：银行外部挤兑流动执行借贷流量阶段"
function exBank_illiquity_repay!(BB::BankCommercial, BI::BankInterbank, b::TypeState{1}, ib::TypeState{2}, para::ParameterVariables)
    ## # 银行外部挤兑流动执行借贷流量阶段

    # BB.A_Q[b], BB.A_P[b], BB.Shock_P_run_s[b] = transfer_B_capital_reverse(BB.A_Q[b], BB.A_P[b], BB.Shock_P_run_s[b], BB.Li_P[b]) # 资产变动，因收回厂商贷款
    # # BB.A_Q[b] .*= (1 - para.kappa_A_P) #HACK 暂时还不用！
    # update_B_balanceSheet!(BB, BI, b, ib; byWay = "A_Q")
    # update_B_balanceSheet!(BB, BI, b, ib; byWay = "A_P")
    # update_B_Shock!(BB, BI, b, ib; byWay = "Shock_P_run_s")

    BB.Z_D[b], BB.A_Q[b], BB.Shock_D_run_t[b] = transfer_B_capital_reduce(BB.Z_D[b], BB.A_Q[b], BB.Shock_D_run_t[b], BB.Bo_D[b]) # 资产变动，因偿还居民存款
    update_B_balanceSheet!(BB, BI, b, ib; byWay = "A_Q")
    update_B_balanceSheet!(BB, BI, b, ib; byWay = "Z_D")
    update_B_Shock!(BB, BI, b, ib; byWay = "Shock_D_run_t")

    update_B_state!(BB, BI; to = "healthy", from = "illiquity") # 更新银行状态之流动性短缺的与健康的

    update_B_transfer!(BB, BI, b, ib; byWay = "clear transfer all") # 清零所有不必要的借贷流量变量；

    return BB, BI
end # function



# "函数：流动性短缺银行间挤兑流动传染。假设所有流动性短缺或者破产银行都能收回其债务银行之所有资金。" #状态/停用 #HACK可能会被删除
# function interBank_illiquity_contagion_old!(BB::BankCommercial, BI::BankInterbank, BB_t1::BankCommercial, BI_t1::BankInterbank, b::TypeState{1}, ib::TypeState{2},para::ParameterVariables)
#     ## # 流动性短缺银行间挤兑流动传染
#     update_B_Shock!(BB, BI, b, ib; byWay = "clear Shock_B_A and Shock_B_Z") # 清零银行内资产负债冲击
#     for i in findall(BB.ilq) # 流动性短缺银行收回资产，导致其对各债务银行之资产变动，造成流动性短缺银行间挤兑流动冲击
#         BI.A_BI[i, BI.deb[i]] .*= (1.0 - BB.Shock_BI_run_ilq_s[i] ./ BB_t1.A_BI_all[i])
#         BI.Shock_BI_run_ilq[BI.deb[i], i] = BI_t1.A_BI[i, BI.deb[i]] .* BB.Shock_BI_run_ilq_s[i] ./ BB_t1.A_BI_all[i] # 注意这里用BI.A_BI而非BI.Z_BI是因为转换资产负债表过程被放在后面了
#     end
#     # HACK以下部分是否提取出来在阶段1结束之前使用
#     update_B_balanceSheet!(BB, BI, b, ib; byWay = "alter to Z_BI from A_BI") # 转换银行间资产负债邻接矩阵
#     update_B_Shock!(BB, BI, b, ib; byWay = "Shock_BI_run_ilq") # 加总各单个债务银行遭受总银行间挤兑流动冲击
#     # BB.A_BI_all[b] -= BB.Shock_BI_run_ilq_t[b] # HACK（仅作说明）各流动性短缺银行对应债务银行之银行间负债变动（不是在此处出现，而是在银行内冲击阶段出现）。可以删除。
#     BB.Shock_B_Z[b] = BB.Shock_BI_run_t[b] # 银行间冲击传导为银行内冲击
#     update_B_Shock!(BB, BI, b, ib; byWay = "Shock_B_Z") # 汇总各银行之银行内资产负债冲击

#     return BB, BI
# end # function


# "函数：流动性短缺银行间挤兑流动冲击。假设所有流动性短缺或者破产银行都能收回其债务银行之所有资金。" #状态/停用 #HACK可能会被删除
# function interBank_illiquity_shock_old!(BB::BankCommercial, BI::BankInterbank, BB_t1::BankCommercial, BI_t1::BankInterbank, b::TypeState{1}, ib::TypeState{2},para::ParameterVariables)
#     ## # 资不抵债银行间违约损失冲击阶段
#     #= #HACK 仅在同时考虑违约损失冲击和挤兑流动冲击时才使用
#     i1 = (BB.on .&& ((BB.Z_D - BB.Shock_D_def_s) + ((BB.Z_BI_all - BB.Shock_BI_def_s)) .< BB.Shock_B_Z)) # 计算条件之于银行集合其满足其应违约但是应被收回
#     BB.Shock_B_Z[i1] = (BB.Shock_D_def_s[i1] + BB.Shock_BI_def_s[i1]) - (BB.Z_D[i1] + BB.Z_BI_all[i1]) # 更新遭受实际银行内负债冲击
#     update_B_Shock!(BB, BI, b, ib; byWay = "Shock_B_Z")
#     update_B_state!(BB, BI; to = "illiquity", from = "healthy")
#     =#
#     BB.Z_BI_all[b] = max.(BB.Z_BI_all[b] - BB.Shock_B_Z[b], 0.0) # 银行之银行间负债变动
#     update_B_balanceSheet!(BB, BI, b, ib; byWay = "Z_BI_all")
#     BB.A_Q[b] = max.(BB.A_Q[b] - BB.Shock_B_Z[b], 0.0) # 银行之流动资产变动
#     update_B_state!(BB, BI; to = "illiquity", from = "healthy") # 更新各银行之状态，从健康到流动性短缺
#     # update_B_state!(BB, BI; to = "bankrupt", from = "illiquity") # 更新各银行之状态，从流动性短缺到破产
#     update_B_balanceSheet!(BB, BI, b, ib; byWay = "A_Q")
#     BB.A_BI_all[BB.ilq] = BB_t1.A_BI_all[BB.ilq] - ((BB.Shock_B_Z[BB.ilq] - BB_t1.A_Q[BB.ilq]) ./ (BB_t1.A_P[BB.ilq] + BB_t1.A_BI_all[BB.ilq]) .* BB_t1.A_BI_all[BB.ilq]) # 银行间资产应变动，由于回收资产
#     update_B_balanceSheet!(BB, BI, b, ib; byWay = "A_BI_all") # 更新资产负债表，通过A_P或A_BI_all
#     BB.Shock_BI_run_ilq_s[BB.ilq] = abs.(BB.A_BI_all[BB.ilq] - BB_t1.A_BI_all[BB.ilq]) # 计算应银行内冲击传导至银行间传染冲击
#     update_B_Shock!(BB, BI, b, ib; byWay = "Shock_BI_run_ilq_s") # 汇总各银行之流动性短缺流动性挤兑冲击
#     BB.A_P[BB.ilq] = BB_t1.A_P[BB.ilq] - ((BB.Shock_B_Z[BB.ilq] - BB_t1.A_Q[BB.ilq]) ./ (BB_t1.A_P[BB.ilq] + BB_t1.A_BI_all[BB.ilq]) .* BB_t1.A_P[BB.ilq]) # 非银行间贷款资产应变动，由于回收资产
#     update_B_balanceSheet!(BB, BI, b, ib; byWay = "A_P") # 更新资产负债表，通过A_P或A_BI_all
#     BB.Shock_P_run_s[BB.ilq] = abs.(BB.A_P[BB.ilq] - BB_t1.A_P[BB.ilq]) # 银行内冲击传导至银行厂商贷款传染冲击
#     update_B_Shock!(BB, BI, b, ib; byWay = "clear Shock_B_A and Shock_B_Z") # 清零银行内资产负债冲击

#     return BB, BI, BB_t1, BI_t1
# end # function


"函数：流动性短缺银行间挤兑流动冲击。考虑情况：存在部分债务银行之部分债务因为流动性短缺从而无法偿还。"
function interBank_illiquity_shock!(BB::BankCommercial, BI::BankInterbank, b::TypeState{1}, ib::TypeState{2}, para::ParameterVariables)
    ## # 资不抵债银行间违约损失冲击阶段
    #= #HACK 仅在同时考虑违约损失冲击和挤兑流动冲击时才使用
    i1 = (BB.on .&& ((BB.Z_D - BB.Shock_D_def_s) + ((BB.Z_BI_all - BB.Shock_BI_def_s)) .< BB.Shock_B_Z)) # 计算条件之于银行集合其满足其应违约但是应被收回
    BB.Shock_B_Z[i1] = (BB.Shock_D_def_s[i1] + BB.Shock_BI_def_s[i1]) - (BB.Z_D[i1] + BB.Z_BI_all[i1]) # 更新遭受实际银行内负债冲击
    update_B_Shock!(BB, BI, b, ib; byWay = "Shock_B_Z")
    update_B_state!(BB, BI; to = "illiquity", from = "healthy")
    =#

    # update_B_Shock!(BB, BI, b, ib; byWay = "clear Shock_B_A and Shock_B_Z")

    return BB, BI, BB_t1, BI_t1
end # function


"函数：流动性短缺银行间挤兑流动冲击传染。考虑情况：存在部分债务银行之部分债务因为流动性短缺从而无法偿还。"
function interBank_illiquity_shock_contagion!(BB::BankCommercial, BI::BankInterbank, b::TypeState{1}, ib::TypeState{2}, para::ParameterVariables)
    ## # 流动性短缺银行间挤兑流动传染

    ##BUG 方式一：每个银行只有一次分配传染冲击之行为。
    i_nas = (BB.ilq .& .!BB.isAllocatedShock) # 临时设置示性变量，表示银行其未分配传染冲击。暨每个银行只有一次分配传染冲击之行为。
    BB.Shock_BI_run_ilq_s[i_nas] = abs.((BB.Shock_run_t[i_nas] - BB.A_Q[i_nas]) ./ (BB.A_P[i_nas] + BB.A_BI_all[i_nas]) .* BB.A_BI_all[i_nas]) # 计算应银行内冲击传导至银行间传染冲击
    update_B_Shock!(BB, BI, b, ib; byWay = "Shock_BI_run_ilq_s") # 汇总各银行之流动性短缺流动性挤兑冲击
    BB.Shock_P_run_s[i_nas] = abs.((BB.Shock_run_t[i_nas] - BB.A_Q[i_nas]) ./ (BB.A_P[i_nas] + BB.A_BI_all[i_nas]) .* BB.A_P[i_nas]) # 银行内冲击传导至银行厂商贷款传染冲击
    BB.isAllocatedShock .|= BB.ilq # 更新已经分配传染冲击的银行
    for i in findall(i_nas) # 流动性短缺银行计划收回资产，导致其对各债务银行之资产变动，造成流动性短缺银行间挤兑流动冲击
        BI.Shock_BI_run_ilq[BI.deb[i], i] = BI.A_BI[i, BI.deb[i]] .* BB.Shock_BI_run_ilq_s[i] ./ BB.A_BI_all[i]
    end
    update_B_Shock!(BB, BI, b, ib; byWay = "Shock_BI_run_ilq") # 加总各单个债务银行遭受总银行间挤兑流动冲击
    update_B_state!(BB, BI; to = "illiquity", from = "healthy") # 更新各银行之状态，从健康到流动性短缺

    # ##BUG 方式二：每个银行可以有多次分配传染冲击之行为。
    # i_nas = (BB.ilq .& .!BB.isAllocatedShock) # 临时设置示性变量，表示银行其未分配传染冲击。暨每个银行只有一次分配传染冲击之行为。
    # BB.Shock_BI_run_ilq_s[BB.ilq] = abs.((BB.Shock_run_t[BB.ilq] - BB.A_Q[BB.ilq]) ./ (BB.A_P[BB.ilq] + BB.A_BI_all[BB.ilq]) .* BB.A_BI_all[BB.ilq]) # 计算应银行内冲击传导至银行间传染冲击
    # update_B_Shock!(BB, BI, b, ib; byWay = "Shock_BI_run_ilq_s") # 汇总各银行之流动性短缺流动性挤兑冲击
    # BB.Shock_P_run_s[BB.ilq] = abs.((BB.Shock_run_t[BB.ilq] - BB.A_Q[BB.ilq]) ./ (BB.A_P[BB.ilq] + BB.A_BI_all[BB.ilq]) .* BB.A_P[BB.ilq]) # 银行内冲击传导至银行厂商贷款传染冲击
    # BB.isAllocatedShock .|= BB.ilq # 更新已经分配传染冲击的银行
    # for i in findall(BB.on) # 流动性短缺银行计划收回资产，导致其对各债务银行之资产变动，造成流动性短缺银行间挤兑流动冲击
    #     BI.Shock_BI_run_ilq[BI.deb[i], i] = BI.A_BI[i, BI.deb[i]] .* BB.Shock_BI_run_ilq_s[i] ./ BB.A_BI_all[i]
    # end
    # update_B_Shock!(BB, BI, b, ib; byWay = "Shock_BI_run_ilq") # 加总各单个债务银行遭受总银行间挤兑流动冲击
    # update_B_state!(BB, BI; to = "illiquity", from = "healthy") # 更新各银行之状态，从健康到流动性短缺

    return BB, BI
end # function


"函数：流动性短缺银行间挤兑流动分配借贷流量阶段"
function interBank_illiquity_allocate!(BB::BankCommercial, BI::BankInterbank, b::TypeState{1}, ib::TypeState{2}, para::ParameterVariables)
    ## # 流动性短缺银行间挤兑流动分配借贷流量阶段

    update_B_state!(BB, BI; to = "needed collect A_P", from = "any")
    update_B_state!(BB, BI; to = "enabled collect A_P", from = "any")
    BB.Li_P[BB.eLiP] = BB.Shock_P_run_s[BB.eLiP] # 计算银行收回厂商贷款流量
    update_B_transfer!(BB, BI, b, ib; byWay = "Li_P")

    update_B_state!(BB, BI; to = "needed repay Z_D", from = "any")
    update_B_state!(BB, BI; to = "enabled repay Z_D", from = "any")
    update_B_state!(BB, BI; to = "needed repay BI", from = "any")
    update_B_state!(BB, BI; to = "enabled repay BI", from = "any")
    BB.Bo_all[BB.eBoBI.|BB.eBoD] = min.(BB.A_Q[BB.eBoBI.|BB.eBoD], BB.Shock_run_t[BB.eBoBI.|BB.eBoD]) # 计算银行偿还借款总流量
    BB.Bo_D[BB.eBoBI.|BB.eBoD] = BB.Shock_D_run_t[BB.eBoBI.|BB.eBoD] .* (BB.Bo_all[BB.eBoBI.|BB.eBoD] ./ BB.Shock_run_t[BB.eBoBI.|BB.eBoD]) # 计算银行偿还居民借款流量
    BB.Bo_BI_all[BB.eBoBI.|BB.eBoD] = BB.Shock_BI_run_ilq_t[BB.eBoBI.|BB.eBoD] .* (BB.Bo_all[BB.eBoBI.|BB.eBoD] ./ BB.Shock_run_t[BB.eBoBI.|BB.eBoD]) # 计算银行偿还银行间借款流量
    update_B_transfer!(BB, BI, b, ib; byWay = "Bo_D") #HACK 这个必须放在这里！
    update_B_transfer!(BB, BI, b, ib; byWay = "Bo_BI_all")
    for i in findall(BB.eBoBI) # 计算银行偿还各债权银行借款流量
        BI.Bo_BI[i, BI.cre[i]] = BI.Shock_BI_run_ilq[i, BI.cre[i]] .* (BB.Bo_BI_all[i] ./ BB.Shock_BI_run_ilq_t[i])
    end
    update_B_transfer!(BB, BI, b, ib; byWay = "Bo_BI")

    return BB, BI
end # function

"函数：流动性短缺银行间挤兑流动执行借贷流量阶段"
function interBank_illiquity_repay!(BB::BankCommercial, BI::BankInterbank, b::TypeState{1}, ib::TypeState{2}, para::ParameterVariables)
    ## # 流动性短缺银行间挤兑流动执行借贷流量阶段

    BB.A_Q[b], BB.A_P[b], BB.Shock_P_run_s[b] = transfer_B_capital_reverse(BB.A_Q[b], BB.A_P[b], BB.Shock_P_run_s[b], BB.Li_P[b]) # 流动资产变动，因收回厂商贷款
    # BB.A_Q[b] .*= (1 - para.kappa_A_P) #HACK 暂时还不用！
    update_B_balanceSheet!(BB, BI, b, ib; byWay = "A_Q")
    update_B_balanceSheet!(BB, BI, b, ib; byWay = "A_P")
    update_B_Shock!(BB, BI, b, ib; byWay = "Shock_P_run_s")

    BB.Z_D[b], BB.A_Q[b], BB.Shock_D_run_t[b] = transfer_B_capital_reduce(BB.Z_D[b], BB.A_Q[b], BB.Shock_D_run_t[b], BB.Bo_D[b]) # 流动资产变动，因偿还居民存款
    update_B_balanceSheet!(BB, BI, b, ib; byWay = "A_Q")
    update_B_balanceSheet!(BB, BI, b, ib; byWay = "Z_D")
    update_B_Shock!(BB, BI, b, ib; byWay = "Shock_D_run_t")

    BI.Shock_BI_run_ilq[ib] -= BI.Bo_BI[ib] # 各银行间挤兑流动冲击变动，当偿还相应的银行间借款时
    update_B_Shock!(BB, BI, b, ib; byWay = "Shock_BI_run_ilq")
    BB.Shock_BI_run_ilq_s[b] -= BB.Li_BI_all[b] # 各银行之银行间挤兑流动冲击源头变动，当收回相应的银行间贷款时
    update_B_Shock!(BB, BI, b, ib; byWay = "Shock_BI_run_ilq_s")
    BI.Z_BI[ib] -= BI.Bo_BI[ib] # 各银行间负债变动，当偿还相应的银行间借款时
    update_B_balanceSheet!(BB, BI, b, ib; byWay = "sum Z_BI")
    update_B_balanceSheet!(BB, BI, b, ib; byWay = "alter to A_BI from Z_BI")
    # BI.A_BI[ib] += BI.Li_BI[ib]' # 各银行间资产变动，当收回相应的银行间贷款时
    update_B_balanceSheet!(BB, BI, b, ib; byWay = "sum A_BI")
    BB.A_Q[b] += (BB.Li_BI_all[b] - BB.Bo_BI_all[b]) # 各银行流动资金变动，当收回相应的银行间贷款、偿还相应的银行间借款时
    update_B_balanceSheet!(BB, BI, b, ib; byWay = "A_Q")

    update_B_state!(BB, BI; to = "healthy", from = "illiquity") # 更新银行状态之流动性短缺的与健康的

    update_B_transfer!(BB, BI, b, ib; byWay = "clear transfer all") # 清零所有不必要的借贷流量变量；

    return BB, BI
end # function


#TODO"函数：外生破产银行间挤兑流动传染"
function exBank_bankrupt_contagion!(BB::BankCommercial, BI::BankInterbank, b::TypeState{1}, ib::TypeState{2}, para::ParameterVariables)
    ## # 外生破产银行间挤兑流动传染
    if BB_t0.br != FALSE1 # 当最初存在已经判定倒闭的银行时执行以下过程
        BB.Shock_BI_run_br_s[BB.br], BB.A_BI_all[BB.br] = transfer_B_capital_reverse(BB.Shock_BI_run_br_s[BB.br], BB.A_BI_all[BB.br], BB.A_BI_all[BB.br]) # 转移破产银行之资产变动，并且银行内冲击传导至银行倒闭挤兑流动冲击
        BB.Shock_P_run_s[BB.br], BB.A_P[BB.br] = transfer_B_capital_reverse(BB.Shock_P_run_s[BB.br], BB.A_P[BB.br], BB.A_P[BB.br]) # 非银行间贷款资产应变动，由于回收资产，并且银行内冲击传导至银行厂商贷款传染冲击
        update_B_Shock!(BB, BI, b, ib; byWay = "Shock_BI_run_br_s") # 汇总各银行之倒闭流动性挤兑冲击
        update_B_state!(BB, BI; to = "off", from = "bankrupt") # 更新各银行之状态，从破产到退出
    end # if

    return BB, BI

end # function



#BUG"函数：外生破产银行间挤兑流动冲击"
function exBank_bankrupt_shock!(BB::BankCommercial, BI::BankInterbank, BB_t1::BankCommercial, BI_t1::BankInterbank, b::TypeState{1}, ib::TypeState{2}, para::ParameterVariables)
    ## # 外生破产银行银行间挤兑流动传染冲击
    if BB_t0.br != FALSE1 # 当最初存在已经判定倒闭的银行时执行以下过程
        update_B_state!(BB, BI; to = "bankrupt", from = "any") # 更新示性向量之于破产银行状态
        for i in findall(BB.br) # 破产银行收回其银行间资产，用于后续偿还其银行间负债。此举导致其对各债务银行之资产变动，造成破产银行银行间挤兑流动冲击
            BI.Shock_BI_run_br[BI.deb[i], i], BI.A_BI[i, BI.deb[i]] = transfer_B_capital_reverse(BI.Shock_BI_run_br[BI.deb[i], i], BI.A_BI[i, BI.deb[i]], BI.A_BI[i, BI.deb[i]])
        end
        # HACK以下部分是否提取出来在阶段1结束之前使用
        update_B_balanceSheet!(BB, BI, b, ib; byWay = "alter to Z_BI from A_BI") # 转换银行间资产负债邻接矩阵
        update_B_Shock!(BB, BI, b, ib; byWay = "Shock_BI_run_br") # 加总各单个债务银行遭受总银行间挤兑流动冲击
        BB.Shock_B_Z[b] = BB.Shock_BI_run_t[b] # 银行间冲击传导为银行内冲击
        update_B_Shock!(BB, BI, b, ib; byWay = "Shock_B_Z") # 更新各银行之冲击变量，通过银行内负债冲击

        # update_B_state!(BB, BI; to = "off", from = "bankrupt") # 更新各银行之状态，从破产到退出
    end # if

    return BB, BI, BB_t1, BI_t1

end # function


# #TODO "过程：破产银行间挤兑流动传染冲击"
# function interBank_bankrupt_contagion!(BB::BankCommercial, BI::BankInterbank, BB_t1::BankCommercial, BI_t1::BankInterbank,b::TypeState{1},ib::TypeState{2},para::ParameterVariables)
#     println(" ")
# end # function

# end # module
















# while  




#     ## 过程：破产银行间挤兑流动冲击传染 #TODO
#     println("过程：破产银行间挤兑流动冲击传染")

#         ## 初始化
#         env.tau = 0 # 初始化传染回合
#         env.is_end_round = false # 初始化结束判断

#         env.tau += 1 # 传染回合累加一
#         println("开始回合",env.tau)

#         ## # 初始阶段$t_{0}$，当$\env.tau=1$时：
#         println("t0 初始阶段")

#         b = TypeState{1}(BB.on .|| BB.off) # 临时设置BB示性变量
#         ib = TypeState{2}((BB.on .|| BB.off) .&& (BB.on .|| BB.off)') # 临时设置BI示性变量


#         ## # 破产资产负债冲击阶段$t_{3}$：，当$\env.tau=1$时：
#         println("t3 开始破产召回阶段")

#         ## ## 初始化：
#         println("t2-0 初始化")

#         ## 设置临时变量
#         BB_t1 = deepcopy(BB)
#         BI_t1 = deepcopy(BI)

#         ## 清零银行间和银行外冲击变量
#         update_B_Shock!(BB, BI, b, ib; byWay = "clear Shock_BI and Shock_exBI")

#         ## # 破产召回阶段$t_{3}$：，当$\env.tau=1$时：
#         println("t3 开始破产召回阶段")
#         update_B_state!(BB, BI; to = "bankrupt", from = "any") # 更新示性向量之于破产银行状态
#         BB.Shock_BI_run_br_s[BB.br], BB.A_BI_all[BB.br] = transfer_B_capital(BB.Shock_BI_run_br_s[BB.br], BB.A_BI_all[BB.br], BB.A_BI_all[BB.br]) # 转移破产银行之资产变动，并且银行内冲击传导至银行倒闭挤兑流动冲击
#         update_B_Shock!(BB, BI, b, ib; byWay = "Shock_BI_run_br_s") # 汇总各银行之倒闭流动性挤兑冲击
#         BB.Shock_P_run_s[BB.br], BB.A_P[BB.br] = transfer_B_capital(BB.Shock_P_run_s[BB.br], BB.A_P[BB.br], BB.A_P[BB.br]) # 非银行间贷款资产应变动，由于回收资产，并且银行内冲击传导至银行厂商贷款传染冲击
#         # update_B_state!(BB, BI; to = "off", from = "bankrupt") # 更新各银行之状态，从破产到退出

#         ## # 尾声阶段$t_{4}$：
#         println("t4 开始尾声阶段")

#         ## TODO存储数据
#         BB_tau[env.tau] = deepcopy(BB) # 存储该回合传染结果数据
#         BI_tau[env.tau] = deepcopy(BI) # 存储该回合传染结果数据

#         ## 清零银行内冲击变量
#         update_B_Shock!(BB, BI, b, ib; byWay = "clear Shock_B_A and Shock_B_Z") # 清零银行内资产负债冲击

#         ## 判定本回合是否有银行转移状态，如果无则后续处理然后结束本轮，如果有则继续处理。
#         if BB.br == BB_t1.br
#             env.is_end_round = true
#         end

#         ## 过程：流动性短缺银行间挤兑流动冲击传染
#         println("过程：流动性短缺银行间挤兑流动冲击传染")
#         while (env.tau <= env.max_num_tau .&& env.is_end_round != true) # 循环，当回合$\env.tau>1$时：

#             env.tau += 1 # 传染回合累加一
#             println("开始回合",env.tau)

#             ## 初始阶段$t_{0}$，当$\env.tau>1$时：
#             println("t0 初始阶段")

#             b = TypeState{1}(BB.on .|| BB.off) # 临时设置BB示性变量
#             ib = TypeState{2}((BB.on .|| BB.off) .&& (BB.on .|| BB.off)') # 临时设置BI示性变量


#             ## # 银行间传染冲击阶段$t_{1}$，当$\env.tau>1$时：
#             println("t1 开始银行间传染冲击阶段")

#             ## ## 流动性短缺银行银行间挤兑流动冲击传染方式 $i_{ilq} \stackrel{BI,run}{\longrightarrow} k_{deb}$：
#             println("t1-2 流动性短缺银行银行间挤兑流动冲击传染方式")
#             for i in findall(BB.ilq) # 流动性短缺银行收回资产，导致其对各债务银行之资产变动，造成流动性短缺银行间挤兑流动冲击
#                 BI.A_BI[i, BI.deb[i]] .*= (1.0 - BB.Shock_BI_run_ilq_s[i] ./ BB_t1.A_BI_all[i])
#                 BI.Shock_BI_run_ilq[BI.deb[i], i] = BI_t1.A_BI[i, BI.deb[i]] .* BB.Shock_BI_run_ilq_s[i] ./ BB_t1.A_BI_all[i] # 注意这里用BI.A_BI而非BI.Z_BI是因为转换资产负债表过程被放在后面了
#             end
#             # HACK以下部分是否提取出来在阶段1结束之前使用
#             update_B_balanceSheet!(BB, BI, b, ib; byWay = "alter to Z_BI from A_BI") # 转换银行间资产负债邻接矩阵
#             update_B_Shock!(BB, BI, b, ib; byWay = "Shock_BI_run_ilq") # 加总各单个债务银行遭受总银行间挤兑流动冲击
#             # BB.A_BI_all[b] -= BB.Shock_BI_run_ilq_t[b] # HACK（仅作说明）各流动性短缺银行对应债务银行之银行间负债变动（不是在此处出现，而是在银行内冲击阶段出现）。可以删除。
#             BB.Shock_B_Z[b] = BB.Shock_BI_run_t[b] # 银行间冲击传导为银行内冲击
#             update_B_Shock!(BB, BI, b, ib; byWay = "Shock_B_Z") # 汇总各银行之银行内资产负债冲击


#             ## # 银行资产负债冲击阶段$t_{2}$，当$\env.tau>1$时：
#             println("t2 开始银行资产负债冲击阶段")

#             ## ## 初始化：
#             println("t2-0 初始化")

#             ## 清零银行间和银行外冲击变量
#             update_B_Shock!(BB, BI, b, ib; byWay = "clear Shock_BI and Shock_exBI") # 清零各银行之不必要的冲击变量，被使用于下一回合，从第二回合开始

#             ## ## 银行内负债冲击：
#             println("t2-2 银行内负债冲击")

#             ## 设置临时变量
#             BB_t1 = deepcopy(BB) # 临时设置BB变量，被读取于本回合之银行资产冲击
#             BI_t1 = deepcopy(BI) # 临时设置BI变量，被读取于本回合之银行资产冲击

#             i1 = (BB.on .&& ((BB.Z_D - BB.Shock_D_def_s) + ((BB.Z_BI_all - BB.Shock_BI_def_s)) .< BB.Shock_B_Z)) # 计算条件之于银行集合其满足其应违约但是应被收回
#             BB.Shock_B_Z[i1] = (BB.Shock_D_def_s[i1] + BB.Shock_BI_def_s[i1]) - (BB.Z_D[i1] + BB.Z_BI_all[i1]) # 更新遭受实际银行内负债冲击
#             update_B_Shock!(BB, BI, b, ib; byWay = "Shock_B_Z")
#             update_B_state!(BB, BI; to = "illiquity", from = "healthy")
#             BB.Z_BI_all[b] = max.(BB.Z_BI_all[b] - BB.Shock_B_Z[b], 0.0) # 银行之银行间负债变动
#             update_B_balanceSheet!(BB, BI, b, ib; byWay = "Z_BI_all")
#             BB.A_Q[b] = max.(BB.A_Q[b] - BB.Shock_B_Z[b], 0.0) # 银行之流动资产变动
#             update_B_state!(BB, BI; to = "illiquity", from = "healthy") # 更新各银行之状态，从健康到流动性短缺
#             # update_B_state!(BB, BI; to = "bankrupt", from = "illiquity") # 更新各银行之状态，从流动性短缺到破产
#             update_B_balanceSheet!(BB, BI, b, ib; byWay = "A_Q")
#             BB.A_BI_all[BB.ilq] = BB_t1.A_BI_all[BB.ilq] - ((BB.Shock_B_Z[BB.ilq] - BB_t1.A_Q[BB.ilq]) ./ (BB_t1.A_P[BB.ilq] + BB_t1.A_BI_all[BB.ilq]) .* BB_t1.A_BI_all[BB.ilq]) # 银行间资产应变动，由于回收资产
#             update_B_balanceSheet!(BB, BI, b, ib; byWay = "A_BI_all") # 更新资产负债表，通过A_P或A_BI_all
#             BB.Shock_BI_run_ilq_s[BB.ilq] = abs.(BB.A_BI_all[BB.ilq] - BB_t1.A_BI_all[BB.ilq]) # 计算应银行内冲击传导至银行间传染冲击
#             update_B_Shock!(BB, BI, b, ib; byWay = "Shock_BI_run_ilq_s") # 汇总各银行之流动性短缺流动性挤兑冲击
#             BB.A_P[BB.ilq] = BB_t1.A_P[BB.ilq] - ((BB.Shock_B_Z[BB.ilq] - BB_t1.A_Q[BB.ilq]) ./ (BB_t1.A_P[BB.ilq] + BB_t1.A_BI_all[BB.ilq]) .* BB_t1.A_P[BB.ilq]) # 非银行间贷款资产应变动，由于回收资产
#             update_B_balanceSheet!(BB, BI, b, ib; byWay = "A_P") # 更新资产负债表，通过A_P或A_BI_all
#             BB.Shock_P_run_s[BB.ilq] = abs.(BB.A_P[BB.ilq] - BB_t1.A_P[BB.ilq]) # 银行内冲击传导至银行厂商贷款传染冲击
#             # i0 = (BB.br .&& BB.ilq) # 计算状态之于银行集合其满足破产和流动性短缺
#             # BB.Shock_BI_run_br_s[i0] = BB.A_BI_all[i0] # 流动性短缺的银行内冲击传导至银行倒闭冲击
#             # update_B_Shock!(BB, BI,b,ib; byWay = "Shock_BI_run_br_s") # 汇总各银行之倒闭流动性挤兑冲击



#             ## # 尾声阶段$t_{4}$：
#             println("t4 开始尾声阶段")

#             # update_B_state!(BB, BI; to = "bankrupt", from = "illiquity") # 更新各银行之状态到破产

#             ## TODO存储数据
#             BB_tau[env.tau] = deepcopy(BB) # 存储该回合传染结果数据
#             BI_tau[env.tau] = deepcopy(BI) # 存储该回合传染结果数据

#             ## 清零银行内冲击变量
#             update_B_Shock!(BB, BI, b, ib; byWay = "clear Shock_B_A and Shock_B_Z") # 清零银行内资产负债冲击

#             ## 判定本回合是否有银行转移状态，如果无则后续处理然后结束本轮，如果有则继续处理。
#             if BB.ilq == BB_t1.ilq
#                 env.is_end_round = true
#                 break
#             end


#         end # while # 过程：流动性短缺银行间挤兑流动冲击传染


#         # ## 循环，当回合$\env.tau>1$时：
#         # while (env.tau <= env.max_num_tau .&& env.is_end_round != true)

#         #     env.tau += 1 # 传染回合累加一
#         #     println("开始回合",env.tau)

#         #     ## # 初始阶段$t_{0}$，当$\env.tau>1$时：
#         #     println("t0 初始阶段")

#         #     b = TypeState{1}(BB.on .|| BB.off) # 临时设置BB示性变量
#         #     ib = TypeState{2}((BB.on .|| BB.off) .&& (BB.on .|| BB.off)') # 临时设置BI示性变量

#         #     ## # 银行间传染冲击阶段$t_{1}$，当$\env.tau>1$时：
#         #     println("t1 开始银行间传染冲击阶段")

#         #     # ## ## 流动性短缺银行银行间挤兑流动冲击传染方式 $i_{ilq} \stackrel{BI,run}{\longrightarrow} k_{deb}$：
#         #     # println("t1-2 流动性短缺银行银行间挤兑流动冲击传染方式")
#         #     # for i in findall(BB.ilq) # 流动性短缺银行收回资产，导致其对各债务银行之资产变动，造成流动性短缺银行间挤兑流动冲击
#         #     #     BI.A_BI[i, BI.deb[i]] = BI_t1.A_BI[i, BI.deb[i]] .* (1.0 - BB.Shock_BI_run_ilq_s[i] ./ BB_t1.A_BI_all[i])
#         #     #     BI.Shock_BI_run_ilq[BI.deb[i], i] = BI_t1.A_BI[i, BI.deb[i]] .* BB.Shock_BI_run_ilq_s[i] ./ BB_t1.A_BI_all[i] # 注意这里用BI.A_BI而非BI.Z_BI是因为转换资产负债表过程被放在后面了
#         #     # end
#         #     # # HACK以下部分是否提取出来在阶段1结束之前使用
#         #     # update_B_balanceSheet!(BB, BI, b, ib; byWay = "alter to Z_BI from A_BI") # 转换银行间资产负债邻接矩阵
#         #     # update_B_Shock!(BB, BI, b, ib; byWay = "Shock_BI_run_ilq") # 加总各单个债务银行遭受总银行间挤兑流动冲击
#         #     # # BB.A_BI_all[b] -= BB.Shock_BI_run_ilq_t[b] # HACK（仅作说明）各流动性短缺银行对应债务银行之银行间负债变动（不是在此处出现，而是在银行内冲击阶段出现）。可以删除。
#         #     # BB.Shock_B_Z[b] = BB.Shock_BI_run_t[b] # 银行间冲击传导为银行内冲击
#         #     # update_B_Shock!(BB, BI, b, ib; byWay = "Shock_B_Z") # 汇总各银行之银行内资产负债冲击

#         #     ## ## 破产银行银行间挤兑流动冲击传染方式 $i_{br} \stackrel{BI,run}{\longrightarrow} k_{deb}$：
#         #     println("t1-3 破产银行银行间挤兑流动冲击传染方式")
#         #     for i in findall(BB.br) # 破产银行收回其银行间资产，用于后续偿还其银行间负债。此举导致其对各债务银行之资产变动，造成破产银行银行间挤兑流动冲击
#         #         BI.A_BI[i, BI.deb[i]] = BI_t1.A_BI[i, BI.deb[i]] .* (1.0 - BB.Shock_BI_run_br_s[i] ./ BB_t1.A_BI_all[i])
#         #         BI.Shock_BI_run_br[BI.deb[i], i] = BI_t1.A_BI[i, BI.deb[i]] .* BB.Shock_BI_run_br_s[i] ./ BB_t1.A_BI_all[i] # 注意这里用BI.A_BI而非BI.Z_BI是因为转换资产负债表过程被放在后面了
#         #         # BI.Shock_BI_run_br[BI.deb[i], i], BI.A_BI[i, BI.deb[i]] = transfer_B_capital(BI.Shock_BI_run_br[BI.deb[i], i], BI.A_BI[i, BI.deb[i]], BI.A_BI[i, BI.deb[i]])
#         #     end
#         #     # HACK以下部分是否提取出来在阶段1结束之前使用
#         #     update_B_balanceSheet!(BB, BI, b, ib; byWay = "alter to Z_BI from A_BI") # 转换银行间资产负债邻接矩阵
#         #     update_B_Shock!(BB, BI, b, ib; byWay = "Shock_BI_run_br") # 加总各单个债务银行遭受总银行间挤兑流动冲击
#         #     # BB.A_BI_all[b] -= BB.Shock_BI_run_br_t[b] # HACK（仅作说明）各流动性短缺银行对应债务银行之银行间负债变动（不是在此处出现，在银行内冲击阶段出现）。可以删除。
#         #     BB.Shock_B_Z[b] = BB.Shock_BI_run_t[b] # 银行间冲击传导为银行内冲击
#         #     update_B_Shock!(BB, BI, b, ib; byWay = "Shock_B_Z") # 更新各银行之冲击变量，通过银行内负债冲击

#         #     # update_B_state!(BB, BI; to = "off", from = "bankrupt") # 更新各银行之状态，从破产到退出


#         #     ## # 银行资产负债冲击阶段$t_{2}$，当$\env.tau>1$时：
#         #     println("t2 开始银行资产负债冲击阶段")


#         #     ## ## 初始化：
#         #     println("t2-0 初始化")

#         #     ## ## 银行内负债冲击：
#         #     println("t2-2 银行内负债冲击")

#         #     ## 设置临时变量
#         #     BB_t1 = deepcopy(BB) # 临时设置BB变量
#         #     BI_t1 = deepcopy(BI) # 临时设置BI变量

#         #     i1 = (BB.on .&& ((BB.Z_D - BB.Shock_D_def_s) + ((BB.Z_BI_all - BB.Shock_BI_def_s)) .< BB.Shock_B_Z)) # 计算条件之于银行集合其满足其应违约但是应被收回
#         #     BB.Shock_B_Z[i1] = (BB.Shock_D_def_s[i1] + BB.Shock_BI_def_s[i1]) - (BB.Z_D[i1] + BB.Z_BI_all[i1]) # 更新遭受实际银行内负债冲击
#         #     update_B_Shock!(BB, BI, b, ib; byWay = "Shock_B_Z")
#         #     update_B_state!(BB, BI; to = "illiquity", from = "healthy")
#         #     BB.Z_BI_all[b] = max.(BB.Z_BI_all[b] - BB.Shock_B_Z[b], 0.0) # 银行之银行间负债变动
#         #     update_B_balanceSheet!(BB, BI, b, ib; byWay = "Z_BI_all")
#         #     BB.A_Q[b] = max.(BB.A_Q[b] - BB.Shock_B_Z[b], 0.0) # 银行之流动资产变动
#         #     update_B_state!(BB, BI; to = "illiquity", from = "healthy") # 更新各银行之状态，从健康到破产
#         #     # update_B_state!(BB, BI; to = "bankrupt", from = "illiquity") # 更新各银行之状态，从健康到破产
#         #     update_B_balanceSheet!(BB, BI, b, ib; byWay = "A_Q")
#         #     BB.A_BI_all[BB.ilq] = BB_t1.A_BI_all[BB.ilq] - ((BB.Shock_B_Z[BB.ilq] - BB_t1.A_Q[BB.ilq]) ./ (BB_t1.A_P[BB.ilq] + BB_t1.A_BI_all[BB.ilq]) .* BB_t1.A_BI_all[BB.ilq]) # 银行间资产应变动，由于回收资产
#         #     update_B_balanceSheet!(BB, BI, b, ib; byWay = "A_BI_all") # 更新资产负债表，通过A_P或A_BI_all
#         #     BB.Shock_BI_run_ilq_s[BB.ilq] = abs.(BB.A_BI_all[BB.ilq] - BB_t1.A_BI_all[BB.ilq]) # 计算应银行内冲击传导至银行间传染冲击
#         #     update_B_Shock!(BB, BI, b, ib; byWay = "Shock_BI_run_ilq_s") # 汇总各银行之流动性短缺流动性挤兑冲击
#         #     BB.A_P[BB.ilq] = BB_t1.A_P[BB.ilq] - ((BB.Shock_B_Z[BB.ilq] - BB_t1.A_Q[BB.ilq]) ./ (BB_t1.A_P[BB.ilq] + BB_t1.A_BI_all[BB.ilq]) .* BB_t1.A_P[BB.ilq]) # 非银行间贷款资产应变动，由于回收资产
#         #     update_B_balanceSheet!(BB, BI, b, ib; byWay = "A_P") # 更新资产负债表，通过A_P或A_BI_all
#         #     BB.Shock_P_run_s[BB.ilq] = abs.(BB.A_P[BB.ilq] - BB_t1.A_P[BB.ilq]) # 银行内冲击传导至银行厂商贷款传染冲击
#         #     # i0 = (BB.br .&& BB.ilq) # 计算状态之于银行集合其满足破产和流动性短缺
#         #     # BB.Shock_BI_run_br_s[i0] = BB.A_BI_all[i0] # 流动性短缺的银行内冲击传导至银行倒闭冲击
#         #     # update_B_Shock!(BB, BI,b,ib; byWay = "Shock_BI_run_br_s") # 汇总各银行之倒闭流动性挤兑冲击

#         #     ## 清零银行间和银行外冲击变量
#         #     update_B_Shock!(BB, BI, b, ib; byWay = "clear Shock_BI and Shock_exBI") # 清零各银行之不必要的冲击变量，被使用于下一回合，从第二回合开始


#         #     ## # 破产召回阶段$t_{3}$：，当$\env.tau>1$时：
#         #     println("t3 开始破产召回阶段")

#         #     ## 设置临时变量
#         #     BB_t2 = deepcopy(BB) # 临时设置BB变量
#         #     BI_t2 = deepcopy(BI) # 临时设置BI变量

#         #     BB.Shock_BI_run_br_s[BB.br], BB.A_BI_all[BB.br] = transfer_B_capital(BB.Shock_BI_run_br_s[BB.br], BB.A_BI_all[BB.br], BB.A_BI_all[BB.br]) # 转移破产银行之资产变动，并且银行内冲击传导至银行倒闭挤兑流动冲击
#         #     update_B_Shock!(BB, BI, b, ib; byWay = "Shock_BI_run_br_s") # 汇总各银行之倒闭流动性挤兑冲击
#         #     BB.Shock_P_run_s[BB.br], BB.A_P[BB.br] = transfer_B_capital(BB.Shock_P_run_s[BB.br], BB.A_P[BB.br], BB.A_P[BB.br]) # 非银行间贷款资产应变动，由于回收资产，并且银行内冲击传导至银行厂商贷款传染冲击
#         #     # BB.A_P[BB.br] .= 0.0  #HACK，冗余，可以删除
#         #     # BB.Shock_BI_run_br_s[BB.br] = abs.(BB.A_BI_all[BB.br] - BB_t1.A_BI_all[BB.br]) # 倒闭的银行之银行内冲击传导至银行倒闭挤兑流动冲击  #HACK，冗余，可以删除
#         #     update_B_Shock!(BB, BI, b, ib; byWay = "Shock_BI_run_br_s") # 汇总各银行之倒闭流动性挤兑冲击
#         #     # BB.Shock_P_run_s[BB.br] = abs.(BB.A_P[BB.br] - BB_t1.A_P[BB.br]) # 银行内冲击传导至银行厂商贷款传染冲击 #HACK，冗余，可以删除
#         #     # update_B_balanceSheet!(BB, BI,b,ib; byWay = "alter to Z_BI from A_BI") # 转换银行间资产负债邻接矩阵
#         #     # update_B_balanceSheet!(BB, BI,b,ib; byWay = "A_other") # 更新各银行之资产负债表变量，通过其它资产
#         #     # BB.A_P[br] .= 0.0 # 破产银行之非银行间贷款清零
#         #     # BB.A_Q[BB.br], BB.A_BI_all[BB.br] = transfer_B_capital(BB.A_Q[BB.br], BB.A_BI_all[BB.br], BB.A_BI_all[BB.br])
#         #     # for i in findall(BB.br) # 破产银行偿还银行间借款，破产银行对应债权银行之银行间资产变成各自债权银行之其它资产
#         #     #     BB.A_other[BI.cre[i]], BI.A_BI[BI.cre[i], i] = transfer_B_capital(BB.A_other[BI.cre[i]], BI.A_BI[BI.cre[i], i], BI.A_BI[BI.cre[i], i])
#         #     #     # BB.A_other[BI.cre[i]] += BI.A_BI[BI.cre[i], i]
#         #     #     # BI.A_BI[BI.cre[i], i] .= 0.0
#         #     # end
#         #     # BB.A_Q[br] .= 0.0 # 破产银行之流动资金清零
#         #     # BB.A_R[br] .= 0.0 # 破产银行之存款准备金清零
#         #     # BB.A_other[br] .= 0.0 # 破产银行之其它资产清零
#         #     # update_B_balanceSheet!(BB, BI,b,ib; byWay = "A_exBI") # 更新各银行之资产负债表变量，通过非银行间资产
#         #     # BB.Z_D[br] .= 0.0 # 破产银行之居民存款清零，为了偿还剩余存款负债
#         #     # BB.Z_other[br] .= 0.0 # 破产银行之其它负债清零
#         #     # BB.Z_BI_all[br] .= 0.0 # 破产银行之银行间贷款清零，为了偿还所有银行间负债
#         #     # update_B_balanceSheet!(BB, BI,b,ib; byWay = "Z_exBI") # 更新各银行之资产负债表变量，通过非银行间负债
#         #     # update_B_state!(BB, BI; to = "off", from = "bankrupt") # 更新各银行之状态，从破产到退出





#         #     ## # 尾声阶段$t_{4}$：
#         #     println("t4 开始尾声阶段")

#         #     ## TODO存储数据
#         #     BB_tau[env.tau] = deepcopy(BB) # 存储该回合传染结果数据
#         #     BI_tau[env.tau] = deepcopy(BI) # 存储该回合传染结果数据

#         #     ## 清零银行内冲击变量
#         #     update_B_Shock!(BB, BI, b, ib; byWay = "clear Shock_B_A and Shock_B_Z") # 清零银行内资产负债冲击

#         #     ## 判定本回合是否有银行转移状态，如果无则后续处理然后结束本轮，如果有则继续处理。
#         #     if BB.off == BB_t1.off
#         #         env.is_end_round = true
#         #         break
#         #     end

#         # end # while

#     end # while

